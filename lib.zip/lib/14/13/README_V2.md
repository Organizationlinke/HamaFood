# Hama Work - Flutter lib V2

This `lib` replaces the old Hama Work Flutter `lib` and is designed for the Hama Work Database V2 schema.

## Replace

Replace the existing project `lib/` folder with the `lib/` folder from this package.

## Existing dependencies

The code is intentionally limited to the dependencies already used by the original app:

- flutter
- flutter_riverpod
- go_router
- supabase_flutter

No secret key is included in Flutter.

## Runtime configuration

Keep the existing dart-defines, using:

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `HAMA_AUTH_DOMAIN` (optional; default: `auth.hamaholding.com`)

The username `ahmed` is mapped by the app to the Auth email `ahmed@auth.hamaholding.com`.

## Included modules

- Authentication and username-based sign in
- Dashboard / Needs Your Attention
- Work Items, participants, status, archive, reopen, final result
- Tasks, responsible/follower, deadlines, priority, stages, evidence, task chat, manager confirmation, evaluation and reopen
- Messages, audience selection, seen tracking, replies/comments, mentions and reactions
- Daily Work
- Activities, including standalone activities and Work Item / Task links
- Approvals and manager decisions
- Notifications
- Search across core business records and file metadata
- Reports
- Users and departments
- Work Item timeline / audit-facing views
- Supabase Storage metadata links

## Important integration notes

1. Deploy the V2-compatible `create-user` Edge Function. The old function expects the old `admin` role and old profile fields.
2. The current lib records attachment metadata and Storage paths. True device file/photo/voice selection requires adding platform packages to `pubspec.yaml`; no new package was silently assumed here.
3. Automatic push/in-app notification generation and scheduled overdue processing depend on database triggers / scheduled jobs. The lib displays and consumes the notification and overdue data model, and computes overdue status from deadline when reading tasks.
4. Database V2 should allow standalone activities. See the accompanying SQL patch supplied with this delivery.

## Validation

The Dart source was checked for balanced syntax delimiters and old-schema identifiers. A full `flutter analyze` could not be run in this environment because the Flutter/Dart SDK is not installed here.
