import 'dart:math';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/supabase_client.dart';
import '../models/models.dart';

class AppRepository {
  SupabaseClient get _db => supabase;
  String get _uid => _db.auth.currentUser?.id ?? (throw const AuthException('Not authenticated'));

  String _code(String prefix) {
    final d = DateTime.now();
    final r = Random.secure().nextInt(9000) + 1000;
    return '$prefix-${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}-${d.hour.toString().padLeft(2, '0')}${d.minute.toString().padLeft(2, '0')}${d.second.toString().padLeft(2, '0')}-$r';
  }

  String _day(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _effectiveTaskStatus(Map<String, dynamic> m) {
    final status = (m['status'] ?? 'not_started').toString();
    if (status == 'completed' || status == 'cancelled' || status == 'overdue') return status;
    final deadline = DateTime.tryParse(m['deadline']?.toString() ?? '');
    if (deadline != null && deadline.isBefore(DateTime.now())) return 'overdue';
    return status;
  }

  Future<Profile?> myProfile() async {
    if (_db.auth.currentUser == null) return null;
    final row = await _db.from('profiles').select('*, department:departments(name,code)').eq('id', _uid).maybeSingle();
    if (row == null) return null;
    final m = Map<String, dynamic>.from(row);
    if (m['department'] is Map) {
      final d = Map<String, dynamic>.from(m['department'] as Map);
      m['department_name'] = d['name'];
    }
    return Profile.fromMap(m);
  }

  Future<Profile> _currentProfile() async => (await myProfile()) ?? (throw const AuthException('Profile not found'));
  Future<void> _requireGm() async { final p = await _currentProfile(); if (!p.isActive || !p.isGm) throw const AuthException('Only the General Manager can perform this action'); }
  Future<void> _requireManager() async { final p = await _currentProfile(); if (!p.isActive || !(p.isGm || p.isManager)) throw const AuthException('Manager permission required'); }

  Future<void> loginWithUsername({required String username, required String password}) async {
    final u = username.trim().toLowerCase();
    if (!RegExp(r'^[a-z0-9._-]{3,40}$').hasMatch(u)) throw const AuthException('Invalid username');
    await _db.auth.signInWithPassword(email: '$u@${AppConfig.authDomain}', password: password);
    final row = await _db.from('profiles').select('username,is_active').eq('id', _uid).maybeSingle();
    if (row == null) {
      await _db.auth.signOut();
      throw const AuthException('Profile is not configured for this account');
    }
    final dbUsername = (row['username'] ?? '').toString().toLowerCase();
    if (dbUsername != u || row['is_active'] != true) {
      await _db.auth.signOut();
      throw const AuthException('User is inactive or username does not match');
    }

    // last_seen_at must never be allowed to block a successful login.
    try {
      await _db.from('profiles').update({
        'last_seen_at': DateTime.now().toIso8601String(),
      }).eq('id', _uid);
    } catch (_) {
      // Ignore activity timestamp failures; authentication is already valid.
    }
  }

  Future<List<Profile>> users({bool activeOnly = false}) async {
    var q = _db.from('profiles').select('*, department:departments(name,code)');
    if (activeOnly) q = q.eq('is_active', true);
    final rows = await q.order('full_name');
    return rows.map<Profile>((row) {
      final m = Map<String, dynamic>.from(row);
      if (m['department'] is Map) m['department_name'] = (m['department'] as Map)['name'];
      return Profile.fromMap(m);
    }).toList();
  }

  Future<List<Department>> departments() async => (await _db.from('departments').select().eq('is_active', true).order('name')).map<Department>((m) => Department.fromMap(m)).toList();

  Future<DashboardStats> dashboardStats() async {
    final work = List<Map<String, dynamic>>.from(await _db.from('work_items').select('id,status,is_archived,responsible_id,follower_id'));
    final tasks = List<Map<String, dynamic>>.from(await _db.from('tasks').select('id,status,responsible_id,follower_id,deadline'));
    final pending = await _db.from('approvals').select('id').eq('status', 'pending').count(CountOption.exact);
    final unreadN = await _db.from('notifications').select('id').eq('user_id', _uid).eq('is_read', false).count(CountOption.exact);
    final unreadM = await _db.from('message_recipients').select('id').eq('user_id', _uid).isFilter('seen_at', null).count(CountOption.exact);
    final daily = List<Map<String, dynamic>>.from(await _db.from('daily_works').select('id').eq('user_id', _uid).eq('work_date', _day(DateTime.now())));
    final activeWork = work.where((x) => x['is_archived'] != true).toList();
    return DashboardStats(
      workItems: activeWork.length,
      openWorkItems: activeWork.where((x) => ['open', 'in_progress', 'waiting'].contains(x['status'])).length,
      tasks: tasks.length,
      myTasks: tasks.where((x) => x['responsible_id'] == _uid || x['follower_id'] == _uid).length,
      overdueTasks: tasks.where((x) => _effectiveTaskStatus(x) == 'overdue').length,
      readyTasks: tasks.where((x) => _effectiveTaskStatus(x) == 'ready_for_completion').length,
      unreadMessages: unreadM.count,
      unreadNotifications: unreadN.count,
      pendingApprovals: pending.count,
      todayDailyWork: daily.length,
    );
  }

  Future<List<WorkItem>> workItems({String? status, bool includeArchived = false}) async {
    var q = _db.from('work_items').select();
    if (!includeArchived) q = q.eq('is_archived', false);
    if (status != null && status.isNotEmpty) q = q.eq('status', status);
    final rows = await q.order('updated_at', ascending: false);
    return rows.map<WorkItem>((m) => WorkItem.fromMap(m)).toList();
  }

  Future<WorkItem> workItemById(String id) async => WorkItem.fromMap(await _db.from('work_items').select().eq('id', id).single());

  Future<WorkItem> createWorkItem({required String title, String? description, required String category, required String priority, String? responsibleId, String? followerId, DateTime? deadline}) async {
    final row = await _db.from('work_items').insert({
      'code': _code('WI'), 'title': title, 'description': description, 'category': category,
      'status': 'open', 'priority': priority, 'responsible_id': responsibleId, 'follower_id': followerId,
      'deadline': deadline?.toIso8601String(), 'created_by': _uid,
    }).select().single();
    final participantIds = <String>{};
    if (responsibleId != null && responsibleId.isNotEmpty) participantIds.add(responsibleId);
    if (followerId != null && followerId.isNotEmpty) participantIds.add(followerId);
    if (participantIds.isNotEmpty) {
      await _db.from('work_item_participants').upsert(participantIds.map((id) => {'work_item_id': row['id'], 'user_id': id}).toList(), onConflict: 'work_item_id,user_id');
    }
    await addTimeline(workItemId: row['id'].toString(), eventType: 'created', title: 'Work Item created', description: title);
    return WorkItem.fromMap(row);
  }

  Future<void> updateWorkItem(String id, Map<String, dynamic> values) async {
    await _db.from('work_items').update(values).eq('id', id);
    await addTimeline(workItemId: id, eventType: 'updated', title: 'Work Item updated');
  }

  Future<void> setWorkItemStatus(String id, String status) async {
    if (status == 'completed' || status == 'cancelled') await _requireManager();
    await _db.from('work_items').update({'status': status}).eq('id', id);
    await addTimeline(workItemId: id, eventType: 'status_changed', title: 'Work Item status changed', description: status);
  }

  Future<void> completeWorkItem(String id, String result) async {
    await _requireManager();
    await _db.from('work_items').update({'status': 'completed', 'final_result': result, 'completed_at': DateTime.now().toIso8601String(), 'completed_by': _uid}).eq('id', id);
    await addTimeline(workItemId: id, eventType: 'completed', title: 'Work Item completed', description: result);
  }

  Future<void> reopenWorkItem(String id) async { await _requireManager(); await _db.from('work_items').update({'status': 'in_progress', 'reopened_at': DateTime.now().toIso8601String(), 'reopened_by': _uid}).eq('id', id); await addTimeline(workItemId: id, eventType: 'reopened', title: 'Work Item reopened'); }
  Future<void> archiveWorkItem(String id) async { await _requireManager(); await _db.from('work_items').update({'is_archived': true, 'archived_at': DateTime.now().toIso8601String(), 'archived_by': _uid}).eq('id', id); await addTimeline(workItemId: id, eventType: 'archived', title: 'Work Item archived'); }

  Future<List<Profile>> workItemParticipants(String id) async {
    final rows = await _db.from('work_item_participants').select('user_id').eq('work_item_id', id);
    final ids = rows.map((e) => e['user_id'].toString()).toList();
    if (ids.isEmpty) return [];
    final users = await _db.from('profiles').select('*, department:departments(name)').inFilter('id', ids);
    return users.map<Profile>((m) => Profile.fromMap(m)).toList();
  }

  Future<void> addWorkItemParticipant(String workItemId, String userId) async { await _db.from('work_item_participants').upsert({'work_item_id': workItemId, 'user_id': userId}); await addTimeline(workItemId: workItemId, eventType: 'participant_added', title: 'Participant added'); }
  Future<void> removeWorkItemParticipant(String workItemId, String userId) async => _db.from('work_item_participants').delete().eq('work_item_id', workItemId).eq('user_id', userId);

  Future<List<Task>> tasks({String? workItemId}) async {
    var q = _db.from('tasks').select();
    if (workItemId != null && workItemId.isNotEmpty) q = q.eq('work_item_id', workItemId);
    final rows = await q.order('created_at', ascending: false);
    return rows.map<Task>((m) { final x = Map<String, dynamic>.from(m); x['status'] = _effectiveTaskStatus(x); return Task.fromMap(x); }).toList();
  }

  Future<Task> taskById(String id) async { final m = Map<String, dynamic>.from(await _db.from('tasks').select().eq('id', id).single()); m['status'] = _effectiveTaskStatus(m); return Task.fromMap(m); }

  Future<Task> createTask({required String title, String? description, String? workItemId, required String priority, DateTime? deadline, required String responsibleId, String? followerId, List<String> additionalResponsibleIds = const [], bool evidenceRequired = false, bool managerConfirmationRequired = true}) async {
    await _requireGm();
    final effectiveDeadline = deadline ?? DateTime.now().add(const Duration(days: 1));
    final row = await _db.from('tasks').insert({
      'code': _code('TASK'), 'title': title, 'description': description, 'work_item_id': workItemId,
      'responsible_id': responsibleId, 'follower_id': followerId, 'deadline': effectiveDeadline.toIso8601String(),
      'priority': priority, 'status': 'not_started', 'evidence_required': evidenceRequired,
      'manager_confirmation_required': managerConfirmationRequired, 'manager_confirmed': false, 'created_by': _uid,
    }).select().single();

    final assignmentIds = <String>{responsibleId, ...additionalResponsibleIds};
    await _db.from('task_assignments').upsert(
      assignmentIds.map((id) => {'task_id': row['id'], 'user_id': id, 'assignment_type': 'responsible'}).toList(),
      onConflict: 'task_id,user_id,assignment_type',
    );
    if (followerId != null && followerId.isNotEmpty) {
      await _db.from('task_assignments').upsert(
        {'task_id': row['id'], 'user_id': followerId, 'assignment_type': 'follower'},
        onConflict: 'task_id,user_id,assignment_type',
      );
    }
    if (workItemId != null) {
      await addTimeline(workItemId: workItemId, eventType: 'task_created', title: 'Task created', description: title);
    }
    return Task.fromMap(row);
  }

  Future<void> startTask(String id) async { await _db.from('tasks').update({'status': 'in_progress'}).eq('id', id); await _taskEvent(id, 'Task started'); }

  Future<void> requestCompletion(String id) async {
    final task = await taskById(id);
    if (!task.managerConfirmationRequired) {
      await _db.from('tasks').update({
        'status': 'completed',
        'completed_at': DateTime.now().toIso8601String(),
        'completed_by': _uid,
      }).eq('id', id);
      await _taskEvent(id, 'Task completed');
      return;
    }
    await _db.from('tasks').update({
      'status': 'ready_for_completion',
      'completion_requested_at': DateTime.now().toIso8601String(),
    }).eq('id', id);
    await _taskEvent(id, 'Task ready for completion');
  }
  Future<void> confirmTask(String id, int score, {String? comment}) async { await _requireManager(); await _db.from('tasks').update({'status': 'completed', 'completed_at': DateTime.now().toIso8601String(), 'completed_by': _uid, 'manager_confirmed': true, 'manager_confirmed_by': _uid, 'manager_confirmed_at': DateTime.now().toIso8601String(), 'score': score, 'eval_comment': comment}).eq('id', id); await _taskEvent(id, 'Task completed and evaluated'); }
  Future<void> reopenTask(String id) async { await _requireManager(); await _db.from('tasks').update({'status': 'in_progress', 'reopened_at': DateTime.now().toIso8601String(), 'reopened_by': _uid}).eq('id', id); await _taskEvent(id, 'Task reopened'); }
  Future<void> cancelTask(String id) async { await _requireManager(); await _db.from('tasks').update({'status': 'cancelled', 'cancelled_at': DateTime.now().toIso8601String(), 'cancelled_by': _uid}).eq('id', id); await _taskEvent(id, 'Task cancelled'); }
  Future<void> _taskEvent(String id, String title) async { final t = await taskById(id); if (t.workItemId != null) await addTimeline(workItemId: t.workItemId!, eventType: 'task_updated', title: title, description: t.title); }

  Future<List<TaskStage>> taskStages(String taskId) async => (await _db.from('task_stages').select().eq('task_id', taskId).order('sort_order')).map<TaskStage>((m) => TaskStage.fromMap(m)).toList();
  Future<void> createTaskStage({required String taskId, required String title, String? description, String? responsibleId, DateTime? deadline, int sortOrder = 1}) async { await _db.from('task_stages').insert({'task_id': taskId, 'title': title, 'description': description, 'responsible_id': responsibleId, 'deadline': deadline?.toIso8601String(), 'status': 'pending', 'sort_order': sortOrder}); }
  Future<void> updateTaskStage(String id, Map<String, dynamic> values) async => _db.from('task_stages').update(values).eq('id', id);
  Future<List<Map<String, dynamic>>> taskEvidence(String taskId) async => List<Map<String, dynamic>>.from(await _db.from('task_evidence').select().eq('task_id', taskId).order('created_at', ascending: false));
  Future<void> addTaskEvidence({required String taskId, required String title, String? description, String? attachmentId}) async => _db.from('task_evidence').insert({'task_id': taskId, 'title': title, 'description': description, 'attachment_id': attachmentId, 'created_by': _uid});

  Future<List<Activity>> activities({String? workItemId, String? taskId}) async {
    var q = _db.from('activities').select();
    if (workItemId != null && workItemId.isNotEmpty) q = q.eq('work_item_id', workItemId);
    if (taskId != null && taskId.isNotEmpty) q = q.eq('task_id', taskId);
    final rows = await q.order('date_time', ascending: false).limit(200);
    return rows.map<Activity>((m) => Activity.fromMap(m)).toList();
  }

  Future<void> addActivity({required String type, required DateTime dateTime, required String description, String? withWhom, String? toWhom, String? result, String? nextAction, String? workItemId, String? taskId}) async {
    await _db.from('activities').insert({'type': type, 'date_time': dateTime.toIso8601String(), 'with_whom': withWhom, 'to_whom': toWhom, 'description': description, 'result': result, 'next_action': nextAction, 'work_item_id': workItemId, 'task_id': taskId, 'created_by': _uid});
    if (workItemId != null) await addTimeline(workItemId: workItemId, eventType: 'activity', title: 'Activity added', description: description);
  }

  Future<List<MessageItem>> messages() async {
    final raw = List<Map<String, dynamic>>.from(await _db.from('messages').select().order('created_at', ascending: false).limit(200));
    if (raw.isEmpty) return [];
    final ids = raw.map((m) => m['id'].toString()).toList();
    final senderIds = raw.map((m) => m['created_by']?.toString()).whereType<String>().toSet().toList();
    final senders = senderIds.isEmpty ? <Map<String, dynamic>>[] : List<Map<String, dynamic>>.from(await _db.from('profiles').select('id,full_name').inFilter('id', senderIds));
    final names = {for (final s in senders) s['id'].toString(): s['full_name'].toString()};
    final rec = List<Map<String, dynamic>>.from(await _db.from('message_recipients').select('message_id,user_id,seen_at').inFilter('message_id', ids));
    final by = <String, List<Map<String, dynamic>>>{};
    for (final r in rec) (by[r['message_id'].toString()] ??= []).add(r);
    return raw.map((m) {
      final r = by[m['id'].toString()] ?? [];
      return MessageItem(
        id: m['id'].toString(), code: (m['code'] ?? '').toString(), content: (m['content'] ?? '').toString(),
        messageType: (m['message_type'] ?? 'information').toString(), audienceType: (m['audience_type'] ?? 'everyone').toString(),
        workItemId: m['work_item_id']?.toString(), taskId: m['task_id']?.toString(), createdBy: m['created_by']?.toString(),
        senderName: names[m['created_by']?.toString() ?? ''], createdAt: DateTime.tryParse(m['created_at']?.toString() ?? '') ?? DateTime.now(),
        recipientCount: r.length, seenCount: r.where((x) => x['seen_at'] != null).length,
        seenByMe: r.any((x) => x['user_id'].toString() == _uid && x['seen_at'] != null),
      );
    }).toList();
  }

  Future<MessageItem?> messageById(String id) async { final xs = await messages(); for (final x in xs) { if (x.id == id) return x; } return null; }

  Future<MessageItem> sendMessage({required String content, required String messageType, required String audienceType, List<String> recipientIds = const [], String? workItemId, String? taskId}) async {
    final row = await _db.from('messages').insert({'code': _code('MSG'), 'content': content, 'message_type': messageType, 'audience_type': audienceType, 'work_item_id': workItemId, 'task_id': taskId, 'created_by': _uid}).select().single();
    final active = List<Map<String, dynamic>>.from(await _db.from('profiles').select('id').eq('is_active', true));
    final ids = audienceType == 'everyone' ? active.map((x) => x['id'].toString()).toSet().toList() : recipientIds.toSet().toList();
    if (!ids.contains(_uid)) ids.add(_uid);
    final now = DateTime.now().toIso8601String();
    await _db.from('message_recipients').upsert(ids.map((id) => {'message_id': row['id'], 'user_id': id, 'seen_at': id == _uid ? now : null}).toList(), onConflict: 'message_id,user_id');
    await addMentionsFromText('message', row['id'].toString(), content);
    if (workItemId != null) await addTimeline(workItemId: workItemId, eventType: 'message', title: 'Message added', description: content);
    return MessageItem(id: row['id'].toString(), code: row['code'].toString(), content: content, messageType: messageType, audienceType: audienceType, workItemId: workItemId, taskId: taskId, createdBy: _uid, createdAt: DateTime.now(), recipientCount: ids.length, seenCount: 1, seenByMe: true);
  }

  Future<void> markMessageSeen(String id) async => _db.from('message_recipients').upsert({'message_id': id, 'user_id': _uid, 'seen_at': DateTime.now().toIso8601String()}, onConflict: 'message_id,user_id');
  Future<void> linkMessageToWorkItem(String messageId, String workItemId) async { await _db.from('messages').update({'work_item_id': workItemId}).eq('id', messageId); await addTimeline(workItemId: workItemId, eventType: 'message', title: 'Message linked', description: messageId); }
  Future<List<Profile>> messageRecipients(String id) async {
    final rows = await _db.from('message_recipients').select('user_id').eq('message_id', id);
    final ids = rows.map((x) => x['user_id'].toString()).toList();
    if (ids.isEmpty) return [];
    final users = await _db.from('profiles').select('*, department:departments(name)').inFilter('id', ids);
    return users.map<Profile>((m) => Profile.fromMap(m)).toList();
  }

  Future<List<CommentItem>> comments(String parentType, String parentId) async {
    final raw = List<Map<String, dynamic>>.from(await _db.from('comments').select().eq('parent_type', parentType).eq('parent_id', parentId).order('created_at'));
    final ids = raw.map((x) => x['created_by']?.toString()).whereType<String>().toSet().toList();
    final users = ids.isEmpty ? <Map<String, dynamic>>[] : List<Map<String, dynamic>>.from(await _db.from('profiles').select('id,full_name').inFilter('id', ids));
    final names = {for (final u in users) u['id'].toString(): u['full_name'].toString()};
    return raw.map((m) => CommentItem.fromMap(m, creatorName: names[m['created_by']?.toString() ?? ''])).toList();
  }

  Future<void> addComment({required String parentType, required String parentId, required String content}) async {
    await _db.from('comments').insert({'parent_type': parentType, 'parent_id': parentId, 'content': content, 'created_by': _uid});
    await addMentionsFromText(parentType, parentId, content);
  }

  Future<void> addMentionsFromText(String parentType, String parentId, String content) async {
    final matches = RegExp(r'@([a-zA-Z0-9._-]{3,40})').allMatches(content);
    if (matches.isEmpty) return;
    final names = matches.map((m) => m.group(1)!.toLowerCase()).toSet().toList();
    final users = List<Map<String, dynamic>>.from(await _db.from('profiles').select('id,username').inFilter('username', names));
    if (users.isEmpty) return;
    await _db.from('mentions').upsert(users.map((u) => {'parent_type': parentType, 'parent_id': parentId, 'mentioned_user_id': u['id'], 'created_by': _uid}).toList(), onConflict: 'parent_type,parent_id,mentioned_user_id');
  }

  Future<void> react({required String parentType, required String parentId, required String reaction}) async => _db.from('reactions').upsert({'parent_type': parentType, 'parent_id': parentId, 'user_id': _uid, 'reaction': reaction}, onConflict: 'parent_type,parent_id,user_id');

  Future<List<DailyWork>> dailyWorks({DateTime? date, bool all = false}) async {
    var q = _db.from('daily_works').select();
    if (!all) q = q.eq('user_id', _uid);
    if (date != null) q = q.eq('work_date', _day(date));
    final rows = await q.order('work_date', ascending: false).order('created_at', ascending: false).limit(200);
    return rows.map<DailyWork>((m) => DailyWork.fromMap(m)).toList();
  }

  Future<DailyWork> saveDailyWork({required DateTime workDate, required String content, String? problems, String? nextActions, required String status, String? workItemId, String? taskId}) async => DailyWork.fromMap(await _db.from('daily_works').upsert({'user_id': _uid, 'work_date': _day(workDate), 'content': content, 'problems': problems, 'next_actions': nextActions, 'status': status, 'work_item_id': workItemId, 'task_id': taskId, 'updated_at': DateTime.now().toIso8601String()}, onConflict: 'user_id,work_date').select().single());

  Future<List<Approval>> approvals() async => (await _db.from('approvals').select().order('created_at', ascending: false).limit(200)).map<Approval>((m) => Approval.fromMap(m)).toList();
  Future<Approval> createApproval({String? title, required String requestText, required String requestedFrom, DateTime? deadline, String? workItemId, String? taskId}) async => Approval.fromMap(await _db.from('approvals').insert({'code': _code('APR'), 'title': title, 'request_text': requestText, 'requested_from': requestedFrom, 'requested_by': _uid, 'deadline': deadline?.toIso8601String(), 'status': 'pending', 'work_item_id': workItemId, 'task_id': taskId}).select().single());
  Future<void> decideApproval(String id, String status, {String? comment}) async { await _requireManager(); await _db.from('approvals').update({'status': status, 'decision_by': _uid, 'decision_at': DateTime.now().toIso8601String(), 'decision_comment': comment}).eq('id', id); }

  Future<List<NotificationItem>> notifications() async => (await _db.from('notifications').select().eq('user_id', _uid).order('created_at', ascending: false).limit(100)).map<NotificationItem>((m) => NotificationItem.fromMap(m)).toList();
  Future<void> markNotificationRead(String id) async => _db.from('notifications').update({'is_read': true, 'read_at': DateTime.now().toIso8601String()}).eq('id', id).eq('user_id', _uid);
  Future<void> markAllNotificationsRead() async => _db.from('notifications').update({'is_read': true, 'read_at': DateTime.now().toIso8601String()}).eq('user_id', _uid).eq('is_read', false);

  Future<List<AttachmentItem>> attachments({required String parentType, required String parentId}) async => (await _db.from('attachments').select().eq('parent_type', parentType).eq('parent_id', parentId).order('created_at', ascending: false)).map<AttachmentItem>((m) => AttachmentItem.fromMap(m)).toList();
  Future<void> addAttachmentMetadata({required String parentType, required String parentId, required String fileName, required String storagePath, String? mimeType, int? sizeBytes}) async => _db.from('attachments').insert({'parent_type': parentType, 'parent_id': parentId, 'file_name': fileName, 'storage_path': storagePath, 'mime_type': mimeType, 'size_bytes': sizeBytes, 'uploaded_by': _uid});
  String publicStorageUrl(String bucket, String path) => _db.storage.from(bucket).getPublicUrl(path);

  Future<List<TimelineEvent>> timeline(String workItemId) async => (await _db.from('timeline_events').select().eq('work_item_id', workItemId).order('created_at', ascending: false).limit(300)).map<TimelineEvent>((m) => TimelineEvent.fromMap(m)).toList();
  Future<void> addTimeline({required String workItemId, required String eventType, required String title, String? description, Map<String, dynamic>? metadata}) async => _db.from('timeline_events').insert({'work_item_id': workItemId, 'event_type': eventType, 'title': title, 'description': description, 'created_by': _uid, 'metadata': metadata ?? {}});

  Future<Map<String, List<Map<String, dynamic>>>> searchAll(String term) async {
    final s = term.trim();
    if (s.isEmpty) return {};
    final work = await _db.from('work_items').select('id,code,title,status').or('title.ilike.%$s%,code.ilike.%$s%,description.ilike.%$s%').limit(30);
    final tasks = await _db.from('tasks').select('id,code,title,status').or('title.ilike.%$s%,code.ilike.%$s%,description.ilike.%$s%').limit(30);
    final messages = await _db.from('messages').select('id,code,content,message_type').ilike('content', '%$s%').limit(30);
    final activities = await _db.from('activities').select('id,type,description,date_time').ilike('description', '%$s%').limit(30);
    final comments = await _db.from('comments').select('id,parent_type,parent_id,content,created_at').ilike('content', '%$s%').limit(30);
    final attachments = await _db.from('attachments').select('id,parent_type,parent_id,file_name,storage_path').or('file_name.ilike.%$s%,storage_path.ilike.%$s%').limit(30);
    return {
      'work_items': List<Map<String, dynamic>>.from(work), 'tasks': List<Map<String, dynamic>>.from(tasks),
      'messages': List<Map<String, dynamic>>.from(messages), 'activities': List<Map<String, dynamic>>.from(activities),
      'comments': List<Map<String, dynamic>>.from(comments), 'attachments': List<Map<String, dynamic>>.from(attachments),
    };
  }

  Future<List<Map<String, dynamic>>> reportTasks() async => List<Map<String, dynamic>>.from(await _db.from('tasks').select('id,status,priority,score,created_at,completed_at'));
  Future<List<Map<String, dynamic>>> reportWorkItems() async => List<Map<String, dynamic>>.from(await _db.from('work_items').select('id,status,priority,created_at,completed_at'));
  Future<List<Map<String, dynamic>>> reportActivities() async => List<Map<String, dynamic>>.from(await _db.from('activities').select('id,type,date_time'));
  Future<List<Map<String, dynamic>>> reportDailyWorks() async => List<Map<String, dynamic>>.from(await _db.from('daily_works').select('id,status,work_date,user_id'));
  Future<List<Map<String, dynamic>>> reportApprovals() async => List<Map<String, dynamic>>.from(await _db.from('approvals').select('id,status,created_at,decision_at'));

  Future<void> createUser({required String username, required String fullName, required String password, required String role, required String departmentCode, String? jobTitle}) async {
    await _requireGm();
    final res = await _db.functions.invoke('create-user', body: {'username': username.trim().toLowerCase(), 'full_name': fullName.trim(), 'password': password, 'role': role, 'job_title': jobTitle, 'department_code': departmentCode});
    if (res.data is Map && (res.data as Map)['error'] != null) {
      final m = res.data as Map;
      throw Exception(m['details'] == null ? m['error'].toString() : '${m['error']}\n${m['details']}');
    }
  }

  Future<void> setUserActive(String id, bool active) async { await _requireGm(); await _db.from('profiles').update({'is_active': active}).eq('id', id); }
}
