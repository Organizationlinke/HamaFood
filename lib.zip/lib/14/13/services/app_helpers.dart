import 'package:flutter/material.dart';

String labelize(String value) => value.replaceAll('_', ' ').split(' ').map((p) => p.isEmpty ? p : '${p[0].toUpperCase()}${p.substring(1)}').join(' ');

String shortDate(DateTime? value) {
  if (value == null) return '—';
  final d = value.toLocal();
  return '${d.day.toString().padLeft(2,'0')}/${d.month.toString().padLeft(2,'0')}/${d.year}';
}

String dateTimeText(DateTime? value) {
  if (value == null) return '—';
  final d = value.toLocal();
  return '${shortDate(d)} ${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';
}

Color statusColor(String status) {
  switch (status) {
    case 'completed': return Colors.green;
    case 'overdue': case 'cancelled': return Colors.red;
    case 'in_progress': return Colors.blue;
    case 'waiting': case 'ready_for_completion': case 'pending': case 'need_more_info': return Colors.orange;
    case 'approved': return Colors.green;
    case 'rejected': return Colors.red;
    default: return Colors.grey;
  }
}

Color priorityColor(String priority) => priority == 'urgent' ? Colors.red : Colors.blueGrey;

class Ui {
  static void snack(BuildContext context, String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  static Future<bool?> confirm(BuildContext context, {required String title, required String message}) => showDialog<bool>(context: context, builder: (c) => AlertDialog(title: Text(title), content: Text(message), actions: [TextButton(onPressed: () => Navigator.pop(c,false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(c,true), child: const Text('Confirm'))]));
}
