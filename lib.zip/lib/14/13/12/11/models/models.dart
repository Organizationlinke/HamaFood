class Profile {
  final String id, fullName, username;
  final bool isActive;
  final String? jobTitle, departmentId;
  final String role;
  Profile({required this.id, required this.fullName, required this.username, this.jobTitle, this.departmentId, required this.role, this.isActive = true});
  factory Profile.fromMap(Map<String,dynamic> m) => Profile(id:m['id'], fullName:m['full_name'] ?? 'User', username:m['username'] ?? '', jobTitle:m['job_title'], departmentId:m['department_id'], role:m['role'] ?? 'manager', isActive:m['is_active'] ?? true);
}

class WorkItem {
  final String id,title,status,priority,category;
  final String? description, responsibleId;
  final DateTime? deadline;
  final DateTime createdAt;
  WorkItem({required this.id,required this.title,required this.status,required this.priority,required this.category,this.description,this.responsibleId,this.deadline,required this.createdAt});
  factory WorkItem.fromMap(Map<String,dynamic> m)=>WorkItem(id:m['id'],title:m['title'],status:m['status'],priority:m['priority'],category:m['category'],description:m['description'],responsibleId:m['responsible_id'],deadline:m['deadline']==null?null:DateTime.parse(m['deadline']),createdAt:DateTime.parse(m['created_at']));
}

class Task {
  final String id,title,status,priority;
  final String? description,workItemId;
  final DateTime? deadline;
  final bool evidenceRequired;
  final int? evaluation;
  Task({required this.id,required this.title,required this.status,required this.priority,this.description,this.workItemId,this.deadline,required this.evidenceRequired,this.evaluation});
  factory Task.fromMap(Map<String,dynamic> m)=>Task(id:m['id'],title:m['title'],status:m['status'],priority:m['priority'],description:m['description'],workItemId:m['work_item_id'],deadline:m['deadline']==null?null:DateTime.parse(m['deadline']),evidenceRequired:m['evidence_required']??false,evaluation:m['evaluation']);
}

class Activity {
  final String id,type,description;
  final DateTime occurredAt;
  final String? result,nextAction,withTo;
  Activity({required this.id,required this.type,required this.description,required this.occurredAt,this.result,this.nextAction,this.withTo});
  factory Activity.fromMap(Map<String,dynamic> m)=>Activity(id:m['id'],type:m['type'],description:m['description'],occurredAt:DateTime.parse(m['occurred_at']),result:m['result'],nextAction:m['next_action'],withTo:m['with_to']);
}
