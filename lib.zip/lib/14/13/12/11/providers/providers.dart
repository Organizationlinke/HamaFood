import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../services/repository.dart';

final repoProvider=Provider<AppRepository>((ref)=>AppRepository());
final profileProvider=FutureProvider<Profile?>((ref)=>ref.watch(repoProvider).myProfile());
final workItemsProvider=FutureProvider<List<WorkItem>>((ref)=>ref.watch(repoProvider).workItems());
final tasksProvider=FutureProvider<List<Task>>((ref)=>ref.watch(repoProvider).tasks());
final messagesProvider=FutureProvider<List<Map<String,dynamic>>>((ref)=>ref.watch(repoProvider).messages());
