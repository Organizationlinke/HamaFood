import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/supabase_client.dart';
import '../models/models.dart';

class AppRepository {
  Future<Profile?> myProfile() async {
    final uid=supabase.auth.currentUser?.id; if(uid==null)return null;
    final row=await supabase.from('profiles').select().eq('id',uid).maybeSingle();
    return row==null?null:Profile.fromMap(row);
  }

  Future<List<WorkItem>> workItems({String? status}) async {
    var q=supabase.from('work_items').select();
    if(status!=null) q=q.eq('status',status);
    final rows=await q.order('created_at',ascending:false);
    return rows.map<WorkItem>((m)=>WorkItem.fromMap(m)).toList();
  }

  Future<WorkItem> createWorkItem({required String title,String? description,required String category,required String priority,String? responsibleId,DateTime? deadline}) async {
    final row=await supabase.from('work_items').insert({'title':title,'description':description,'category':category,'priority':priority,'responsible_id':responsibleId,'deadline':deadline?.toIso8601String(),'creator_id':supabase.auth.currentUser!.id}).select().single();
    return WorkItem.fromMap(row);
  }

  Future<List<Task>> tasks({String? workItemId}) async {
    var q=supabase.from('tasks').select();
    if(workItemId!=null) q=q.eq('work_item_id',workItemId);
    final rows=await q.order('created_at',ascending:false);
    return rows.map<Task>((m)=>Task.fromMap(m)).toList();
  }

  Future<Task> createTask({required String title,String? description,String? workItemId,required String priority,DateTime? deadline,required String responsibleId}) async {
    final row=await supabase.from('tasks').insert({'title':title,'description':description,'work_item_id':workItemId,'priority':priority,'deadline':deadline?.toIso8601String(),'creator_id':supabase.auth.currentUser!.id}).select().single();
    await supabase.from('task_responsibles').insert({'task_id':row['id'],'user_id':responsibleId});
    return Task.fromMap(row);
  }

  Future<void> startTask(String id) async => supabase.from('tasks').update({'status':'in_progress'}).eq('id',id);
  Future<void> requestCompletion(String id) async => supabase.from('tasks').update({'status':'ready_for_completion','completion_requested_at':DateTime.now().toIso8601String()}).eq('id',id);
  Future<void> confirmTask(String id,int score,{String? comment}) async => supabase.from('tasks').update({'status':'completed','completed_at':DateTime.now().toIso8601String(),'completed_by':supabase.auth.currentUser!.id,'evaluation':score,'evaluation_comment':comment}).eq('id',id);

  Future<List<Activity>> activities(String workItemId) async {
    final rows=await supabase.from('activities').select().eq('work_item_id',workItemId).order('occurred_at',ascending:false);
    return rows.map<Activity>((m)=>Activity.fromMap(m)).toList();
  }
  Future<void> addActivity({required String workItemId,required String type,required String description,String? result,String? nextAction,String? withTo}) async {
    await supabase.from('activities').insert({'work_item_id':workItemId,'user_id':supabase.auth.currentUser!.id,'type':type,'description':description,'result':result,'next_action':nextAction,'with_to':withTo});
  }

  Future<List<Map<String,dynamic>>> messages() async {
    final rows=await supabase.from('messages').select('*, sender:profiles!messages_sender_id_fkey(full_name)').order('created_at',ascending:false);
    return List<Map<String,dynamic>>.from(rows);
  }
  Future<void> sendMessage(String body,String type) async {
    final row=await supabase.from('messages').insert({'sender_id':supabase.auth.currentUser!.id,'body':body,'type':type}).select().single();
    final users=await supabase.from('profiles').select('id').eq('is_active',true);
    await supabase.from('message_recipients').insert((users as List).where((u)=>u['id']!=supabase.auth.currentUser!.id).map((u)=>{'message_id':row['id'],'user_id':u['id']}).toList());
  }


  Future<List<Profile>> users() async {
    final rows = await supabase.from('profiles').select().order('full_name');
    return rows.map<Profile>((m) => Profile.fromMap(m)).toList();
  }

  Future<void> createUser({required String username, required String fullName, required String password, required String role, String? jobTitle, String? departmentId}) async {
    final res = await supabase.functions.invoke('create-user', body: {
      'username': username.trim().toLowerCase(),
      'full_name': fullName.trim(),
      'password': password,
      'role': role,
      'job_title': jobTitle,
      'department_id': departmentId,
    });
    if (res.data is Map && (res.data as Map)['error'] != null) {
      throw Exception((res.data as Map)['error']);
    }
  }

  Future<void> setUserActive(String userId, bool active) async {
    await supabase.from('profiles').update({'is_active': active}).eq('id', userId);
  }

  Future<int> unreadNotifications() async => await supabase.from('notifications').select('id').eq('user_id',supabase.auth.currentUser!.id).eq('is_read',false).count(CountOption.exact).then((r)=>r.count);
}
