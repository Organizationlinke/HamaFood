import 'package:supabase_flutter/supabase_flutter.dart';

class AppConfig {
  static const url = String.fromEnvironment('https://dqievbhmcafhsucwfewa.supabase.co');
  static const publishableKey = String.fromEnvironment('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRxaWV2YmhtY2FmaHN1Y3dmZXdhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgzMzEzNzMsImV4cCI6MjA5MzkwNzM3M30.mPlKlWjwO9TkhblH0BUVfv6LIH1BNPVqT7Dyw7l0HHw');
}

final supabase = Supabase.instance.client;
