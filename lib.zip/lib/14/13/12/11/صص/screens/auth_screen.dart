import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController(),
      pass = TextEditingController(),
      name = TextEditingController();
  bool signup = false, busy = false;
  String? error;
  Future<void> submit() async {
    setState(() => busy = true);
    try {
      if (signup) {
        await Supabase.instance.client.auth.signUp(
            email: email.text.trim(),
            password: pass.text,
            data: {'full_name': name.text.trim()});
      } else {
        await Supabase.instance.client.auth
            .signInWithPassword(email: email.text.trim(), password: pass.text);
      }
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      body: Center(
          child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Card(
                  margin: const EdgeInsets.all(24),
                  child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Text('Hama Work',
                            style: TextStyle(
                                fontSize: 32, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Text(
                            signup
                                ? 'Create your account'
                                : 'Internal Work & Communication',
                            textAlign: TextAlign.center),
                        const SizedBox(height: 28),
                        if (signup)
                          TextField(
                              controller: name,
                              decoration: const InputDecoration(
                                  labelText: 'Full name')),
                        if (signup) const SizedBox(height: 12),
                        TextField(
                            controller: email,
                            decoration:
                                const InputDecoration(labelText: 'Email'),
                            keyboardType: TextInputType.emailAddress),
                        const SizedBox(height: 12),
                        TextField(
                            controller: pass,
                            obscureText: true,
                            decoration:
                                const InputDecoration(labelText: 'Password')),
                        if (error != null)
                          Padding(
                              padding: const EdgeInsets.only(top: 12),
                              child: Text(error!,
                                  style: const TextStyle(color: Colors.red))),
                        const SizedBox(height: 20),
                        SizedBox(
                            width: double.infinity,
                            child: FilledButton(
                                onPressed: busy ? null : submit,
                                child: Text(busy
                                    ? 'Please wait'
                                    : signup
                                        ? 'Create account'
                                        : 'Sign in'))),
                        TextButton(
                            onPressed: () => setState(() => signup = !signup),
                            child: Text(signup
                                ? 'Already have an account? Sign in'
                                : 'Create first account'))
                      ]))))));
}
