import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/repository.dart';

class WorkItemDetailScreen extends ConsumerStatefulWidget {
  final WorkItem item;
  const WorkItemDetailScreen({super.key, required this.item});
  @override
  ConsumerState<WorkItemDetailScreen> createState() => _State();
}

class _State extends ConsumerState<WorkItemDetailScreen> {
  int tab = 0;
  final activity = TextEditingController();
  @override
  Widget build(BuildContext c) {
    final tasks = ref.watch(tasksProvider);
    final acts = FutureProvider.autoDispose(
        (ref) => ref.read(repoProvider).activities(widget.item.id));
    return Scaffold(
        appBar: AppBar(title: Text(widget.item.title)),
        body: Column(children: [
          Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                Chip(label: Text(widget.item.status)),
                const SizedBox(width: 8),
                Chip(label: Text(widget.item.priority)),
                const Spacer(),
                Text(widget.item.category)
              ])),
          const Divider(height: 1),
          NavigationBar(
              selectedIndex: tab,
              onDestinationSelected: (v) => setState(() => tab = v),
              destinations: const [
                NavigationDestination(
                    icon: Icon(Icons.info_outline), label: 'Overview'),
                NavigationDestination(
                    icon: Icon(Icons.task_alt), label: 'Tasks'),
                NavigationDestination(
                    icon: Icon(Icons.timeline), label: 'Timeline')
              ]),
          Expanded(
              child: tab == 0
                  ? _overview()
                  : tab == 1
                      ? tasks.when(
                          data: (ts) => ListView(children: [
                                ...ts
                                    .where(
                                        (t) => t.workItemId == widget.item.id)
                                    .map((t) => ListTile(
                                        title: Text(t.title),
                                        subtitle: Text(t.status),
                                        trailing: Text(t.priority))),
                                ListTile(
                                    leading: const Icon(Icons.add),
                                    title: const Text('Create Task'),
                                    onTap: () => _newTask())
                              ]),
                          loading: () =>
                              const Center(child: CircularProgressIndicator()),
                          error: (e, st) => Text('$e'))
                      : Consumer(builder: (c, ref, _) {
                          final a = ref.watch(acts);
                          return a.when(
                              data: (xs) => ListView(
                                      padding: const EdgeInsets.all(16),
                                      children: [
                                        ...xs.map((x) => Card(
                                            child: ListTile(
                                                title: Text(x.type),
                                                subtitle: Text(x.description),
                                                leading: const Icon(
                                                    Icons.event_note)))),
                                        const SizedBox(height: 60)
                                      ]),
                              loading: () => const Center(
                                  child: CircularProgressIndicator()),
                              error: (e, st) => Text('$e'));
                        }))
        ]));
  }

  Widget _overview() => ListView(padding: const EdgeInsets.all(20), children: [
        Text(widget.item.description ?? 'No description'),
        const SizedBox(height: 20),
        FilledButton.icon(
            onPressed: _newActivity,
            icon: const Icon(Icons.add),
            label: const Text('Add Activity'))
      ]);
  Future<void> _newActivity() async {
    final text = TextEditingController();
    await showDialog(
        context: context,
        builder: (c) => AlertDialog(
                title: const Text('Add Activity'),
                content: TextField(
                    controller: text,
                    maxLines: 4,
                    decoration:
                        const InputDecoration(labelText: 'What happened?')),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(c),
                      child: const Text('Cancel')),
                  FilledButton(
                      onPressed: () async {
                        await ref.read(repoProvider).addActivity(
                            workItemId: widget.item.id,
                            type: 'note',
                            description: text.text.trim());
                        if (mounted) Navigator.pop(c);
                        setState(() {});
                      },
                      child: const Text('Save'))
                ]));
  }

  Future<void> _newTask() async {
    final title = TextEditingController();
    final uid = ref.read(profileProvider).valueOrNull?.id;
    if (uid == null) return;
    await showDialog(
        context: context,
        builder: (c) => AlertDialog(
                title: const Text('New Task'),
                content: TextField(
                    controller: title,
                    decoration: const InputDecoration(labelText: 'Task')),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(c),
                      child: const Text('Cancel')),
                  FilledButton(
                      onPressed: () async {
                        await ref.read(repoProvider).createTask(
                            title: title.text.trim(),
                            workItemId: widget.item.id,
                            priority: 'normal',
                            responsibleId: uid);
                        ref.invalidate(tasksProvider);
                        if (mounted) Navigator.pop(c);
                      },
                      child: const Text('Create'))
                ]));
  }
}
