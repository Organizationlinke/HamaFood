import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../services/repository.dart';

class TasksScreen extends ConsumerWidget {
  const TasksScreen({super.key});
  @override
  Widget build(BuildContext c, WidgetRef ref) {
    final data = ref.watch(tasksProvider);
    return Scaffold(
        appBar: AppBar(title: const Text('Tasks')),
        body: data.when(
            data: (tasks) => ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: tasks.length,
                itemBuilder: (c, i) {
                  final t = tasks[i];
                  return Card(
                      child: ListTile(
                          title: Text(t.title),
                          subtitle: Text('${t.status} • ${t.priority}'),
                          trailing: PopupMenuButton<String>(
                              onSelected: (v) async {
                                final r = ref.read(repoProvider);
                                if (v == 'start') await r.startTask(t.id);
                                if (v == 'request')
                                  await r.requestCompletion(t.id);
                                if (v == 'confirm') await _confirm(c, r, t.id);
                                ref.invalidate(tasksProvider);
                              },
                              itemBuilder: (_) => [
                                    if (t.status == 'not_started')
                                      const PopupMenuItem(
                                          value: 'start', child: Text('Start')),
                                    if (t.status == 'in_progress')
                                      const PopupMenuItem(
                                          value: 'request',
                                          child: Text('Request completion')),
                                    if (t.status == 'ready_for_completion')
                                      const PopupMenuItem(
                                          value: 'confirm',
                                          child: Text('Confirm & evaluate'))
                                  ])));
                }),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, st) => Center(child: Text('$e'))));
  }

  Future<void> _confirm(BuildContext c, AppRepository r, String id) async {
    int score = 8;
    await showDialog(
        context: c,
        builder: (x) => AlertDialog(
                title: const Text('Evaluate Task'),
                content: StatefulBuilder(
                    builder: (c, set) =>
                        Column(mainAxisSize: MainAxisSize.min, children: [
                          Text('Score: $score / 10'),
                          Slider(
                              value: score.toDouble(),
                              min: 1,
                              max: 10,
                              divisions: 9,
                              onChanged: (v) => set(() => score = v.round()))
                        ])),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(x),
                      child: const Text('Cancel')),
                  FilledButton(
                      onPressed: () {
                        r.confirmTask(id, score);
                        Navigator.pop(x);
                      },
                      child: const Text('Complete'))
                ]));
  }
}
