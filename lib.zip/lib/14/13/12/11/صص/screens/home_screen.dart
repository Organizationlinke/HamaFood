// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:go_router/go_router.dart';
// import '../providers/providers.dart';
// import '../core/supabase_client.dart';

// class HomeScreen extends ConsumerWidget{const HomeScreen({super.key});
// @override Widget build(BuildContext c,WidgetRef ref){final profile=ref.watch(profileProvider);final wi=ref.watch(workItemsProvider);final tasks=ref.watch(tasksProvider);return Scaffold(appBar:AppBar(title:const Text('Hama Work'),actions:[IconButton(onPressed:()=>supabase.auth.signOut(),icon:const Icon(Icons.logout))]),drawer:Drawer(child:ListView(children:[const DrawerHeader(child:Text('Hama Work',style:TextStyle(fontSize:28))),ListTile(leading:const Icon(Icons.dashboard),title:const Text('Home'),onTap:()=>c.pop()),ListTile(leading:const Icon(Icons.folder),title:const Text('Work Items'),onTap:()=>c.push('/work-items')),ListTile(leading:const Icon(Icons.task_alt),title:const Text('My / Team Tasks'),onTap:()=>c.push('/tasks')),ListTile(leading:const Icon(Icons.chat),title:const Text('Messages'),onTap:()=>c.push('/messages'))])),body:RefreshIndicator(onRefresh:()async{ref.invalidate(workItemsProvider);ref.invalidate(tasksProvider);},child:ListView(padding:const EdgeInsets.all(20),children:[profile.when(data:(p)=>Text('Good morning, ${p?.fullName ?? 'User'}',style:Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),loading:()=>const LinearProgressIndicator(),error:(e,st)=>const Text('Profile error')),const SizedBox(height:20),Row(children:[Expanded(child:_stat(c,'Work Items',wi.valueOrNull?.length??0,Icons.folder_open,()=>c.push('/work-items'))),const SizedBox(width:12),Expanded(child:_stat(c,'Tasks',tasks.valueOrNull?.length??0,Icons.task_alt,()=>c.push('/tasks')))]),const SizedBox(height:24),Card(child:ListTile(leading:const Icon(Icons.warning_amber),title:const Text('Needs Your Attention'),subtitle:Text('${tasks.valueOrNull?.where((t)=>t.status=='overdue').length??0} overdue tasks'),onTap:()=>c.push('/tasks'))),const SizedBox(height:12),Card(child:ListTile(leading:const Icon(Icons.chat_bubble_outline),title:const Text('Communication'),subtitle:const Text('Open Messages'),onTap:()=>c.push('/messages')))]));}
// Widget _stat(BuildContext c,String t,int n,IconData i,VoidCallback onTap)=>Card(child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(12),child:Padding(padding:const EdgeInsets.all(18),child:Row(children:[Icon(i,size:30),const SizedBox(width:14),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('$n',style:const TextStyle(fontSize:28,fontWeight:FontWeight.bold)),Text(t)])]))));}
// }
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../providers/providers.dart';
import '../core/supabase_client.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext c, WidgetRef ref) {
    final profile = ref.watch(profileProvider);
    final wi = ref.watch(workItemsProvider);
    final tasks = ref.watch(tasksProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hama Work'),
        actions: [
          IconButton(
            onPressed: () => supabase.auth.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              child: Text('Hama Work', style: TextStyle(fontSize: 28)),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard),
              title: const Text('Home'),
              onTap: () => c.pop(),
            ),
            ListTile(
              leading: const Icon(Icons.folder),
              title: const Text('Work Items'),
              onTap: () => c.push('/work-items'),
            ),
            ListTile(
              leading: const Icon(Icons.task_alt),
              title: const Text('My / Team Tasks'),
              onTap: () => c.push('/tasks'),
            ),
            ListTile(
              leading: const Icon(Icons.chat),
              title: const Text('Messages'),
              onTap: () => c.push('/messages'),
            ),
          ],
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(workItemsProvider);
          ref.invalidate(tasksProvider);
          await ref.read(workItemsProvider.future);
          await ref.read(tasksProvider.future);
        },
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            profile.when(
              data: (p) => Text(
                'Good morning, ${p?.fullName ?? 'User'}',
                style: Theme.of(c).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              loading: () => const LinearProgressIndicator(),
              error: (e, st) => const Text('Profile error'),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: _stat(
                    c,
                    'Work Items',
                    wi.valueOrNull?.length ?? 0,
                    Icons.folder_open,
                    () => c.push('/work-items'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _stat(
                    c,
                    'Tasks',
                    tasks.valueOrNull?.length ?? 0,
                    Icons.task_alt,
                    () => c.push('/tasks'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Card(
              child: ListTile(
                leading: const Icon(Icons.warning_amber),
                title: const Text('Needs Your Attention'),
                subtitle: Text(
                  '${tasks.valueOrNull?.where((t) => t.status == 'overdue').length ?? 0} overdue tasks',
                ),
                onTap: () => c.push('/tasks'),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.chat_bubble_outline),
                title: const Text('Communication'),
                subtitle: const Text('Open Messages'),
                onTap: () => c.push('/messages'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(
    BuildContext c,
    String t,
    int n,
    IconData i,
    VoidCallback onTap,
  ) =>
      Card(
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                Icon(i, size: 30),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$n',
                      style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(t),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
}