// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import '../providers/providers.dart';
// import '../services/repository.dart';
// import 'work_item_detail_screen.dart';

// class WorkItemsScreen extends ConsumerWidget{const WorkItemsScreen({super.key});
// @override Widget build(BuildContext c,WidgetRef ref){final data=ref.watch(workItemsProvider);return Scaffold(appBar:AppBar(title:const Text('Work Items')),floatingActionButton:FloatingActionButton.extended(onPressed:()=>showDialog(context:c,builder:(_)=>const CreateWorkItemDialog()),icon:const Icon(Icons.add),label:const Text('New Work Item')),body:data.when(data:(items)=>RefreshIndicator(onRefresh:()async=>ref.refresh(workItemsProvider.future),child:ListView.builder(padding:const EdgeInsets.all(16),itemCount:items.length,itemBuilder:(c,i){final w=items[i];return Card(child:ListTile(title:Text(w.title,style:const TextStyle(fontWeight:FontWeight.w600)),subtitle:Text('${w.category} • ${w.status} • ${w.priority}'),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>WorkItemDetailScreen(item:w))));})),loading:()=>const Center(child:CircularProgressIndicator()),error:(e,st)=>Center(child:Text(e.toString())));}
// }
// class CreateWorkItemDialog extends ConsumerStatefulWidget{const CreateWorkItemDialog({super.key});@override ConsumerState<CreateWorkItemDialog> createState()=>_CreateState();}
// class _CreateState extends ConsumerState<CreateWorkItemDialog>{final title=TextEditingController(),desc=TextEditingController();String category='Other',priority='normal';bool busy=false;
// Future<void> save()async{if(title.text.trim().isEmpty)return;setState(()=>busy=true);try{await ref.read(repoProvider).createWorkItem(title:title.text.trim(),description:desc.text.trim(),category:category,priority:priority);ref.invalidate(workItemsProvider);if(mounted)Navigator.pop(context);}finally{if(mounted)setState(()=>busy=false);}}
// @override Widget build(BuildContext c)=>AlertDialog(title:const Text('New Work Item'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'Title')),TextField(controller:desc,decoration:const InputDecoration(labelText:'Description'),maxLines:3),DropdownButtonFormField(value:category,items:['Other','Maintenance','Production','Cold Store','Purchasing','Administration','Supplier','Quality'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>category=v!),decoration:const InputDecoration(labelText:'Category')),DropdownButtonFormField(value:priority,items:['normal','urgent'].map((x)=>DropdownMenuItem(value:x,child:Text(x=='normal'?'Normal':'Urgent'))).toList(),onChanged:(v)=>setState(()=>priority=v!),decoration:const InputDecoration(labelText:'Priority'))])),actions:[TextButton(onPressed:busy?null:()=>Navigator.pop(c),child:const Text('Cancel')),FilledButton(onPressed:busy?null:save,child:Text(busy?'Saving':'Create'))]);}
// }
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../services/repository.dart';
import 'work_item_detail_screen.dart';

class WorkItemsScreen extends ConsumerWidget {
  const WorkItemsScreen({super.key});
  @override
  Widget build(BuildContext c, WidgetRef ref) {
    final data = ref.watch(workItemsProvider);
    return Scaffold(
        appBar: AppBar(title: const Text('Work Items')),
        floatingActionButton: FloatingActionButton.extended(
            onPressed: () => showDialog(
                context: c, builder: (_) => const CreateWorkItemDialog()),
            icon: const Icon(Icons.add),
            label: const Text('New Work Item')),
        body: data.when(
            data: (items) => RefreshIndicator(
                onRefresh: () async {
                  ref.refresh(workItemsProvider);
                },
                child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: items.length,
                    itemBuilder: (c, i) {
                      final w = items[i];
                      return Card(
                          child: ListTile(
                              title: Text(w.title,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w600)),
                              subtitle: Text(
                                  '${w.category} • ${w.status} • ${w.priority}'),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () => Navigator.push(
                                  c,
                                  MaterialPageRoute(
                                      builder: (_) =>
                                          WorkItemDetailScreen(item: w)))));
                    })),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, st) => Center(child: Text(e.toString()))));
  }
}

class CreateWorkItemDialog extends ConsumerStatefulWidget {
  const CreateWorkItemDialog({super.key});
  @override
  ConsumerState<CreateWorkItemDialog> createState() => _CreateState();
}

class _CreateState extends ConsumerState<CreateWorkItemDialog> {
  final title = TextEditingController(), desc = TextEditingController();
  String category = 'Other', priority = 'normal';
  bool busy = false;
  Future<void> save() async {
    if (title.text.trim().isEmpty) return;
    setState(() => busy = true);
    try {
      await ref.read(repoProvider).createWorkItem(
          title: title.text.trim(),
          description: desc.text.trim(),
          category: category,
          priority: priority);
      ref.invalidate(workItemsProvider);
      if (mounted) Navigator.pop(context);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext c) => AlertDialog(
          title: const Text('New Work Item'),
          content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
                controller: title,
                decoration: const InputDecoration(labelText: 'Title')),
            TextField(
                controller: desc,
                decoration: const InputDecoration(labelText: 'Description'),
                maxLines: 3),
            DropdownButtonFormField(
                value: category,
                items: [
                  'Other',
                  'Maintenance',
                  'Production',
                  'Cold Store',
                  'Purchasing',
                  'Administration',
                  'Supplier',
                  'Quality'
                ]
                    .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                    .toList(),
                onChanged: (v) => setState(() => category = v!),
                decoration: const InputDecoration(labelText: 'Category')),
            DropdownButtonFormField(
                value: priority,
                items: ['normal', 'urgent']
                    .map((x) => DropdownMenuItem(
                        value: x,
                        child: Text(x == 'normal' ? 'Normal' : 'Urgent')))
                    .toList(),
                onChanged: (v) => setState(() => priority = v!),
                decoration: const InputDecoration(labelText: 'Priority'))
          ])),
          actions: [
            TextButton(
                onPressed: busy ? null : () => Navigator.pop(c),
                child: const Text('Cancel')),
            FilledButton(
                onPressed: busy ? null : save,
                child: Text(busy ? 'Saving' : 'Create'))
          ]);
}
