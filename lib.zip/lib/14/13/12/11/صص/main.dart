import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/supabase_client.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/work_items_screen.dart';
import 'screens/tasks_screen.dart';
import 'screens/messages_screen.dart';

Future<void> main() async {
  print("tets00");
  WidgetsFlutterBinding.ensureInitialized();
  print("tets0");
  // if (AppConfig.url.isEmpty || AppConfig.publishableKey.isEmpty) {
  //   runApp(const ProviderScope(child: ConfigErrorApp()));
  //   return;
  // }
  print("tets1");
  await Supabase.initialize(
    
      url: AppConfig.url, publishableKey: AppConfig.publishableKey);
  runApp(const ProviderScope(child: HamaWorkApp()));
  print("tets2");
}

class ConfigErrorApp extends StatelessWidget {
  const ConfigErrorApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
      home: Scaffold(
          body: Center(
              child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                      'Configure SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY with --dart-define.')))));
}

class HamaWorkApp extends StatefulWidget {
  const HamaWorkApp({super.key});
  @override
  State<HamaWorkApp> createState() => _HamaWorkAppState();
}

class _HamaWorkAppState extends State<HamaWorkApp> {
  late final GoRouter router = GoRouter(
      refreshListenable: GoRouterRefreshStream(
          Supabase.instance.client.auth.onAuthStateChange),
      redirect: (context, state) {
        final logged = Supabase.instance.client.auth.currentSession != null;
        final login = state.matchedLocation == '/login';
        if (!logged && !login) return '/login';
        if (logged && login) return '/';
        return null;
      },
      routes: [
        GoRoute(path: '/login', builder: (c, s) => const AuthScreen()),
        GoRoute(path: '/', builder: (c, s) => const HomeScreen()),
        GoRoute(
            path: '/work-items', builder: (c, s) => const WorkItemsScreen()),
        GoRoute(path: '/tasks', builder: (c, s) => const TasksScreen()),
        GoRoute(path: '/messages', builder: (c, s) => const MessagesScreen()),
      ]);
  @override
  Widget build(BuildContext context) => MaterialApp.router(
      title: 'Hama Work',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: Colors.indigo,
          scaffoldBackgroundColor: const Color(0xfff7f8fb)),
      routerConfig: router);
}

class GoRouterRefreshStream extends ChangeNotifier {
  GoRouterRefreshStream(Stream<dynamic> stream) {
    _sub = stream.asBroadcastStream().listen((_) => notifyListeners());
  }
  late final dynamic _sub;
  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }
}
