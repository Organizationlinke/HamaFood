import 'package:supabase_flutter/supabase_flutter.dart';

class AppConfig {
  static const url = String.fromEnvironment('SUPABASE_URL');
  static const publishableKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  // This is only used to map a username to the hidden Supabase Auth identity.
  // Use a real domain controlled by Hama Holding. No email is shown to users.
  static const authDomain = String.fromEnvironment(
    'HAMA_AUTH_DOMAIN',
    defaultValue: 'auth.hamaholding.com',
  );
}

final supabase = Supabase.instance.client;
