import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/supabase_client.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final username = TextEditingController();
  final pass = TextEditingController();
  bool busy = false;
  String? error;

  String get hiddenEmail => '${username.text.trim().toLowerCase()}@${AppConfig.authDomain}';

  Future<void> submit() async {
    final u = username.text.trim().toLowerCase();
    if (u.isEmpty || pass.text.isEmpty) {
      setState(() => error = 'اكتب اسم المستخدم وكلمة المرور.');
      return;
    }
    if (!RegExp(r'^[a-z0-9._-]{3,40}$').hasMatch(u)) {
      setState(() => error = 'اسم المستخدم يجب أن يحتوي على حروف إنجليزية أو أرقام أو . _ - فقط.');
      return;
    }
    setState(() { busy = true; error = null; });
    try {
      await Supabase.instance.client.auth.signInWithPassword(
        email: hiddenEmail,
        password: pass.text,
      );
    } on AuthException catch (e) {
      setState(() => error = 'اسم المستخدم أو كلمة المرور غير صحيحة.');
      debugPrint('Auth error: ${e.message}');
    } catch (e) {
      setState(() => error = 'تعذر تسجيل الدخول. تحقق من اتصال النظام.');
      debugPrint('Login error: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    username.dispose();
    pass.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Card(
          margin: const EdgeInsets.all(24),
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Hama Work', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Internal Work & Communication', textAlign: TextAlign.center),
                const SizedBox(height: 28),
                TextField(
                  controller: username,
                  autofocus: true,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(labelText: 'Username', prefixIcon: Icon(Icons.person_outline)),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: pass,
                  obscureText: true,
                  onSubmitted: (_) => submit(),
                  decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline)),
                ),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 14),
                    child: Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red)),
                  ),
                const SizedBox(height: 22),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: busy ? null : submit,
                    child: Text(busy ? 'Please wait...' : 'Sign in'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}
