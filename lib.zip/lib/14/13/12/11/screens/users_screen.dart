// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import '../models/models.dart';
// import '../providers/providers.dart';

// final usersProvider = FutureProvider<List<Profile>>((ref) => ref.watch(repoProvider).users());

// class UsersScreen extends ConsumerWidget {
//   const UsersScreen({super.key});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final profile = ref.watch(profileProvider);
//     if (profile.valueOrNull?.role != 'admin') {
//       return Scaffold(appBar: AppBar(title: const Text('Users')), body: const Center(child: Text('Admin access required.')));
//     }
//     final users = ref.watch(usersProvider);
//     return Scaffold(
//       appBar: AppBar(title: const Text('Users')),
//       floatingActionButton: FloatingActionButton.extended(
//         onPressed: () => _showCreateUser(context, ref),
//         icon: const Icon(Icons.person_add),
//         label: const Text('New User'),
//       ),
//       body: users.when(
//         loading: () => const Center(child: CircularProgressIndicator()),
//         error: (e, _) => Center(child: Text('Error: $e')),
//         data: (items) => ListView.separated(
//           padding: const EdgeInsets.all(16),
//           itemCount: items.length,
//           separatorBuilder: (_, __) => const Divider(),
//           itemBuilder: (_, i) {
//             final u = items[i];
//             return ListTile(
//               leading: CircleAvatar(child: Text(u.fullName.isEmpty ? '?' : u.fullName[0].toUpperCase())),
//               title: Text(u.fullName),
//               subtitle: Text('@${u.username} • ${u.role}${u.jobTitle == null ? '' : ' • ${u.jobTitle}'}'),
//               trailing: Switch(
//                 value: u.isActive,
//                 onChanged: (v) async {
//                   await ref.read(repoProvider).setUserActive(u.id, v);
//                   ref.invalidate(usersProvider);
//                 },
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }

//   Future<void> _showCreateUser(BuildContext context, WidgetRef ref) async {
//     final username = TextEditingController();
//     final fullName = TextEditingController();
//     final password = TextEditingController();
//     final jobTitle = TextEditingController();
//     String role = 'manager';
//     bool busy = false;

//     await showDialog(
//       context: context,
//       builder: (dialogContext) => StatefulBuilder(
//         builder: (context, setState) => AlertDialog(
//           title: const Text('Create user'),
//           content: SingleChildScrollView(
//             child: Column(mainAxisSize: MainAxisSize.min, children: [
//               TextField(controller: username, decoration: const InputDecoration(labelText: 'Username')),
//               TextField(controller: fullName, decoration: const InputDecoration(labelText: 'Full name')),
//               TextField(controller: jobTitle, decoration: const InputDecoration(labelText: 'Job title')),
//               TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
//               const SizedBox(height: 12),
//               DropdownButtonFormField<String>(
//                 value: role,
//                 items: const [
//                   DropdownMenuItem(value: 'manager', child: Text('Manager')),
//                   DropdownMenuItem(value: 'employee', child: Text('Employee')),
//                   DropdownMenuItem(value: 'admin', child: Text('Admin')),
//                 ],
//                 onChanged: (v) => setState(() => role = v ?? 'manager'),
//                 decoration: const InputDecoration(labelText: 'Role'),
//               ),
//             ]),
//           ),
//           actions: [
//             TextButton(onPressed: busy ? null : () => Navigator.pop(dialogContext), child: const Text('Cancel')),
//             FilledButton(
//               onPressed: busy ? null : () async {
//                 setState(() => busy = true);
//                 try {
//                   await ref.read(repoProvider).createUser(username: username.text, fullName: fullName.text, password: password.text, role: role, jobTitle: jobTitle.text.isEmpty ? null : jobTitle.text);
//                   if (context.mounted) Navigator.pop(dialogContext);
//                   ref.invalidate(usersProvider);
//                   if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('User created')));
//                 } catch (e) {
//                   if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
//                 } finally {
//                   if (context.mounted) setState(() => busy = false);
//                 }
//               },
//               child: Text(busy ? 'Creating...' : 'Create'),
//             ),
//           ],
//         ),
//       ),
//     );
//     username.dispose(); fullName.dispose(); password.dispose(); jobTitle.dispose();
//   }
// }
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/models.dart';
import '../providers/providers.dart';

final usersProvider =
    FutureProvider<List<Profile>>((ref) => ref.watch(repoProvider).users());

class UsersScreen extends ConsumerWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider);

    if (profile.valueOrNull?.role != 'admin') {
      return Scaffold(
        appBar: AppBar(title: const Text('Users')),
        body: const Center(
          child: Text('Admin access required.'),
        ),
      );
    }

    final users = ref.watch(usersProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Users'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateUser(context, ref),
        icon: const Icon(Icons.person_add),
        label: const Text('New User'),
      ),
      body: users.when(
        loading: () => const Center(
          child: CircularProgressIndicator(),
        ),
        error: (e, _) => Center(
          child: Text('Error: $e'),
        ),
        data: (items) => ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: items.length,
          separatorBuilder: (_, __) => const Divider(),
          itemBuilder: (_, i) {
            final u = items[i];

            return ListTile(
              leading: CircleAvatar(
                child: Text(
                  u.fullName.isEmpty
                      ? '?'
                      : u.fullName[0].toUpperCase(),
                ),
              ),
              title: Text(u.fullName),
              subtitle: Text(
                '@${u.username} • ${u.role}'
                '${u.jobTitle == null ? '' : ' • ${u.jobTitle}'}',
              ),
              trailing: Switch(
                value: u.isActive,
                onChanged: (v) async {
                  await ref
                      .read(repoProvider)
                      .setUserActive(u.id, v);

                  ref.invalidate(usersProvider);
                },
              ),
            );
          },
        ),
      ),
    );
  }

  Future<void> _showCreateUser(
    BuildContext parentContext,
    WidgetRef ref,
  ) async {
    final username = TextEditingController();
    final fullName = TextEditingController();
    final password = TextEditingController();
    final jobTitle = TextEditingController();

    String role = 'manager';
    bool busy = false;

    try {
      await showDialog(
        context: parentContext,
        builder: (dialogContext) {
          return StatefulBuilder(
            builder: (dialogContext, setState) {
              return AlertDialog(
                title: const Text('Create user'),

                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        controller: username,
                        decoration: const InputDecoration(
                          labelText: 'Username',
                        ),
                      ),

                      TextField(
                        controller: fullName,
                        decoration: const InputDecoration(
                          labelText: 'Full name',
                        ),
                      ),

                      TextField(
                        controller: jobTitle,
                        decoration: const InputDecoration(
                          labelText: 'Job title',
                        ),
                      ),

                      TextField(
                        controller: password,
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: 'Password',
                        ),
                      ),

                      const SizedBox(height: 12),

                      DropdownButtonFormField<String>(
                        value: role,
                        items: const [
                          DropdownMenuItem(
                            value: 'manager',
                            child: Text('Manager'),
                          ),
                          DropdownMenuItem(
                            value: 'employee',
                            child: Text('Employee'),
                          ),
                          DropdownMenuItem(
                            value: 'admin',
                            child: Text('Admin'),
                          ),
                        ],
                        onChanged: busy
                            ? null
                            : (v) {
                                setState(() {
                                  role = v ?? 'manager';
                                });
                              },
                        decoration: const InputDecoration(
                          labelText: 'Role',
                        ),
                      ),
                    ],
                  ),
                ),

                actions: [
                  TextButton(
                    onPressed: busy
                        ? null
                        : () {
                            Navigator.of(dialogContext).pop();
                          },
                    child: const Text('Cancel'),
                  ),

                  FilledButton(
                    onPressed: busy
                        ? null
                        : () async {
                            setState(() {
                              busy = true;
                            });

                            try {
                              await ref
                                  .read(repoProvider)
                                  .createUser(
                                    username: username.text.trim(),
                                    fullName: fullName.text.trim(),
                                    password: password.text,
                                    role: role,
                                    jobTitle:
                                        jobTitle.text.trim().isEmpty
                                            ? null
                                            : jobTitle.text.trim(),
                                  );

                              // Refresh users list
                              ref.invalidate(usersProvider);

                              // Close dialog
                              if (dialogContext.mounted) {
                                Navigator.of(dialogContext).pop();
                              }

                              // Show message using the PAGE context,
                              // not the dialog context.
                              if (parentContext.mounted) {
                                ScaffoldMessenger.of(parentContext)
                                    .showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      'User created successfully',
                                    ),
                                  ),
                                );
                              }
                            } catch (e) {
                              if (dialogContext.mounted) {
                                setState(() {
                                  busy = false;
                                });
                              }

                              if (parentContext.mounted) {
                                ScaffoldMessenger.of(parentContext)
                                    .showSnackBar(
                                  SnackBar(
                                    content: Text(e.toString()),
                                  ),
                                );
                              }
                            }
                          },
                    child: Text(
                      busy ? 'Creating...' : 'Create',
                    ),
                  ),
                ],
              );
            },
          );
        },
      );
    } finally {
      username.dispose();
      fullName.dispose();
      password.dispose();
      jobTitle.dispose();
    }
  }
}