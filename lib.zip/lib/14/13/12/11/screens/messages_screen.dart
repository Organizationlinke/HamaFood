// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import '../providers/providers.dart';
// import '../services/repository.dart';

// class MessagesScreen extends ConsumerStatefulWidget{const MessagesScreen({super.key});@override ConsumerState<MessagesScreen> createState()=>_State();}
// class _State extends ConsumerState<MessagesScreen>{final controller=TextEditingController();String type='information';
// @override Widget build(BuildContext c){final data=ref.watch(messagesProvider);return Scaffold(appBar:AppBar(title:const Text('Messages')),body:Column(children:[Expanded(child:data.when(data:(rows)=>ListView.builder(reverse:false,itemCount:rows.length,itemBuilder:(c,i){final m=rows[i];return ListTile(title:Text(m['sender']?['full_name']??'User'),subtitle:Text(m['body']),leading:CircleAvatar(child:Text((m['sender']?['full_name']??'U')[0])),trailing:Text(m['type'])),loading:()=>const Center(child:CircularProgressIndicator()),error:(e,st)=>Text('$e'))),SafeArea(child:Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:TextField(controller:controller,decoration:const InputDecoration(hintText:'Write a message...',border:OutlineInputBorder()))),IconButton(onPressed:()async{if(controller.text.trim().isEmpty)return;await ref.read(repoProvider).sendMessage(controller.text.trim(),type);controller.clear();ref.invalidate(messagesProvider);},icon:const Icon(Icons.send))])))]));}
// }
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../services/repository.dart';

class MessagesScreen extends ConsumerStatefulWidget{const MessagesScreen({super.key});@override ConsumerState<MessagesScreen> createState()=>_State();}
class _State extends ConsumerState<MessagesScreen>{final controller=TextEditingController();String type='information';
@override Widget build(BuildContext c){final data=ref.watch(messagesProvider);return Scaffold(appBar:AppBar(title:const Text('Messages')),body:Column(children:[Expanded(child:data.when(data:(rows)=>ListView.builder(reverse:false,itemCount:rows.length,itemBuilder:(c,i){final m=rows[i];return ListTile(title:Text(m['sender']?['full_name']??'User'),subtitle:Text(m['body']),leading:CircleAvatar(child:Text((m['sender']?['full_name']??'U')[0])),trailing:Text(m['type']));}),loading:()=>const Center(child:CircularProgressIndicator()),error:(e,st)=>Text('$e'))),SafeArea(child:Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:TextField(controller:controller,decoration:const InputDecoration(hintText:'Write a message...',border:OutlineInputBorder()))),IconButton(onPressed:()async{if(controller.text.trim().isEmpty)return;await ref.read(repoProvider).sendMessage(controller.text.trim(),type);controller.clear();ref.invalidate(messagesProvider);},icon:const Icon(Icons.send))])))]));}
}