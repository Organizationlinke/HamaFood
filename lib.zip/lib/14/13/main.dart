import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/supabase_client.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/work_items_screen.dart';
import 'screens/work_item_detail_screen.dart';
import 'screens/tasks_screen.dart';
import 'screens/task_detail_screen.dart';
import 'screens/messages_screen.dart';
import 'screens/message_detail_screen.dart';
import 'screens/daily_work_screen.dart';
import 'screens/activities_screen.dart';
import 'screens/approvals_screen.dart';
import 'screens/notifications_screen.dart';
import 'screens/users_screen.dart';
import 'screens/search_screen.dart';
import 'screens/reports_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (!AppConfig.configured) {
    runApp(const ProviderScope(child: ConfigErrorApp()));
    return;
  }
  await Supabase.initialize(
      url: AppConfig.url, publishableKey: AppConfig.publishableKey);
  runApp(const ProviderScope(child: HamaWorkApp()));
}

class ConfigErrorApp extends StatelessWidget {
  const ConfigErrorApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const Scaffold(
          body: Center(
              child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                      'Missing SUPABASE_URL / SUPABASE_PUBLISHABLE_KEY dart-defines.',
                      textAlign: TextAlign.center)))));
}

class HamaWorkApp extends StatefulWidget {
  const HamaWorkApp({super.key});
  @override
  State<HamaWorkApp> createState() => _HamaWorkAppState();
}

class _HamaWorkAppState extends State<HamaWorkApp> {
  late final GoRouter router = GoRouter(
    refreshListenable:
        GoRouterRefreshStream(Supabase.instance.client.auth.onAuthStateChange),
    redirect: (context, state) {
      final logged = Supabase.instance.client.auth.currentSession != null;
      final login = state.matchedLocation == '/login';
      if (!logged && !login) return '/login';
      if (logged && login) return '/';
      return null;
    },
    routes: [
      GoRoute(path: '/login', builder: (c, s) => const AuthScreen()),
      GoRoute(path: '/', builder: (c, s) => const HomeScreen()),
      GoRoute(path: '/work-items', builder: (c, s) => const WorkItemsScreen()),
      GoRoute(
          path: '/work-items/:id',
          builder: (c, s) =>
              WorkItemDetailScreen(workItemId: s.pathParameters['id']!)),
      GoRoute(
          path: '/tasks',
          builder: (c, s) => const TasksScreen(initialScope: 'team')),
      GoRoute(
          path: '/my-tasks',
          builder: (c, s) => const TasksScreen(initialScope: 'my')),
      GoRoute(
          path: '/team-tasks',
          builder: (c, s) => const TasksScreen(initialScope: 'team')),
      GoRoute(
          path: '/tasks/:id',
          builder: (c, s) => TaskDetailScreen(taskId: s.pathParameters['id']!)),
      GoRoute(path: '/messages', builder: (c, s) => const MessagesScreen()),
      GoRoute(
          path: '/messages/:id',
          builder: (c, s) =>
              MessageDetailScreen(messageId: s.pathParameters['id']!)),
      GoRoute(path: '/daily-work', builder: (c, s) => const DailyWorkScreen()),
      GoRoute(path: '/activities', builder: (c, s) => const ActivitiesScreen()),
      GoRoute(path: '/approvals', builder: (c, s) => const ApprovalsScreen()),
      GoRoute(
          path: '/notifications',
          builder: (c, s) => const NotificationsScreen()),
      GoRoute(path: '/users', builder: (c, s) => const UsersScreen()),
      GoRoute(path: '/search', builder: (c, s) => const SearchScreen()),
      GoRoute(path: '/reports', builder: (c, s) => const ReportsScreen()),
    ],
  );
  @override
  Widget build(BuildContext context) => MaterialApp.router(
      title: 'Hama Work',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: Colors.indigo,
          scaffoldBackgroundColor: const Color(0xfff7f8fb),
          inputDecorationTheme:
              const InputDecorationTheme(border: OutlineInputBorder()),
          cardTheme: const CardThemeData(margin: EdgeInsets.zero)),
      routerConfig: router);
}

class GoRouterRefreshStream extends ChangeNotifier {
  GoRouterRefreshStream(Stream<dynamic> stream) {
    _sub = stream.asBroadcastStream().listen((_) => notifyListeners());
  }
  late final dynamic _sub;
  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }
}
