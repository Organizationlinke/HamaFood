DateTime? _date(dynamic v) => v == null ? null : (v is DateTime ? v : DateTime.tryParse(v.toString()));
int? _int(dynamic v) => v == null ? null : (v is int ? v : int.tryParse(v.toString()));
bool _bool(dynamic v, [bool fallback = false]) => v == null ? fallback : (v is bool ? v : v.toString().toLowerCase() == 'true');

class Profile {
  final String id, fullName, username, userCode, role;
  final String? jobTitle, departmentId, departmentName;
  final bool isActive;
  final DateTime? lastSeenAt;
  const Profile({required this.id,required this.fullName,required this.username,required this.userCode,required this.role,this.jobTitle,this.departmentId,this.departmentName,this.isActive=true,this.lastSeenAt});
  bool get isGm => role == 'gm';
  bool get isManager => role == 'manager';
  bool get canManageUsers => isGm;
  factory Profile.fromMap(Map<String,dynamic> m) => Profile(id:m['id'].toString(),fullName:(m['full_name']??'User').toString(),username:(m['username']??'').toString(),userCode:(m['user_code']??'').toString(),role:(m['role']??'employee').toString(),jobTitle:m['job_title']?.toString(),departmentId:m['department_id']?.toString(),departmentName:m['department_name']?.toString() ?? (m['department'] is Map ? m['department']['name']?.toString() : null),isActive:_bool(m['is_active'],true),lastSeenAt:_date(m['last_seen_at']));
}

class Department {
  final String id, code, name; final bool isActive;
  const Department({required this.id,required this.code,required this.name,required this.isActive});
  factory Department.fromMap(Map<String,dynamic> m)=>Department(id:m['id'].toString(),code:(m['code']??'').toString(),name:(m['name']??'').toString(),isActive:_bool(m['is_active'],true));
}

class WorkItem {
  final String id, code, title, status, priority, category;
  final String? description, responsibleId, followerId, createdBy, finalResult;
  final DateTime? deadline, completedAt, reopenedAt, updatedAt;
  final bool isArchived; final DateTime createdAt;
  const WorkItem({required this.id,required this.code,required this.title,required this.status,required this.priority,required this.category,this.description,this.responsibleId,this.followerId,this.createdBy,this.finalResult,this.deadline,this.completedAt,this.reopenedAt,this.updatedAt,this.isArchived=false,required this.createdAt});
  factory WorkItem.fromMap(Map<String,dynamic> m)=>WorkItem(id:m['id'].toString(),code:(m['code']??'').toString(),title:(m['title']??'').toString(),status:(m['status']??'open').toString(),priority:(m['priority']??'normal').toString(),category:(m['category']??'other').toString(),description:m['description']?.toString(),responsibleId:m['responsible_id']?.toString(),followerId:m['follower_id']?.toString(),createdBy:m['created_by']?.toString(),finalResult:m['final_result']?.toString(),deadline:_date(m['deadline']),completedAt:_date(m['completed_at']),reopenedAt:_date(m['reopened_at']),updatedAt:_date(m['updated_at']),isArchived:_bool(m['is_archived']),createdAt:_date(m['created_at'])??DateTime.now());
}

class Task {
  final String id, code, title, status, priority;
  final String? description, workItemId, responsibleId, followerId, managerConfirmedBy, evalComment, completedBy, reopenedBy;
  final DateTime? deadline, managerConfirmedAt, completionRequestedAt, completedAt, reopenedAt, createdAt;
  final bool evidenceRequired, managerConfirmationRequired, managerConfirmed; final int? score;
  const Task({required this.id,required this.code,required this.title,required this.status,required this.priority,this.description,this.workItemId,this.responsibleId,this.followerId,this.deadline,this.evidenceRequired=false,this.managerConfirmationRequired=true,this.managerConfirmed=false,this.managerConfirmedBy,this.managerConfirmedAt,this.score,this.evalComment,this.completionRequestedAt,this.completedAt,this.completedBy,this.reopenedAt,this.createdAt,this.reopenedBy});
  factory Task.fromMap(Map<String,dynamic> m)=>Task(id:m['id'].toString(),code:(m['code']??'').toString(),title:(m['title']??'').toString(),status:(m['status']??'not_started').toString(),priority:(m['priority']??'normal').toString(),description:m['description']?.toString(),workItemId:m['work_item_id']?.toString(),responsibleId:m['responsible_id']?.toString(),followerId:m['follower_id']?.toString(),deadline:_date(m['deadline']),evidenceRequired:_bool(m['evidence_required']),managerConfirmationRequired:_bool(m['manager_confirmation_required'],true),managerConfirmed:_bool(m['manager_confirmed']),managerConfirmedBy:m['manager_confirmed_by']?.toString(),managerConfirmedAt:_date(m['manager_confirmed_at']),score:_int(m['score']),evalComment:m['eval_comment']?.toString(),completionRequestedAt:_date(m['completion_requested_at']),completedAt:_date(m['completed_at']),completedBy:m['completed_by']?.toString(),reopenedAt:_date(m['reopened_at']),reopenedBy:m['reopened_by']?.toString(),createdAt:_date(m['created_at']));
}

class TaskStage {
  final String id, taskId, title, status; final String? description, responsibleId; final DateTime? deadline, completedAt; final int sortOrder;
  const TaskStage({required this.id,required this.taskId,required this.title,required this.status,this.description,this.responsibleId,this.deadline,this.completedAt,required this.sortOrder});
  factory TaskStage.fromMap(Map<String,dynamic> m)=>TaskStage(id:m['id'].toString(),taskId:m['task_id'].toString(),title:(m['title']??'').toString(),status:(m['status']??'pending').toString(),description:m['description']?.toString(),responsibleId:m['responsible_id']?.toString(),deadline:_date(m['deadline']),completedAt:_date(m['completed_at']),sortOrder:_int(m['sort_order'])??1);
}

class Activity {
  final String id, type, description; final DateTime dateTime; final String? withWhom, toWhom, result, nextAction, workItemId, taskId, createdBy;
  const Activity({required this.id,required this.type,required this.description,required this.dateTime,this.withWhom,this.toWhom,this.result,this.nextAction,this.workItemId,this.taskId,this.createdBy});
  factory Activity.fromMap(Map<String,dynamic> m)=>Activity(id:m['id'].toString(),type:(m['type']??'note').toString(),description:(m['description']??'').toString(),dateTime:_date(m['date_time'])??DateTime.now(),withWhom:m['with_whom']?.toString(),toWhom:m['to_whom']?.toString(),result:m['result']?.toString(),nextAction:m['next_action']?.toString(),workItemId:m['work_item_id']?.toString(),taskId:m['task_id']?.toString(),createdBy:m['created_by']?.toString());
}

class MessageItem {
  final String id, code, content, messageType, audienceType; final String? workItemId, taskId, createdBy, senderName; final DateTime createdAt; final int recipientCount, seenCount; final bool seenByMe;
  const MessageItem({required this.id,required this.code,required this.content,required this.messageType,required this.audienceType,this.workItemId,this.taskId,this.createdBy,this.senderName,required this.createdAt,required this.recipientCount,required this.seenCount,required this.seenByMe});
}

class CommentItem {
  final String id, parentType, parentId, content; final String? createdBy, creatorName; final DateTime createdAt;
  const CommentItem({required this.id,required this.parentType,required this.parentId,required this.content,this.createdBy,this.creatorName,required this.createdAt});
  factory CommentItem.fromMap(Map<String,dynamic> m,{String? creatorName})=>CommentItem(id:m['id'].toString(),parentType:(m['parent_type']??'').toString(),parentId:m['parent_id'].toString(),content:(m['content']??'').toString(),createdBy:m['created_by']?.toString(),creatorName:creatorName,createdAt:_date(m['created_at'])??DateTime.now());
}

class DailyWork {
  final String id, userId, content, status; final DateTime workDate; final String? problems,nextActions,workItemId,taskId; final DateTime? updatedAt;
  const DailyWork({required this.id,required this.userId,required this.workDate,required this.content,required this.status,this.problems,this.nextActions,this.workItemId,this.taskId,this.updatedAt});
  factory DailyWork.fromMap(Map<String,dynamic> m)=>DailyWork(id:m['id'].toString(),userId:m['user_id'].toString(),workDate:_date(m['work_date'])??DateTime.now(),content:(m['content']??'').toString(),status:(m['status']??'draft').toString(),problems:m['problems']?.toString(),nextActions:m['next_actions']?.toString(),workItemId:m['work_item_id']?.toString(),taskId:m['task_id']?.toString(),updatedAt:_date(m['updated_at']));
}

class Approval {
  final String id, code, requestText, requestedFrom, status; final String? title, requestedBy, decisionBy, decisionComment, workItemId, taskId; final DateTime? deadline, decisionAt; final DateTime createdAt;
  const Approval({required this.id,required this.code,required this.requestText,required this.requestedFrom,required this.status,this.title,this.requestedBy,this.decisionBy,this.decisionComment,this.workItemId,this.taskId,this.deadline,this.decisionAt,required this.createdAt});
  factory Approval.fromMap(Map<String,dynamic> m)=>Approval(id:m['id'].toString(),code:(m['code']??'').toString(),title:m['title']?.toString(),requestText:(m['request_text']??'').toString(),requestedFrom:m['requested_from'].toString(),requestedBy:m['requested_by']?.toString(),status:(m['status']??'pending').toString(),deadline:_date(m['deadline']),decisionBy:m['decision_by']?.toString(),decisionAt:_date(m['decision_at']),decisionComment:m['decision_comment']?.toString(),workItemId:m['work_item_id']?.toString(),taskId:m['task_id']?.toString(),createdAt:_date(m['created_at'])??DateTime.now());
}

class NotificationItem {
  final String id,type,title,body; final String? targetType,targetId; final bool isRead; final DateTime createdAt;
  const NotificationItem({required this.id,required this.type,required this.title,required this.body,this.targetType,this.targetId,required this.isRead,required this.createdAt});
  factory NotificationItem.fromMap(Map<String,dynamic> m)=>NotificationItem(id:m['id'].toString(),type:(m['type']??'system').toString(),title:(m['title']??'').toString(),body:(m['body']??'').toString(),targetType:m['target_type']?.toString(),targetId:m['target_id']?.toString(),isRead:_bool(m['is_read']),createdAt:_date(m['created_at'])??DateTime.now());
}

class AttachmentItem {
  final String id,parentType,parentId,fileName,storagePath; final String? mimeType,uploadedBy; final int? sizeBytes; final DateTime createdAt;
  const AttachmentItem({required this.id,required this.parentType,required this.parentId,required this.fileName,required this.storagePath,this.mimeType,this.uploadedBy,this.sizeBytes,required this.createdAt});
  factory AttachmentItem.fromMap(Map<String,dynamic> m)=>AttachmentItem(id:m['id'].toString(),parentType:(m['parent_type']??'').toString(),parentId:m['parent_id'].toString(),fileName:(m['file_name']??'').toString(),storagePath:(m['storage_path']??'').toString(),mimeType:m['mime_type']?.toString(),uploadedBy:m['uploaded_by']?.toString(),sizeBytes:_int(m['size_bytes']),createdAt:_date(m['created_at'])??DateTime.now());
}

class TimelineEvent {
  final String id,eventType,title; final String? description,createdBy; final DateTime createdAt; final Map<String,dynamic> metadata;
  const TimelineEvent({required this.id,required this.eventType,required this.title,this.description,this.createdBy,required this.createdAt,this.metadata=const {}});
  factory TimelineEvent.fromMap(Map<String,dynamic> m)=>TimelineEvent(id:m['id'].toString(),eventType:(m['event_type']??'event').toString(),title:(m['title']??'').toString(),description:m['description']?.toString(),createdBy:m['created_by']?.toString(),createdAt:_date(m['created_at'])??DateTime.now(),metadata:m['metadata'] is Map?Map<String,dynamic>.from(m['metadata']):const {});
}

class DashboardStats {
  final int workItems,openWorkItems,tasks,myTasks,overdueTasks,readyTasks,unreadMessages,unreadNotifications,pendingApprovals,todayDailyWork;
  const DashboardStats({required this.workItems,required this.openWorkItems,required this.tasks,required this.myTasks,required this.overdueTasks,required this.readyTasks,required this.unreadMessages,required this.unreadNotifications,required this.pendingApprovals,required this.todayDailyWork});
}
