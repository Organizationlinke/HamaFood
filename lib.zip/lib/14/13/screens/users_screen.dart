import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class UsersScreen extends ConsumerWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider).valueOrNull;
    if (profile?.canManageUsers != true) {
      return const AppScaffold(
        title: 'Users',
        body: EmptyView('Only the General Manager can manage users.'),
      );
    }

    final data = ref.watch(usersProvider);
    return AppScaffold(
      title: 'Users',
      actions: [
        IconButton(
          onPressed: () => ref.invalidate(usersProvider),
          icon: const Icon(Icons.refresh),
        ),
      ],
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _create(context, ref),
        icon: const Icon(Icons.person_add),
        label: const Text('New User'),
      ),
      body: data.when(
        data: (users) {
          if (users.isEmpty) {
            return const EmptyView('No users found.', icon: Icons.people_outline);
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: users.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) => _tile(context, ref, users[i]),
          );
        },
        loading: () => const LoadingView(),
        error: (e, _) => ErrorView(
          e,
          retry: () => ref.invalidate(usersProvider),
        ),
      ),
    );
  }

  Widget _tile(BuildContext context, WidgetRef ref, Profile user) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          child: Text(user.fullName.isEmpty ? 'U' : user.fullName[0].toUpperCase()),
        ),
        title: Text(user.fullName),
        subtitle: Text(
          '@${user.username} • ${user.userCode}\n'
          '${user.departmentName ?? 'No department'} • ${labelize(user.role)}'
          '${user.jobTitle == null ? '' : '\n${user.jobTitle}'}',
        ),
        isThreeLine: true,
        trailing: Switch(
          value: user.isActive,
          onChanged: (value) async {
            try {
              await ref.read(repoProvider).setUserActive(user.id, value);
              ref.invalidate(usersProvider);
            } catch (e) {
              if (context.mounted) Ui.snack(context, 'Error: $e');
            }
          },
        ),
      ),
    );
  }

  static Future<void> _create(BuildContext context, WidgetRef ref) async {
    final departments = await ref.read(departmentsProvider.future);
    if (!context.mounted) return;

    final username = TextEditingController();
    final fullName = TextEditingController();
    final password = TextEditingController();
    final jobTitle = TextEditingController();
    String role = 'manager';
    String? departmentCode = departments.isEmpty ? null : departments.first.code;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (dialogContext, setDialogState) {
            return AlertDialog(
              title: const Text('Create User'),
              content: SizedBox(
                width: 520,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      TextField(
                        controller: username,
                        decoration: const InputDecoration(labelText: 'Username *'),
                      ),
                      TextField(
                        controller: fullName,
                        decoration: const InputDecoration(labelText: 'Full name *'),
                      ),
                      TextField(
                        controller: password,
                        obscureText: true,
                        decoration: const InputDecoration(labelText: 'Password *'),
                      ),
                      TextField(
                        controller: jobTitle,
                        decoration: const InputDecoration(labelText: 'Job title'),
                      ),
                      DropdownButtonFormField<String>(
                        value: role,
                        decoration: const InputDecoration(labelText: 'Role'),
                        items: const [
                          DropdownMenuItem(value: 'manager', child: Text('Manager')),
                          DropdownMenuItem(value: 'employee', child: Text('Employee')),
                        ],
                        onChanged: (value) {
                          setDialogState(() => role = value ?? 'manager');
                        },
                      ),
                      DropdownButtonFormField<String>(
                        value: departmentCode,
                        decoration: const InputDecoration(labelText: 'Department'),
                        items: departments
                            .map(
                              (department) => DropdownMenuItem<String>(
                                value: department.code,
                                child: Text(department.name),
                              ),
                            )
                            .toList(),
                        onChanged: (value) {
                          setDialogState(() => departmentCode = value);
                        },
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () async {
                    if (username.text.trim().isEmpty ||
                        fullName.text.trim().isEmpty ||
                        password.text.length < 6 ||
                        departmentCode == null) {
                      Ui.snack(context, 'Complete all required fields.');
                      return;
                    }
                    try {
                      await ref.read(repoProvider).createUser(
                        username: username.text.trim(),
                        fullName: fullName.text.trim(),
                        password: password.text,
                        role: role,
                        departmentCode: departmentCode!,
                        jobTitle: jobTitle.text.trim().isEmpty
                            ? null
                            : jobTitle.text.trim(),
                      );
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                      ref.invalidate(usersProvider);
                      Ui.snack(context, 'User created successfully.');
                    } catch (e) {
                      Ui.snack(context, 'Error: $e');
                    }
                  },
                  child: const Text('Create'),
                ),
              ],
            );
          },
        );
      },
    );

    username.dispose();
    fullName.dispose();
    password.dispose();
    jobTitle.dispose();
  }
}
