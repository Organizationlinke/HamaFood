import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class DailyWorkScreen extends ConsumerStatefulWidget {
  const DailyWorkScreen({super.key});

  @override
  ConsumerState<DailyWorkScreen> createState() => _DailyWorkScreenState();
}

class _DailyWorkScreenState extends ConsumerState<DailyWorkScreen> {
  DateTime selected = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final data = ref.watch(dailyWorksProvider);

    return AppScaffold(
      title: 'Daily Work',
      actions: [
        IconButton(
          onPressed: () => ref.invalidate(dailyWorksProvider),
          icon: const Icon(Icons.refresh),
        ),
      ],
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _edit,
        icon: const Icon(Icons.edit_note),
        label: Text(_isToday ? 'Today' : 'Add Entry'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                OutlinedButton.icon(
                  onPressed: _pickDate,
                  icon: const Icon(Icons.event),
                  label: Text(shortDate(selected)),
                ),
                const Spacer(),
                Text(_isToday ? 'Today' : 'Selected day'),
              ],
            ),
          ),
          Expanded(
            child: data.when(
              data: (items) {
                final xs = items
                    .where((x) => _sameDay(x.workDate, selected))
                    .toList();
                if (xs.isEmpty) {
                  return const EmptyView(
                    'No Daily Work entry for this date',
                    icon: Icons.today_outlined,
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: xs.length,
                  itemBuilder: (_, i) => _tile(xs[i]),
                );
              },
              loading: () => const LoadingView(),
              error: (e, _) => ErrorView(
                e,
                retry: () => ref.invalidate(dailyWorksProvider),
              ),
            ),
          ),
        ],
      ),
    );
  }

  bool get _isToday => _sameDay(DateTime.now(), selected);

  bool _sameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  Widget _tile(DailyWork w) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                StatusChip(w.status),
                const Spacer(),
                Text('Updated ${shortDate(w.updatedAt)}'),
              ],
            ),
            const SizedBox(height: 10),
            Text(w.content),
            if (w.problems?.isNotEmpty == true) ...[
              const SizedBox(height: 12),
              LabeledValue('Problems', w.problems!),
            ],
            if (w.nextActions?.isNotEmpty == true) ...[
              const SizedBox(height: 12),
              LabeledValue('Next Actions', w.nextActions!),
            ],
            if (w.workItemId != null || w.taskId != null) ...[
              const SizedBox(height: 12),
              Wrap(
                spacing: 12,
                children: [
                  if (w.workItemId != null)
                    Chip(label: Text('Work Item linked')),
                  if (w.taskId != null) Chip(label: Text('Task linked')),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: selected,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null && mounted) {
      setState(() => selected = d);
    }
  }

  Future<void> _edit() async {
    try {
      final repo = ref.read(repoProvider);
      final workItems = await repo.workItems();
      final tasks = await repo.tasks();
      final rows = await repo.dailyWorks(date: selected, all: false);
      final matches = rows.where((x) => _sameDay(x.workDate, selected)).toList();
      final existing = matches.isEmpty ? null : matches.first;

      final content = TextEditingController(text: existing?.content ?? '');
      final problems = TextEditingController(text: existing?.problems ?? '');
      final next = TextEditingController(text: existing?.nextActions ?? '');
      String status = existing?.status ?? 'draft';
      String? workItemId = existing?.workItemId;
      String? taskId = existing?.taskId;

      if (!mounted) {
        content.dispose();
        problems.dispose();
        next.dispose();
        return;
      }

      await showDialog<void>(
        context: context,
        builder: (dialogContext) => StatefulBuilder(
          builder: (dialogContext, setDialogState) {
            return AlertDialog(
              title: Text('Daily Work • ${shortDate(selected)}'),
              content: SizedBox(
                width: 600,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      TextField(
                        controller: content,
                        maxLines: 8,
                        decoration: const InputDecoration(
                          labelText: 'What did you do? *',
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: problems,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Problems / blockers',
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: next,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Next actions',
                        ),
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: status,
                        decoration: const InputDecoration(labelText: 'Status'),
                        items: const [
                          DropdownMenuItem(
                            value: 'draft',
                            child: Text('Draft'),
                          ),
                          DropdownMenuItem(
                            value: 'submitted',
                            child: Text('Submitted'),
                          ),
                        ],
                        onChanged: (v) => setDialogState(
                          () => status = v ?? 'draft',
                        ),
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: workItemId,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Link to Work Item (optional)',
                        ),
                        items: [
                          const DropdownMenuItem<String>(
                            value: null,
                            child: Text('No Work Item'),
                          ),
                          ...workItems.map(
                            (w) => DropdownMenuItem<String>(
                              value: w.id,
                              child: Text(
                                '${w.code} • ${w.title}',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ),
                        ],
                        onChanged: (v) => setDialogState(() {
                          workItemId = v;
                          if (v == null) taskId = null;
                        }),
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: taskId,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Link to Task (optional)',
                        ),
                        items: [
                          const DropdownMenuItem<String>(
                            value: null,
                            child: Text('No Task'),
                          ),
                          ...tasks.map(
                            (t) => DropdownMenuItem<String>(
                              value: t.id,
                              child: Text(
                                '${t.code} • ${t.title}',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ),
                        ],
                        onChanged: (v) => setDialogState(() => taskId = v),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () async {
                    if (content.text.trim().isEmpty) {
                      Ui.snack(context, 'Daily Work content is required.');
                      return;
                    }
                    try {
                      await repo.saveDailyWork(
                        workDate: selected,
                        content: content.text.trim(),
                        problems: problems.text.trim().isEmpty
                            ? null
                            : problems.text.trim(),
                        nextActions: next.text.trim().isEmpty
                            ? null
                            : next.text.trim(),
                        status: status,
                        workItemId: workItemId,
                        taskId: taskId,
                      );
                      if (dialogContext.mounted) {
                        Navigator.pop(dialogContext);
                      }
                      ref.invalidate(dailyWorksProvider);
                      ref.invalidate(dashboardProvider);
                      if (mounted) Ui.snack(context, 'Daily Work saved');
                    } catch (e) {
                      Ui.snack(context, 'Error: $e');
                    }
                  },
                  child: const Text('Save'),
                ),
              ],
            );
          },
        ),
      );

      content.dispose();
      problems.dispose();
      next.dispose();
    } catch (e) {
      if (mounted) Ui.snack(context, 'Error: $e');
    }
  }
}
