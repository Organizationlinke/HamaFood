import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class MessageDetailScreen extends ConsumerStatefulWidget {
  final String messageId;
  const MessageDetailScreen({super.key, required this.messageId});
  @override ConsumerState<MessageDetailScreen> createState() => _MessageDetailScreenState();
}

class _MessageDetailScreenState extends ConsumerState<MessageDetailScreen> {
  Future<MessageItem?> _load() => ref.read(repoProvider).messageById(widget.messageId);

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'Message',
      showBack: true,
      body: FutureBuilder<MessageItem?>(
        future: _load(),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const LoadingView();
          if (snapshot.hasError) return ErrorView(snapshot.error!);
          final message = snapshot.data;
          if (message == null) return const EmptyView('Message not found');
          if (!message.seenByMe) {
            ref.read(repoProvider).markMessageSeen(message.id);
          }
          final isGm = ref.watch(profileProvider).valueOrNull?.isGm == true;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _messageCard(message, isGm),
              const SizedBox(height: 12),
              if (message.messageType == 'task' || message.messageType == 'action_required')
                const Card(
                  child: ListTile(
                    leading: Icon(Icons.priority_high),
                    title: Text('Action Required'),
                    subtitle: Text('This message can be converted into a managed Task.'),
                  ),
                ),
              const SizedBox(height: 12),
              _recipientCard(message),
              const SizedBox(height: 12),
              _commentsCard(),
              const SizedBox(height: 12),
              _attachmentsCard(),
            ],
          );
        },
      ),
    );
  }

  Widget _messageCard(MessageItem message, bool isGm) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                StatusChip(message.messageType),
                Chip(label: Text(message.audienceType == 'everyone' ? 'Everyone' : 'Selected')),
              ],
            ),
            const SizedBox(height: 14),
            Text(message.content, style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 14),
            Text('From: ${message.senderName ?? 'User'}'),
            Text(dateTimeText(message.createdAt)),
            Text('Seen ${message.seenCount}/${message.recipientCount}'),
            const SizedBox(height: 10),
            Wrap(
              spacing: 6,
              children: ['👍', '✅', '❤️', '⚠️', '🙏']
                  .map((emoji) => ActionChip(
                        label: Text(emoji),
                        onPressed: () async {
                          try {
                            await ref.read(repoProvider).react(parentType: 'message', parentId: message.id, reaction: emoji);
                            if (mounted) Ui.snack(context, 'Reaction added.');
                          } catch (e) {
                            if (mounted) Ui.snack(context, 'Error: $e');
                          }
                        },
                      ))
                  .toList(),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                if (isGm)
                  OutlinedButton.icon(
                    onPressed: () => _convertToTask(message),
                    icon: const Icon(Icons.add_task),
                    label: const Text('Convert to Task'),
                  ),
                if (message.workItemId != null)
                  OutlinedButton.icon(
                    onPressed: () => context.go('/work-items/${message.workItemId}'),
                    icon: const Icon(Icons.folder_open),
                    label: const Text('Open Work Item'),
                  )
                else
                  OutlinedButton.icon(
                    onPressed: () => _linkWorkItem(message),
                    icon: const Icon(Icons.link),
                    label: const Text('Link Work Item'),
                  ),
                if (message.taskId != null)
                  OutlinedButton.icon(
                    onPressed: () => context.go('/tasks/${message.taskId}'),
                    icon: const Icon(Icons.task_alt),
                    label: const Text('Open Task'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _recipientCard(MessageItem message) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: FutureBuilder<List<Profile>>(
          future: ref.read(repoProvider).messageRecipients(message.id),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) return const LinearProgressIndicator();
            if (snapshot.hasError) return Text('Error: ${snapshot.error}');
            final users = snapshot.data ?? [];
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Recipients', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                users.isEmpty
                    ? const Text('No recipient data available.')
                    : Wrap(spacing: 8, runSpacing: 8, children: users.map((user) => Chip(label: Text(user.fullName))).toList()),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _commentsCard() {
    final data = ref.watch(commentsProvider('message|${widget.messageId}'));
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(child: Text('Replies / Comments', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                IconButton(onPressed: _comment, icon: const Icon(Icons.reply)),
              ],
            ),
            data.when(
              data: (items) => items.isEmpty
                  ? const Text('No replies yet.')
                  : Column(
                      children: items
                          .map((item) => ListTile(
                                contentPadding: EdgeInsets.zero,
                                title: Text(item.creatorName ?? 'User'),
                                subtitle: Text(item.content),
                                trailing: Text(shortDate(item.createdAt)),
                              ))
                          .toList(),
                    ),
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => Text('Error: $e'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _attachmentsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: FutureBuilder<List<AttachmentItem>>(
          future: ref.read(repoProvider).attachments(parentType: 'message', parentId: widget.messageId),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) return const LinearProgressIndicator();
            if (snapshot.hasError) return Text('Error: ${snapshot.error}');
            final items = snapshot.data ?? [];
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(child: Text('Files', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                    IconButton(onPressed: _addAttachment, icon: const Icon(Icons.attach_file)),
                  ],
                ),
                if (items.isEmpty)
                  const Text('No files.')
                else
                  ...items.map(
                    (item) => ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.insert_drive_file_outlined),
                      title: Text(item.fileName),
                      subtitle: Text(item.storagePath),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  Future<void> _comment() async {
    final controller = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Reply'),
        content: TextField(controller: controller, maxLines: 6, decoration: const InputDecoration(hintText: 'Write reply… @username')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              if (controller.text.trim().isEmpty) return;
              try {
                await ref.read(repoProvider).addComment(parentType: 'message', parentId: widget.messageId, content: controller.text.trim());
                if (dialogContext.mounted) Navigator.pop(dialogContext);
                ref.invalidate(commentsProvider('message|${widget.messageId}'));
              } catch (e) {
                Ui.snack(context, 'Error: $e');
              }
            },
            child: const Text('Send'),
          ),
        ],
      ),
    );
    controller.dispose();
  }

  Future<void> _addAttachment() async {
    final name = TextEditingController();
    final path = TextEditingController();
    final mime = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Add File'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'File name *')),
            TextField(controller: path, decoration: const InputDecoration(labelText: 'Storage path *')),
            TextField(controller: mime, decoration: const InputDecoration(labelText: 'MIME type')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty || path.text.trim().isEmpty) return;
              try {
                await ref.read(repoProvider).addAttachmentMetadata(parentType: 'message', parentId: widget.messageId, fileName: name.text.trim(), storagePath: path.text.trim(), mimeType: mime.text.trim().isEmpty ? null : mime.text.trim());
                if (dialogContext.mounted) Navigator.pop(dialogContext);
                setState(() {});
              } catch (e) {
                Ui.snack(context, 'Error: $e');
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    name.dispose(); path.dispose(); mime.dispose();
  }

  Future<void> _linkWorkItem(MessageItem message) async {
    final workItems = await ref.read(repoProvider).workItems();
    if (!mounted) return;
    String? selectedId = workItems.isEmpty ? null : workItems.first.id;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Link Message to Work Item'),
          content: DropdownButtonFormField<String>(
            value: selectedId,
            items: workItems.map((w) => DropdownMenuItem(value: w.id, child: Text('${w.code} • ${w.title}'))).toList(),
            onChanged: (value) => setDialogState(() => selectedId = value),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: selectedId == null
                  ? null
                  : () async {
                      try {
                        await ref.read(repoProvider).linkMessageToWorkItem(message.id, selectedId!);
                        if (dialogContext.mounted) Navigator.pop(dialogContext);
                        setState(() {});
                      } catch (e) { Ui.snack(context, 'Error: $e'); }
                    },
              child: const Text('Link'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _convertToTask(MessageItem message) async {
    final users = await ref.read(activeUsersProvider.future);
    if (!mounted || users.isEmpty) return;
    final title = TextEditingController(text: message.content.length > 80 ? message.content.substring(0, 80) : message.content);
    final description = TextEditingController(text: message.content);
    String? responsibleId = users.first.id;
    String? followerId;
    String priority = message.messageType == 'action_required' ? 'urgent' : 'normal';

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Convert Message to Task'),
          content: SizedBox(
            width: 560,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: title, decoration: const InputDecoration(labelText: 'Task title')),
                TextField(controller: description, maxLines: 4, decoration: const InputDecoration(labelText: 'Description')),
                DropdownButtonFormField<String>(
                  value: priority,
                  decoration: const InputDecoration(labelText: 'Priority'),
                  items: const [DropdownMenuItem(value: 'normal', child: Text('Normal')), DropdownMenuItem(value: 'urgent', child: Text('Urgent'))],
                  onChanged: (value) => setDialogState(() => priority = value ?? 'normal'),
                ),
                DropdownButtonFormField<String>(
                  value: responsibleId,
                  decoration: const InputDecoration(labelText: 'Responsible *'),
                  items: users.map((u) => DropdownMenuItem(value: u.id, child: Text(u.fullName))).toList(),
                  onChanged: (value) => setDialogState(() => responsibleId = value),
                ),
                DropdownButtonFormField<String>(
                  value: followerId,
                  decoration: const InputDecoration(labelText: 'Follower'),
                  items: [const DropdownMenuItem<String>(value: null, child: Text('No follower')), ...users.map((u) => DropdownMenuItem<String>(value: u.id, child: Text(u.fullName)))],
                  onChanged: (value) => setDialogState(() => followerId = value),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () async {
                if (responsibleId == null || title.text.trim().isEmpty) return;
                try {
                  await ref.read(repoProvider).createTask(title: title.text.trim(), description: description.text.trim(), priority: priority, responsibleId: responsibleId!, followerId: followerId, workItemId: message.workItemId);
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                  ref.invalidate(tasksProvider);
                  Ui.snack(context, 'Task created.');
                } catch (e) { Ui.snack(context, 'Error: $e'); }
              },
              child: const Text('Create'),
            ),
          ],
        ),
      ),
    );
    title.dispose(); description.dispose();
  }
}
