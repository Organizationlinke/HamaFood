import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider);
    final stats = ref.watch(dashboardProvider);
    final messages = ref.watch(messagesProvider);
    final approvals = ref.watch(approvalsProvider);

    return AppScaffold(
      title: 'Dashboard',
      actions: [
        IconButton(
          onPressed: () {
            ref.invalidate(dashboardProvider);
            ref.invalidate(messagesProvider);
            ref.invalidate(approvalsProvider);
          },
          icon: const Icon(Icons.refresh),
        ),
      ],
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(dashboardProvider);
          ref.invalidate(messagesProvider);
          ref.invalidate(approvalsProvider);
          await ref.read(dashboardProvider.future);
        },
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            profile.when(
              data: (p) => Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text('Welcome, ${p?.fullName ?? 'User'}'),
                  subtitle: Text(
                    '${p?.jobTitle ?? 'Team member'} • ${p?.departmentName ?? 'No department'}',
                  ),
                ),
              ),
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => Text('Profile error: $e'),
            ),
            const SizedBox(height: 14),
            stats.when(
              data: (s) => Column(
                children: [
                  GridView.count(
                    crossAxisCount:
                        MediaQuery.sizeOf(context).width > 950 ? 4 : 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 1.7,
                    children: [
                      _stat(context, 'Work Items', s.workItems,
                          Icons.folder_open, '/work-items'),
                      _stat(context, 'Open Items', s.openWorkItems,
                          Icons.pending_actions, '/work-items'),
                      _stat(context, 'Tasks', s.tasks, Icons.task_alt, '/tasks'),
                      _stat(context, 'My Tasks', s.myTasks, Icons.person_pin, '/my-tasks'),
                      _stat(context, 'Overdue', s.overdueTasks,
                          Icons.warning_amber, '/team-tasks'),
                      _stat(context, 'Ready', s.readyTasks,
                          Icons.fact_check_outlined, '/tasks'),
                      _stat(context, 'Unread Messages', s.unreadMessages,
                          Icons.mark_chat_unread_outlined, '/messages'),
                      _stat(context, 'Notifications', s.unreadNotifications,
                          Icons.notifications_none, '/notifications'),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.priority_high),
                      title: const Text('Needs Your Attention'),
                      subtitle: Text(
                        '${s.overdueTasks} overdue • '
                        '${s.readyTasks} ready for completion • '
                        '${s.pendingApprovals} pending approvals',
                      ),
                      onTap: () => context.go('/tasks'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: Card(
                          child: ListTile(
                            leading: const Icon(Icons.today),
                            title: const Text('Daily Work'),
                            subtitle: Text(
                              s.todayDailyWork > 0
                                  ? 'Today submitted'
                                  : 'Today not submitted',
                            ),
                            onTap: () => context.go('/daily-work'),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Card(
                          child: ListTile(
                            leading: const Icon(Icons.fact_check_outlined),
                            title: const Text('Approvals'),
                            subtitle: Text('${s.pendingApprovals} pending'),
                            onTap: () => context.go('/approvals'),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              loading: () => const Padding(
                padding: EdgeInsets.all(32),
                child: LoadingView(),
              ),
              error: (e, _) => ErrorView(
                e,
                retry: () => ref.invalidate(dashboardProvider),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Latest Communication',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    messages.when(
                      data: (xs) {
                        final latest = xs.take(5).toList();
                        if (latest.isEmpty) {
                          return const Text('No messages');
                        }
                        return Column(
                          children: latest
                              .map(
                                (m) => ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  onTap: () =>
                                      context.go('/messages/${m.id}'),
                                  leading: const Icon(
                                      Icons.chat_bubble_outline),
                                  title: Text(
                                    m.content,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  subtitle: Text(
                                    '${m.senderName ?? 'User'} • '
                                    'Seen ${m.seenCount}/${m.recipientCount}',
                                  ),
                                ),
                              )
                              .toList(),
                        );
                      },
                      loading: () => const LinearProgressIndicator(),
                      error: (e, _) => Text('Message error: $e'),
                    ),
                    const Divider(),
                    approvals.when(
                      data: (xs) {
                        final pending =
                            xs.where((a) => a.status == 'pending').take(3).toList();
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Pending Approvals',
                              style: TextStyle(fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: 4),
                            if (pending.isEmpty)
                              const Text('No pending approvals.')
                            else
                              ...pending.map(
                                (a) => ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: const Icon(Icons.fact_check_outlined),
                                  title: Text(a.title ?? a.code),
                                  subtitle: Text(
                                    a.requestText,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  onTap: () => context.go('/approvals'),
                                ),
                              ),
                          ],
                        );
                      },
                      loading: () => const LinearProgressIndicator(),
                      error: (e, _) => Text('Approval error: $e'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: ListTile(
                leading: const Icon(Icons.search),
                title: const Text('Search everything'),
                subtitle: const Text(
                  'Work Items, Tasks, Messages, Comments, Activities and Files',
                ),
                onTap: () => context.go('/search'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(
    BuildContext context,
    String title,
    int value,
    IconData icon,
    String route,
  ) {
    return Card(
      child: InkWell(
        onTap: () => context.go(route),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Icon(icon, size: 30),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '$value',
                      style: const TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
