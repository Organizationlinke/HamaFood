import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class NotificationsScreen extends ConsumerWidget { const NotificationsScreen({super.key}); @override Widget build(BuildContext context, WidgetRef ref) { final data = ref.watch(notificationsProvider); return AppScaffold(title: 'Notifications', actions: [TextButton(onPressed: () async { await ref.read(repoProvider).markAllNotificationsRead(); ref.invalidate(notificationsProvider); ref.invalidate(dashboardProvider); }, child: const Text('Mark all read'))], body: data.when(data: (xs) { if (xs.isEmpty) return const EmptyView('No notifications', icon: Icons.notifications_none); return ListView.separated(padding: const EdgeInsets.all(16), itemCount: xs.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) => _tile(context, ref, xs[i])); }, loading: () => const LoadingView(), error: (e, _) => ErrorView(e, retry: () => ref.invalidate(notificationsProvider)))); }
  Widget _tile(BuildContext context, WidgetRef ref, NotificationItem n) => Card(child: ListTile(onTap: () async { if (!n.isRead) { await ref.read(repoProvider).markNotificationRead(n.id); ref.invalidate(notificationsProvider); ref.invalidate(dashboardProvider); } }, leading: CircleAvatar(child: Icon(n.isRead ? Icons.notifications_none : Icons.notifications_active)), title: Text(n.title, style: TextStyle(fontWeight: n.isRead ? FontWeight.normal : FontWeight.bold)), subtitle: Text('${n.body}\n${dateTimeText(n.createdAt)}'), isThreeLine: true, trailing: n.isRead ? null : const Icon(Icons.brightness_1, size: 10)));
}
