// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:go_router/go_router.dart';
// import '../models/models.dart';
// import '../providers/providers.dart';
// import '../services/app_helpers.dart';
// import '../widgets/app_scaffold.dart';
// import '../widgets/common.dart';

// class WorkItemDetailScreen extends ConsumerStatefulWidget {
//   final String workItemId;
//   const WorkItemDetailScreen({super.key, required this.workItemId});
//   @override
//   ConsumerState<WorkItemDetailScreen> createState() => _WorkItemDetailScreenState();
// }

// class _WorkItemDetailScreenState extends ConsumerState<WorkItemDetailScreen> with SingleTickerProviderStateMixin {
//   late final TabController _tabs;

//   @override
//   void initState() {
//     super.initState();
//     _tabs = TabController(length: 5, vsync: this);
//   }

//   @override
//   void dispose() {
//     _tabs.dispose();
//     super.dispose();
//   }

//   Future<WorkItem> _load() => ref.read(repoProvider).workItemById(widget.workItemId);

//   @override
//   Widget build(BuildContext context) {
//     return AppScaffold(
//       title: 'Work Item',
//       showBack: true,
//       body: FutureBuilder<WorkItem>(
//         future: _load(),
//         builder: (context, snapshot) {
//           if (snapshot.connectionState != ConnectionState.done) return const LoadingView();
//           if (snapshot.hasError) return ErrorView(snapshot.error!);
//           final workItem = snapshot.data!;
//           final profile = ref.watch(profileProvider).valueOrNull;
//           return Column(
//             children: [
//               Padding(
//                 padding: const EdgeInsets.fromLTRB(16, 14, 16, 5),
//                 child: Row(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(workItem.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
//                           Text(workItem.code, style: Theme.of(context).textTheme.bodySmall),
//                         ],
//                       ),
//                     ),
//                     StatusChip(workItem.status),
//                     const SizedBox(width: 6),
//                     PriorityChip(workItem.priority),
//                   ],
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 16),
//                 child: Row(
//                   children: [
//                     Text(labelize(workItem.category)),
//                     const Spacer(),
//                     Text('Deadline: ${shortDate(workItem.deadline)}'),
//                   ],
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
//                 child: _actionBar(workItem, profile),
//               ),
//               TabBar(
//                 controller: _tabs,
//                 isScrollable: true,
//                 tabs: const [
//                   Tab(text: 'Overview'),
//                   Tab(text: 'Tasks'),
//                   Tab(text: 'Activities'),
//                   Tab(text: 'Timeline'),
//                   Tab(text: 'Files'),
//                 ],
//               ),
//               Expanded(
//                 child: TabBarView(
//                   controller: _tabs,
//                   children: [
//                     _overview(workItem),
//                     _tasks(workItem),
//                     _activities(),
//                     _timeline(),
//                     _files(),
//                   ],
//                 ),
//               ),
//             ],
//           );
//         },
//       ),
//     );
//   }

//   Widget _actionBar(WorkItem workItem, Profile? profile) {
//     return Wrap(
//       spacing: 8,
//       runSpacing: 8,
//       children: [
//         if (profile?.isGm == true)
//           FilledButton.icon(onPressed: _newTask, icon: const Icon(Icons.add_task), label: const Text('New Task')),
//         if (workItem.status != 'completed' && workItem.status != 'cancelled')
//           OutlinedButton.icon(onPressed: () => _setStatus(workItem), icon: const Icon(Icons.tune), label: const Text('Change Status')),
//         if (profile?.isGm == true || profile?.isManager == true) ...[
//           if (workItem.status == 'completed')
//             OutlinedButton.icon(onPressed: _reopen, icon: const Icon(Icons.replay), label: const Text('Reopen')),
//           if (workItem.status != 'completed')
//             OutlinedButton.icon(onPressed: _complete, icon: const Icon(Icons.check_circle_outline), label: const Text('Close')),
//           OutlinedButton.icon(onPressed: _archive, icon: const Icon(Icons.archive_outlined), label: const Text('Archive')),
//         ],
//         OutlinedButton.icon(onPressed: _newComment, icon: const Icon(Icons.comment_outlined), label: const Text('Comment')),
//       ],
//     );
//   }

//   Widget _overview(WorkItem workItem) {
//     final people = ref.watch(workItemParticipantsProvider(workItem.id));
//     final comments = ref.watch(commentsProvider('work_item|${workItem.id}'));
//     return ListView(
//       padding: const EdgeInsets.all(16),
//       children: [
//         if (workItem.description?.isNotEmpty == true)
//           Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(workItem.description!))),
//         Card(
//           child: Padding(
//             padding: const EdgeInsets.all(16),
//             child: Wrap(
//               spacing: 24,
//               runSpacing: 14,
//               children: [
//                 LabeledValue('Status', labelize(workItem.status)),
//                 LabeledValue('Priority', labelize(workItem.priority)),
//                 LabeledValue('Created', dateTimeText(workItem.createdAt)),
//                 LabeledValue('Updated', dateTimeText(workItem.updatedAt)),
//                 LabeledValue('Final Result', workItem.finalResult ?? '—'),
//               ],
//             ),
//           ),
//         ),
//         Card(
//           child: Padding(
//             padding: const EdgeInsets.all(16),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     const Expanded(child: Text('Participants', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
//                     IconButton(onPressed: _manageParticipants, icon: const Icon(Icons.person_add_alt_1)),
//                   ],
//                 ),
//                 people.when(
//                   data: (users) => users.isEmpty
//                       ? const Text('No additional participants.')
//                       : Wrap(
//                           spacing: 8,
//                           runSpacing: 8,
//                           children: users.map((user) => Chip(label: Text(user.fullName))).toList(),
//                         ),
//                   loading: () => const LinearProgressIndicator(),
//                   error: (e, _) => Text('Error: $e'),
//                 ),
//               ],
//             ),
//           ),
//         ),
//         Card(
//           child: Padding(
//             padding: const EdgeInsets.all(16),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 const Text('Comments', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
//                 const SizedBox(height: 8),
//                 comments.when(
//                   data: (items) => items.isEmpty
//                       ? const Text('No comments yet.')
//                       : Column(
//                           children: items
//                               .map((item) => ListTile(
//                                     contentPadding: EdgeInsets.zero,
//                                     title: Text(item.creatorName ?? 'User'),
//                                     subtitle: Text(item.content),
//                                     trailing: Text(shortDate(item.createdAt)),
//                                   ))
//                               .toList(),
//                         ),
//                   loading: () => const LinearProgressIndicator(),
//                   error: (e, _) => Text('Error: $e'),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   Widget _tasks(WorkItem workItem) {
//     final data = ref.watch(workItemTasksProvider(workItem.id));
//     return data.when(
//       data: (tasks) => tasks.isEmpty
//           ? const EmptyView('No tasks in this Work Item.', icon: Icons.task_alt)
//           : ListView.separated(
//               padding: const EdgeInsets.all(16),
//               itemCount: tasks.length,
//               separatorBuilder: (_, __) => const SizedBox(height: 8),
//               itemBuilder: (_, i) => Card(
//                 child: ListTile(
//                   onTap: () => context.go('/tasks/${tasks[i].id}'),
//                   leading: const CircleAvatar(child: Icon(Icons.task_alt)),
//                   title: Text(tasks[i].title),
//                   subtitle: Text('${tasks[i].code} • ${tasks[i].deadline == null ? 'No deadline' : dateTimeText(tasks[i].deadline)}'),
//                   trailing: StatusChip(tasks[i].status),
//                 ),
//               ),
//             ),
//       loading: () => const LoadingView(),
//       error: (e, _) => ErrorView(e, retry: () => ref.invalidate(workItemTasksProvider(workItem.id))),
//     );
//   }

//   Widget _activities() {
//     final data = ref.watch(workItemActivitiesProvider(widget.workItemId));
//     return Column(
//       children: [
//         Align(
//           alignment: Alignment.centerRight,
//           child: Padding(
//             padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
//             child: FilledButton.icon(onPressed: _newActivity, icon: const Icon(Icons.add), label: const Text('Add Activity')),
//           ),
//         ),
//         Expanded(
//           child: data.when(
//             data: (items) => items.isEmpty
//                 ? const EmptyView('No activities.', icon: Icons.event_note_outlined)
//                 : ListView.separated(
//                     padding: const EdgeInsets.all(16),
//                     itemCount: items.length,
//                     separatorBuilder: (_, __) => const SizedBox(height: 8),
//                     itemBuilder: (_, i) => Card(
//                       child: ListTile(
//                         leading: const CircleAvatar(child: Icon(Icons.event_note_outlined)),
//                         title: Text(items[i].description),
//                         subtitle: Text(
//                           '${labelize(items[i].type)} • ${dateTimeText(items[i].dateTime)}'
//                           '${items[i].withWhom == null ? '' : '\nWith: ${items[i].withWhom}'}'
//                           '${items[i].toWhom == null ? '' : '\nTo: ${items[i].toWhom}'}'
//                           '${items[i].result == null ? '' : '\nResult: ${items[i].result}'}'
//                           '${items[i].nextAction == null ? '' : '\nNext: ${items[i].nextAction}'}',
//                         ),
//                         isThreeLine: true,
//                       ),
//                     ),
//                   ),
//             loading: () => const LoadingView(),
//             error: (e, _) => ErrorView(e, retry: () => ref.invalidate(workItemActivitiesProvider(widget.workItemId))),
//           ),
//         ),
//       ],
//     );
//   }

//   Widget _timeline() {
//     final data = ref.watch(workItemTimelineProvider(widget.workItemId));
//     return data.when(
//       data: (items) => items.isEmpty
//           ? const EmptyView('No timeline events.', icon: Icons.timeline)
//           : ListView.separated(
//               padding: const EdgeInsets.all(16),
//               itemCount: items.length,
//               separatorBuilder: (_, __) => const Divider(height: 1),
//               itemBuilder: (_, i) => ListTile(
//                 leading: const CircleAvatar(child: Icon(Icons.history)),
//                 title: Text(items[i].title),
//                 subtitle: Text('${dateTimeText(items[i].createdAt)}${items[i].description == null ? '' : '\n${items[i].description}'}'),
//                 isThreeLine: items[i].description != null,
//               ),
//             ),
//       loading: () => const LoadingView(),
//       error: (e, _) => ErrorView(e, retry: () => ref.invalidate(workItemTimelineProvider(widget.workItemId))),
//     );
//   }

//   Widget _files() {
//     return FutureBuilder<List<AttachmentItem>>(
//       future: ref.read(repoProvider).attachments(parentType: 'work_item', parentId: widget.workItemId),
//       builder: (context, snapshot) {
//         if (snapshot.connectionState != ConnectionState.done) return const LoadingView();
//         if (snapshot.hasError) return ErrorView(snapshot.error!);
//         final items = snapshot.data ?? [];
//         return Column(
//           children: [
//             Align(
//               alignment: Alignment.centerRight,
//               child: Padding(
//                 padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
//                 child: FilledButton.icon(onPressed: _addAttachment, icon: const Icon(Icons.attach_file), label: const Text('Add File')),
//               ),
//             ),
//             Expanded(
//               child: items.isEmpty
//                   ? const EmptyView('No files.', icon: Icons.folder_open_outlined)
//                   : ListView.separated(
//                       padding: const EdgeInsets.all(16),
//                       itemCount: items.length,
//                       separatorBuilder: (_, __) => const SizedBox(height: 8),
//                       itemBuilder: (_, i) => Card(
//                         child: ListTile(
//                           leading: const Icon(Icons.insert_drive_file_outlined),
//                           title: Text(items[i].fileName),
//                           subtitle: Text('${items[i].mimeType ?? 'file'} • ${items[i].storagePath}'),
//                           trailing: Text(shortDate(items[i].createdAt)),
//                         ),
//                       ),
//                     ),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   Future<void> _setStatus(WorkItem workItem) async {
//     String status = workItem.status == 'completed' || workItem.status == 'cancelled' ? 'in_progress' : workItem.status;
//     await showDialog<void>(
//       context: context,
//       builder: (dialogContext) => StatefulBuilder(
//         builder: (dialogContext, setDialogState) => AlertDialog(
//           title: const Text('Change Status'),
//           content: DropdownButtonFormField<String>(
//             value: status,
//             items: const [
//               DropdownMenuItem(value: 'open', child: Text('Open')),
//               DropdownMenuItem(value: 'in_progress', child: Text('In Progress')),
//               DropdownMenuItem(value: 'waiting', child: Text('Waiting')),
//               DropdownMenuItem(value: 'cancelled', child: Text('Cancelled')),
//             ],
//             onChanged: (value) => setDialogState(() => status = value ?? status),
//           ),
//           actions: [
//             TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
//             FilledButton(
//               onPressed: () async {
//                 try {
//                   await ref.read(repoProvider).setWorkItemStatus(workItem.id, status);
//                   if (dialogContext.mounted) Navigator.pop(dialogContext);
//                   setState(() {});
//                   ref.invalidate(workItemsProvider);
//                 } catch (e) {
//                   Ui.snack(context, 'Error: $e');
//                 }
//               },
//               child: const Text('Save'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Future<void> _newTask() async {
//     final users = await ref.read(activeUsersProvider.future);
//     final workItems = await ref.read(repoProvider).workItems();
//     if (!mounted) return;
//     final title = TextEditingController();
//     final description = TextEditingController();
//     String priority = 'normal';
//     String? responsible = users.isEmpty ? null : users.first.id;
//     String? follower;
//     DateTime? deadline;
//     bool evidenceRequired = true;
//     await showDialog<void>(
//       context: context,
//       builder: (dialogContext) => StatefulBuilder(
//         builder: (dialogContext, setDialogState) => AlertDialog(
//           title: const Text('New Task'),
//           content: SizedBox(
//             width: 600,
//             child: SingleChildScrollView(
//               child: Column(
//                 children: [
//                   TextField(controller: title, decoration: const InputDecoration(labelText: 'Title *')),
//                   TextField(controller: description, maxLines: 4, decoration: const InputDecoration(labelText: 'Description')),
//                   DropdownButtonFormField<String>(
//                     value: priority,
//                     decoration: const InputDecoration(labelText: 'Priority'),
//                     items: const [
//                       DropdownMenuItem(value: 'normal', child: Text('Normal')),
//                       DropdownMenuItem(value: 'urgent', child: Text('Urgent')),
//                     ],
//                     onChanged: (value) => setDialogState(() => priority = value ?? 'normal'),
//                   ),
//                   DropdownButtonFormField<String>(
//                     value: responsible,
//                     decoration: const InputDecoration(labelText: 'Responsible *'),
//                     items: users.map((u) => DropdownMenuItem(value: u.id, child: Text(u.fullName))).toList(),
//                     onChanged: (value) => setDialogState(() => responsible = value),
//                   ),
//                   DropdownButtonFormField<String>(
//                     value: follower,
//                     decoration: const InputDecoration(labelText: 'Follower'),
//                     items: [
//                       const DropdownMenuItem<String>(value: null, child: Text('No follower')),
//                       ...users.map((u) => DropdownMenuItem<String>(value: u.id, child: Text(u.fullName))),
//                     ],
//                     onChanged: (value) => setDialogState(() => follower = value),
//                   ),
//                   DropdownButtonFormField<String>(
//                     value: workItemId,
//                     decoration: const InputDecoration(labelText: 'Work Item'),
//                     items: [
//                       DropdownMenuItem<String>(value: workItemId, child: Text(workItem.title)),
//                       ...workItems.where((w) => w.id != workItemId).map((w) => DropdownMenuItem<String>(value: w.id, child: Text('${w.code} • ${w.title}'))),
//                     ],
//                     onChanged: (_) {},
//                   ),
//                   SwitchListTile(value: evidenceRequired, title: const Text('Evidence required'), onChanged: (value) => setDialogState(() => evidenceRequired = value)),
//                   ListTile(
//                     contentPadding: EdgeInsets.zero,
//                     title: Text(deadline == null ? 'No deadline' : 'Deadline: ${dateTimeText(deadline)}'),
//                     trailing: IconButton(
//                       icon: const Icon(Icons.event),
//                       onPressed: () async {
//                         final d = await showDatePicker(context: dialogContext, firstDate: DateTime.now(), lastDate: DateTime(2100), initialDate: DateTime.now());
//                         if (d != null) setDialogState(() => deadline = DateTime(d.year, d.month, d.day, 17));
//                       },
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//           actions: [
//             TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
//             FilledButton(
//               onPressed: () async {
//                 if (title.text.trim().isEmpty || responsible == null) return;
//                 try {
//                   await ref.read(repoProvider).createTask(
//                     title: title.text.trim(),
//                     description: description.text.trim().isEmpty ? null : description.text.trim(),
//                     workItemId: workItemId,
//                     priority: priority,
//                     deadline: deadline,
//                     responsibleId: responsible!,
//                     followerId: follower,
//                     evidenceRequired: evidenceRequired,
//                   );
//                   if (dialogContext.mounted) Navigator.pop(dialogContext);
//                   ref.invalidate(workItemTasksProvider(widget.workItemId));
//                   ref.invalidate(tasksProvider);
//                 } catch (e) {
//                   Ui.snack(context, 'Error: $e');
//                 }
//               },
//               child: const Text('Create'),
//             ),
//           ],
//         ),
//       ),
//     );
//     title.dispose(); description.dispose();
//   }

//   Future<void> _newActivity() async {
//     final description = TextEditingController();
//     final withWhom = TextEditingController();
//     final to = TextEditingController();
//     final result = TextEditingController();
//     final nextAction = TextEditingController();
//     String type = 'note';
//     await showDialog<void>(
//       context: context,
//       builder: (dialogContext) => StatefulBuilder(
//         builder: (dialogContext, setDialogState) => AlertDialog(
//           title: const Text('Add Activity'),
//           content: SizedBox(
//             width: 580,
//             child: SingleChildScrollView(
//               child: Column(
//                 children: [
//                   DropdownButtonFormField<String>(
//                     value: type,
//                     items: const [
//                       DropdownMenuItem(value: 'phone_call', child: Text('Phone Call')),
//                       DropdownMenuItem(value: 'email', child: Text('Email')),
//                       DropdownMenuItem(value: 'meeting', child: Text('Meeting')),
//                       DropdownMenuItem(value: 'visit', child: Text('Visit')),
//                       DropdownMenuItem(value: 'message', child: Text('Message')),
//                       DropdownMenuItem(value: 'document', child: Text('Document')),
//                       DropdownMenuItem(value: 'note', child: Text('Note')),
//                       DropdownMenuItem(value: 'inspection', child: Text('Inspection')),
//                       DropdownMenuItem(value: 'voice', child: Text('Voice')),
//                       DropdownMenuItem(value: 'other', child: Text('Other')),
//                     ],
//                     onChanged: (value) => setDialogState(() => type = value ?? 'note'),
//                   ),
//                   TextField(controller: withWhom, decoration: const InputDecoration(labelText: 'With whom')),
//                   TextField(controller: to, decoration: const InputDecoration(labelText: 'To')),
//                   TextField(controller: description, maxLines: 6, decoration: const InputDecoration(labelText: 'Description *')),
//                   TextField(controller: result, maxLines: 3, decoration: const InputDecoration(labelText: 'Result')),
//                   TextField(controller: nextAction, maxLines: 3, decoration: const InputDecoration(labelText: 'Next Action')),
//                 ],
//               ),
//             ),
//           ),
//           actions: [
//             TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
//             FilledButton(
//               onPressed: () async {
//                 if (description.text.trim().isEmpty) return;
//                 try {
//                   await ref.read(repoProvider).addActivity(
//                     type: type,
//                     dateTime: DateTime.now(),
//                     description: description.text.trim(),
//                     withWhom: withWhom.text.trim().isEmpty ? null : withWhom.text.trim(),
//                     toWhom: to.text.trim().isEmpty ? null : to.text.trim(),
//                     result: result.text.trim().isEmpty ? null : result.text.trim(),
//                     nextAction: nextAction.text.trim().isEmpty ? null : nextAction.text.trim(),
//                     workItemId: widget.workItemId,
//                   );
//                   if (dialogContext.mounted) Navigator.pop(dialogContext);
//                   ref.invalidate(workItemActivitiesProvider(widget.workItemId));
//                   ref.invalidate(workItemTimelineProvider(widget.workItemId));
//                 } catch (e) {
//                   Ui.snack(context, 'Error: $e');
//                 }
//               },
//               child: const Text('Save'),
//             ),
//           ],
//         ),
//       ),
//     );
//     description.dispose(); withWhom.dispose(); to.dispose(); result.dispose(); nextAction.dispose();
//   }

//   Future<void> _newComment() async {
//     final controller = TextEditingController();
//     await showDialog<void>(
//       context: context,
//       builder: (dialogContext) => AlertDialog(
//         title: const Text('Comment'),
//         content: TextField(controller: controller, maxLines: 6, decoration: const InputDecoration(hintText: 'Write comment… @username')),
//         actions: [
//           TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
//           FilledButton(
//             onPressed: () async {
//               if (controller.text.trim().isEmpty) return;
//               try {
//                 await ref.read(repoProvider).addComment(parentType: 'work_item', parentId: widget.workItemId, content: controller.text.trim());
//                 if (dialogContext.mounted) Navigator.pop(dialogContext);
//                 ref.invalidate(commentsProvider('work_item|${widget.workItemId}'));
//               } catch (e) { Ui.snack(context, 'Error: $e'); }
//             },
//             child: const Text('Post'),
//           ),
//         ],
//       ),
//     );
//     controller.dispose();
//   }

//   Future<void> _complete() async {
//     final result = TextEditingController();
//     await showDialog<void>(
//       context: context,
//       builder: (dialogContext) => AlertDialog(
//         title: const Text('Close Work Item'),
//         content: TextField(controller: result, maxLines: 6, decoration: const InputDecoration(labelText: 'Final Result *')),
//         actions: [
//           TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
//           FilledButton(
//             onPressed: () async {
//               if (result.text.trim().isEmpty) return;
//               try {
//                 await ref.read(repoProvider).completeWorkItem(widget.workItemId, result.text.trim());
//                 if (dialogContext.mounted) Navigator.pop(dialogContext);
//                 setState(() {});
//                 ref.invalidate(workItemsProvider);
//               } catch (e) { Ui.snack(context, 'Error: $e'); }
//             },
//             child: const Text('Close'),
//           ),
//         ],
//       ),
//     );
//     result.dispose();
//   }

//   Future<void> _reopen() async {
//     if (await Ui.confirm(context, title: 'Reopen', message: 'Reopen this Work Item?') == true) {
//       try { await ref.read(repoProvider).reopenWorkItem(widget.workItemId); setState(() {}); } catch (e) { Ui.snack(context, 'Error: $e'); }
//     }
//   }

//   Future<void> _archive() async {
//     if (await Ui.confirm(context, title: 'Archive', message: 'Archive this Work Item?') == true) {
//       try { await ref.read(repoProvider).archiveWorkItem(widget.workItemId); if (mounted) context.go('/work-items'); } catch (e) { Ui.snack(context, 'Error: $e'); }
//     }
//   }

//   Future<void> _manageParticipants() async {
//     final users = await ref.read(activeUsersProvider.future);
//     final existing = await ref.read(repoProvider).workItemParticipants(widget.workItemId);
//     final selected = existing.map((user) => user.id).toSet();
//     await showDialog<void>(
//       context: context,
//       builder: (dialogContext) => StatefulBuilder(
//         builder: (dialogContext, setDialogState) => AlertDialog(
//           title: const Text('Participants'),
//           content: SizedBox(
//             width: 520,
//             child: SingleChildScrollView(
//               child: Column(
//                 children: users.map((user) => CheckboxListTile(
//                   value: selected.contains(user.id),
//                   title: Text(user.fullName),
//                   subtitle: Text('@${user.username}'),
//                   onChanged: (value) async {
//                     try {
//                       if (value == true) {
//                         await ref.read(repoProvider).addWorkItemParticipant(widget.workItemId, user.id);
//                         selected.add(user.id);
//                       } else {
//                         await ref.read(repoProvider).removeWorkItemParticipant(widget.workItemId, user.id);
//                         selected.remove(user.id);
//                       }
//                       setDialogState(() {});
//                     } catch (e) { Ui.snack(context, 'Error: $e'); }
//                   },
//                 )).toList(),
//               ),
//             ),
//           ),
//           actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Done'))],
//         ),
//       ),
//     );
//     ref.invalidate(workItemParticipantsProvider(widget.workItemId));
//     ref.invalidate(workItemTimelineProvider(widget.workItemId));
//   }

//   Future<void> _addAttachment() async {
//     final fileName = TextEditingController();
//     final storagePath = TextEditingController();
//     final mimeType = TextEditingController();
//     await showDialog<void>(
//       context: context,
//       builder: (dialogContext) => AlertDialog(
//         title: const Text('Add File'),
//         content: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             TextField(controller: fileName, decoration: const InputDecoration(labelText: 'File name *')),
//             TextField(controller: storagePath, decoration: const InputDecoration(labelText: 'Supabase Storage path *')),
//             TextField(controller: mimeType, decoration: const InputDecoration(labelText: 'MIME type')),
//           ],
//         ),
//         actions: [
//           TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
//           FilledButton(
//             onPressed: () async {
//               if (fileName.text.trim().isEmpty || storagePath.text.trim().isEmpty) return;
//               try {
//                 await ref.read(repoProvider).addAttachmentMetadata(
//                   parentType: 'work_item', parentId: widget.workItemId,
//                   fileName: fileName.text.trim(), storagePath: storagePath.text.trim(),
//                   mimeType: mimeType.text.trim().isEmpty ? null : mimeType.text.trim(),
//                 );
//                 if (dialogContext.mounted) Navigator.pop(dialogContext);
//                 setState(() {});
//               } catch (e) { Ui.snack(context, 'Error: $e'); }
//             },
//             child: const Text('Save'),
//           ),
//         ],
//       ),
//     );
//     fileName.dispose(); storagePath.dispose(); mimeType.dispose();
//   }
// }
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class WorkItemDetailScreen extends ConsumerStatefulWidget {
  final String workItemId;
  const WorkItemDetailScreen({super.key, required this.workItemId});
  @override
  ConsumerState<WorkItemDetailScreen> createState() => _WorkItemDetailScreenState();
}

class _WorkItemDetailScreenState extends ConsumerState<WorkItemDetailScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<WorkItem> _load() => ref.read(repoProvider).workItemById(widget.workItemId);

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'Work Item',
      showBack: true,
      body: FutureBuilder<WorkItem>(
        future: _load(),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const LoadingView();
          if (snapshot.hasError) return ErrorView(snapshot.error!);
          final workItem = snapshot.data!;
          final profile = ref.watch(profileProvider).valueOrNull;
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 5),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(workItem.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                          Text(workItem.code, style: Theme.of(context).textTheme.bodySmall),
                        ],
                      ),
                    ),
                    StatusChip(workItem.status),
                    const SizedBox(width: 6),
                    PriorityChip(workItem.priority),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Text(labelize(workItem.category)),
                    const Spacer(),
                    Text('Deadline: ${shortDate(workItem.deadline)}'),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                child: _actionBar(workItem, profile),
              ),
              TabBar(
                controller: _tabs,
                isScrollable: true,
                tabs: const [
                  Tab(text: 'Overview'),
                  Tab(text: 'Tasks'),
                  Tab(text: 'Activities'),
                  Tab(text: 'Timeline'),
                  Tab(text: 'Files'),
                ],
              ),
              Expanded(
                child: TabBarView(
                  controller: _tabs,
                  children: [
                    _overview(workItem),
                    _tasks(workItem),
                    _activities(),
                    _timeline(),
                    _files(),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _actionBar(WorkItem workItem, Profile? profile) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        if (profile?.isGm == true)
          FilledButton.icon(onPressed: _newTask, icon: const Icon(Icons.add_task), label: const Text('New Task')),
        if (workItem.status != 'completed' && workItem.status != 'cancelled')
          OutlinedButton.icon(onPressed: () => _setStatus(workItem), icon: const Icon(Icons.tune), label: const Text('Change Status')),
        if (profile?.isGm == true || profile?.isManager == true) ...[
          if (workItem.status == 'completed')
            OutlinedButton.icon(onPressed: _reopen, icon: const Icon(Icons.replay), label: const Text('Reopen')),
          if (workItem.status != 'completed')
            OutlinedButton.icon(onPressed: _complete, icon: const Icon(Icons.check_circle_outline), label: const Text('Close')),
          OutlinedButton.icon(onPressed: _archive, icon: const Icon(Icons.archive_outlined), label: const Text('Archive')),
        ],
        OutlinedButton.icon(onPressed: _newComment, icon: const Icon(Icons.comment_outlined), label: const Text('Comment')),
      ],
    );
  }

  Widget _overview(WorkItem workItem) {
    final people = ref.watch(workItemParticipantsProvider(workItem.id));
    final comments = ref.watch(commentsProvider('work_item|${workItem.id}'));
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (workItem.description?.isNotEmpty == true)
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(workItem.description!))),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Wrap(
              spacing: 24,
              runSpacing: 14,
              children: [
                LabeledValue('Status', labelize(workItem.status)),
                LabeledValue('Priority', labelize(workItem.priority)),
                LabeledValue('Created', dateTimeText(workItem.createdAt)),
                LabeledValue('Updated', dateTimeText(workItem.updatedAt)),
                LabeledValue('Final Result', workItem.finalResult ?? '—'),
              ],
            ),
          ),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(child: Text('Participants', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                    IconButton(onPressed: _manageParticipants, icon: const Icon(Icons.person_add_alt_1)),
                  ],
                ),
                people.when(
                  data: (users) => users.isEmpty
                      ? const Text('No additional participants.')
                      : Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: users.map((user) => Chip(label: Text(user.fullName))).toList(),
                        ),
                  loading: () => const LinearProgressIndicator(),
                  error: (e, _) => Text('Error: $e'),
                ),
              ],
            ),
          ),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Comments', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                comments.when(
                  data: (items) => items.isEmpty
                      ? const Text('No comments yet.')
                      : Column(
                          children: items
                              .map((item) => ListTile(
                                    contentPadding: EdgeInsets.zero,
                                    title: Text(item.creatorName ?? 'User'),
                                    subtitle: Text(item.content),
                                    trailing: Text(shortDate(item.createdAt)),
                                  ))
                              .toList(),
                        ),
                  loading: () => const LinearProgressIndicator(),
                  error: (e, _) => Text('Error: $e'),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _tasks(WorkItem workItem) {
    final data = ref.watch(workItemTasksProvider(workItem.id));
    return data.when(
      data: (tasks) => tasks.isEmpty
          ? const EmptyView('No tasks in this Work Item.', icon: Icons.task_alt)
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: tasks.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) => Card(
                child: ListTile(
                  onTap: () => context.go('/tasks/${tasks[i].id}'),
                  leading: const CircleAvatar(child: Icon(Icons.task_alt)),
                  title: Text(tasks[i].title),
                  subtitle: Text('${tasks[i].code} • ${tasks[i].deadline == null ? 'No deadline' : dateTimeText(tasks[i].deadline)}'),
                  trailing: StatusChip(tasks[i].status),
                ),
              ),
            ),
      loading: () => const LoadingView(),
      error: (e, _) => ErrorView(e, retry: () => ref.invalidate(workItemTasksProvider(workItem.id))),
    );
  }

  Widget _activities() {
    final data = ref.watch(workItemActivitiesProvider(widget.workItemId));
    return Column(
      children: [
        Align(
          alignment: Alignment.centerRight,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            child: FilledButton.icon(onPressed: _newActivity, icon: const Icon(Icons.add), label: const Text('Add Activity')),
          ),
        ),
        Expanded(
          child: data.when(
            data: (items) => items.isEmpty
                ? const EmptyView('No activities.', icon: Icons.event_note_outlined)
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) => Card(
                      child: ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.event_note_outlined)),
                        title: Text(items[i].description),
                        subtitle: Text(
                          '${labelize(items[i].type)} • ${dateTimeText(items[i].dateTime)}'
                          '${items[i].withWhom == null ? '' : '\nWith: ${items[i].withWhom}'}'
                          '${items[i].toWhom == null ? '' : '\nTo: ${items[i].toWhom}'}'
                          '${items[i].result == null ? '' : '\nResult: ${items[i].result}'}'
                          '${items[i].nextAction == null ? '' : '\nNext: ${items[i].nextAction}'}',
                        ),
                        isThreeLine: true,
                      ),
                    ),
                  ),
            loading: () => const LoadingView(),
            error: (e, _) => ErrorView(e, retry: () => ref.invalidate(workItemActivitiesProvider(widget.workItemId))),
          ),
        ),
      ],
    );
  }

  Widget _timeline() {
    final data = ref.watch(workItemTimelineProvider(widget.workItemId));
    return data.when(
      data: (items) => items.isEmpty
          ? const EmptyView('No timeline events.', icon: Icons.timeline)
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: items.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) => ListTile(
                leading: const CircleAvatar(child: Icon(Icons.history)),
                title: Text(items[i].title),
                subtitle: Text('${dateTimeText(items[i].createdAt)}${items[i].description == null ? '' : '\n${items[i].description}'}'),
                isThreeLine: items[i].description != null,
              ),
            ),
      loading: () => const LoadingView(),
      error: (e, _) => ErrorView(e, retry: () => ref.invalidate(workItemTimelineProvider(widget.workItemId))),
    );
  }

  Widget _files() {
    return FutureBuilder<List<AttachmentItem>>(
      future: ref.read(repoProvider).attachments(parentType: 'work_item', parentId: widget.workItemId),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const LoadingView();
        if (snapshot.hasError) return ErrorView(snapshot.error!);
        final items = snapshot.data ?? [];
        return Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: FilledButton.icon(onPressed: _addAttachment, icon: const Icon(Icons.attach_file), label: const Text('Add File')),
              ),
            ),
            Expanded(
              child: items.isEmpty
                  ? const EmptyView('No files.', icon: Icons.folder_open_outlined)
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, i) => Card(
                        child: ListTile(
                          leading: const Icon(Icons.insert_drive_file_outlined),
                          title: Text(items[i].fileName),
                          subtitle: Text('${items[i].mimeType ?? 'file'} • ${items[i].storagePath}'),
                          trailing: Text(shortDate(items[i].createdAt)),
                        ),
                      ),
                    ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _setStatus(WorkItem workItem) async {
    String status = workItem.status == 'completed' || workItem.status == 'cancelled' ? 'in_progress' : workItem.status;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Change Status'),
          content: DropdownButtonFormField<String>(
            value: status,
            items: const [
              DropdownMenuItem(value: 'open', child: Text('Open')),
              DropdownMenuItem(value: 'in_progress', child: Text('In Progress')),
              DropdownMenuItem(value: 'waiting', child: Text('Waiting')),
              DropdownMenuItem(value: 'cancelled', child: Text('Cancelled')),
            ],
            onChanged: (value) => setDialogState(() => status = value ?? status),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () async {
                try {
                  await ref.read(repoProvider).setWorkItemStatus(workItem.id, status);
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                  setState(() {});
                  ref.invalidate(workItemsProvider);
                } catch (e) {
                  Ui.snack(context, 'Error: $e');
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _newTask() async {
    final users = await ref.read(activeUsersProvider.future);
    final workItems = await ref.read(repoProvider).workItems();
    if (!mounted) return;
    final title = TextEditingController();
    final description = TextEditingController();
    String priority = 'normal';
    String? responsible = users.isEmpty ? null : users.first.id;
    String? follower;
    DateTime? deadline;
    bool evidenceRequired = true;
    String selectedWorkItemId = widget.workItemId;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('New Task'),
          content: SizedBox(
            width: 600,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  TextField(controller: title, decoration: const InputDecoration(labelText: 'Title *')),
                  TextField(controller: description, maxLines: 4, decoration: const InputDecoration(labelText: 'Description')),
                  DropdownButtonFormField<String>(
                    value: priority,
                    decoration: const InputDecoration(labelText: 'Priority'),
                    items: const [
                      DropdownMenuItem(value: 'normal', child: Text('Normal')),
                      DropdownMenuItem(value: 'urgent', child: Text('Urgent')),
                    ],
                    onChanged: (value) => setDialogState(() => priority = value ?? 'normal'),
                  ),
                  DropdownButtonFormField<String>(
                    value: responsible,
                    decoration: const InputDecoration(labelText: 'Responsible *'),
                    items: users.map((u) => DropdownMenuItem(value: u.id, child: Text(u.fullName))).toList(),
                    onChanged: (value) => setDialogState(() => responsible = value),
                  ),
                  DropdownButtonFormField<String>(
                    value: follower,
                    decoration: const InputDecoration(labelText: 'Follower'),
                    items: [
                      const DropdownMenuItem<String>(value: null, child: Text('No follower')),
                      ...users.map((u) => DropdownMenuItem<String>(value: u.id, child: Text(u.fullName))),
                    ],
                    onChanged: (value) => setDialogState(() => follower = value),
                  ),
                  DropdownButtonFormField<String>(
                    value: selectedWorkItemId,
                    decoration: const InputDecoration(labelText: 'Work Item'),
                    items: workItems
                        .map(
                          (w) => DropdownMenuItem<String>(
                            value: w.id,
                            child: Text(
                              '${w.code} • ${w.title}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      if (value != null) {
                        setDialogState(() => selectedWorkItemId = value);
                      }
                    },
                  ),
                  SwitchListTile(value: evidenceRequired, title: const Text('Evidence required'), onChanged: (value) => setDialogState(() => evidenceRequired = value)),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(deadline == null ? 'No deadline' : 'Deadline: ${dateTimeText(deadline)}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.event),
                      onPressed: () async {
                        final d = await showDatePicker(context: dialogContext, firstDate: DateTime.now(), lastDate: DateTime(2100), initialDate: DateTime.now());
                        if (d != null) setDialogState(() => deadline = DateTime(d.year, d.month, d.day, 17));
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () async {
                if (title.text.trim().isEmpty || responsible == null) return;
                try {
                  await ref.read(repoProvider).createTask(
                    title: title.text.trim(),
                    description: description.text.trim().isEmpty ? null : description.text.trim(),
                    workItemId: selectedWorkItemId,
                    priority: priority,
                    deadline: deadline,
                    responsibleId: responsible!,
                    followerId: follower,
                    evidenceRequired: evidenceRequired,
                  );
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                  ref.invalidate(workItemTasksProvider(widget.workItemId));
                  ref.invalidate(tasksProvider);
                } catch (e) {
                  Ui.snack(context, 'Error: $e');
                }
              },
              child: const Text('Create'),
            ),
          ],
        ),
      ),
    );
    title.dispose(); description.dispose();
  }

  Future<void> _newActivity() async {
    final description = TextEditingController();
    final withWhom = TextEditingController();
    final to = TextEditingController();
    final result = TextEditingController();
    final nextAction = TextEditingController();
    String type = 'note';
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Add Activity'),
          content: SizedBox(
            width: 580,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  DropdownButtonFormField<String>(
                    value: type,
                    items: const [
                      DropdownMenuItem(value: 'phone_call', child: Text('Phone Call')),
                      DropdownMenuItem(value: 'email', child: Text('Email')),
                      DropdownMenuItem(value: 'meeting', child: Text('Meeting')),
                      DropdownMenuItem(value: 'visit', child: Text('Visit')),
                      DropdownMenuItem(value: 'message', child: Text('Message')),
                      DropdownMenuItem(value: 'document', child: Text('Document')),
                      DropdownMenuItem(value: 'note', child: Text('Note')),
                      DropdownMenuItem(value: 'inspection', child: Text('Inspection')),
                      DropdownMenuItem(value: 'voice', child: Text('Voice')),
                      DropdownMenuItem(value: 'other', child: Text('Other')),
                    ],
                    onChanged: (value) => setDialogState(() => type = value ?? 'note'),
                  ),
                  TextField(controller: withWhom, decoration: const InputDecoration(labelText: 'With whom')),
                  TextField(controller: to, decoration: const InputDecoration(labelText: 'To')),
                  TextField(controller: description, maxLines: 6, decoration: const InputDecoration(labelText: 'Description *')),
                  TextField(controller: result, maxLines: 3, decoration: const InputDecoration(labelText: 'Result')),
                  TextField(controller: nextAction, maxLines: 3, decoration: const InputDecoration(labelText: 'Next Action')),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () async {
                if (description.text.trim().isEmpty) return;
                try {
                  await ref.read(repoProvider).addActivity(
                    type: type,
                    dateTime: DateTime.now(),
                    description: description.text.trim(),
                    withWhom: withWhom.text.trim().isEmpty ? null : withWhom.text.trim(),
                    toWhom: to.text.trim().isEmpty ? null : to.text.trim(),
                    result: result.text.trim().isEmpty ? null : result.text.trim(),
                    nextAction: nextAction.text.trim().isEmpty ? null : nextAction.text.trim(),
                    workItemId: widget.workItemId,
                  );
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                  ref.invalidate(workItemActivitiesProvider(widget.workItemId));
                  ref.invalidate(workItemTimelineProvider(widget.workItemId));
                } catch (e) {
                  Ui.snack(context, 'Error: $e');
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
    description.dispose(); withWhom.dispose(); to.dispose(); result.dispose(); nextAction.dispose();
  }

  Future<void> _newComment() async {
    final controller = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Comment'),
        content: TextField(controller: controller, maxLines: 6, decoration: const InputDecoration(hintText: 'Write comment… @username')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              if (controller.text.trim().isEmpty) return;
              try {
                await ref.read(repoProvider).addComment(parentType: 'work_item', parentId: widget.workItemId, content: controller.text.trim());
                if (dialogContext.mounted) Navigator.pop(dialogContext);
                ref.invalidate(commentsProvider('work_item|${widget.workItemId}'));
              } catch (e) { Ui.snack(context, 'Error: $e'); }
            },
            child: const Text('Post'),
          ),
        ],
      ),
    );
    controller.dispose();
  }

  Future<void> _complete() async {
    final result = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Close Work Item'),
        content: TextField(controller: result, maxLines: 6, decoration: const InputDecoration(labelText: 'Final Result *')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              if (result.text.trim().isEmpty) return;
              try {
                await ref.read(repoProvider).completeWorkItem(widget.workItemId, result.text.trim());
                if (dialogContext.mounted) Navigator.pop(dialogContext);
                setState(() {});
                ref.invalidate(workItemsProvider);
              } catch (e) { Ui.snack(context, 'Error: $e'); }
            },
            child: const Text('Close'),
          ),
        ],
      ),
    );
    result.dispose();
  }

  Future<void> _reopen() async {
    if (await Ui.confirm(context, title: 'Reopen', message: 'Reopen this Work Item?') == true) {
      try { await ref.read(repoProvider).reopenWorkItem(widget.workItemId); setState(() {}); } catch (e) { Ui.snack(context, 'Error: $e'); }
    }
  }

  Future<void> _archive() async {
    if (await Ui.confirm(context, title: 'Archive', message: 'Archive this Work Item?') == true) {
      try { await ref.read(repoProvider).archiveWorkItem(widget.workItemId); if (mounted) context.go('/work-items'); } catch (e) { Ui.snack(context, 'Error: $e'); }
    }
  }

  Future<void> _manageParticipants() async {
    final users = await ref.read(activeUsersProvider.future);
    final existing = await ref.read(repoProvider).workItemParticipants(widget.workItemId);
    final selected = existing.map((user) => user.id).toSet();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Participants'),
          content: SizedBox(
            width: 520,
            child: SingleChildScrollView(
              child: Column(
                children: users.map((user) => CheckboxListTile(
                  value: selected.contains(user.id),
                  title: Text(user.fullName),
                  subtitle: Text('@${user.username}'),
                  onChanged: (value) async {
                    try {
                      if (value == true) {
                        await ref.read(repoProvider).addWorkItemParticipant(widget.workItemId, user.id);
                        selected.add(user.id);
                      } else {
                        await ref.read(repoProvider).removeWorkItemParticipant(widget.workItemId, user.id);
                        selected.remove(user.id);
                      }
                      setDialogState(() {});
                    } catch (e) { Ui.snack(context, 'Error: $e'); }
                  },
                )).toList(),
              ),
            ),
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Done'))],
        ),
      ),
    );
    ref.invalidate(workItemParticipantsProvider(widget.workItemId));
    ref.invalidate(workItemTimelineProvider(widget.workItemId));
  }

  Future<void> _addAttachment() async {
    final fileName = TextEditingController();
    final storagePath = TextEditingController();
    final mimeType = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Add File'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: fileName, decoration: const InputDecoration(labelText: 'File name *')),
            TextField(controller: storagePath, decoration: const InputDecoration(labelText: 'Supabase Storage path *')),
            TextField(controller: mimeType, decoration: const InputDecoration(labelText: 'MIME type')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              if (fileName.text.trim().isEmpty || storagePath.text.trim().isEmpty) return;
              try {
                await ref.read(repoProvider).addAttachmentMetadata(
                  parentType: 'work_item', parentId: widget.workItemId,
                  fileName: fileName.text.trim(), storagePath: storagePath.text.trim(),
                  mimeType: mimeType.text.trim().isEmpty ? null : mimeType.text.trim(),
                );
                if (dialogContext.mounted) Navigator.pop(dialogContext);
                setState(() {});
              } catch (e) { Ui.snack(context, 'Error: $e'); }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    fileName.dispose(); storagePath.dispose(); mimeType.dispose();
  }
}
