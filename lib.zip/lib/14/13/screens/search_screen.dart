import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../providers/providers.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});
  @override ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  final q = TextEditingController();
  bool loading = false;
  Map<String, List<Map<String, dynamic>>> result = {};

  Future<void> _search() async {
    final term = q.text.trim();
    if (term.isEmpty) return;
    setState(() => loading = true);
    try {
      result = await ref.read(repoProvider).searchAll(term);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override void dispose() { q.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => AppScaffold(
    title: 'Search',
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(16), child: TextField(controller: q, onSubmitted: (_) => _search(), decoration: InputDecoration(prefixIcon: const Icon(Icons.search), suffixIcon: IconButton(onPressed: _search, icon: const Icon(Icons.arrow_forward)), hintText: 'Search Work Items, Tasks, Messages, Comments, Activities and Files'))),
      if (loading) const LinearProgressIndicator(),
      Expanded(child: result.isEmpty
        ? const EmptyView('Search anything', icon: Icons.manage_search)
        : ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), children: [
            _section('Work Items', result['work_items'] ?? [], (m) => context.go('/work-items/${m['id']}')),
            _section('Tasks', result['tasks'] ?? [], (m) => context.go('/tasks/${m['id']}')),
            _section('Messages', result['messages'] ?? [], (m) => context.go('/messages/${m['id']}')),
            _section('Activities', result['activities'] ?? [], null),
            _section('Comments', result['comments'] ?? [], null),
            _section('Files', result['attachments'] ?? [], null),
          ])),
    ]),
  );

  Widget _section(String title, List<Map<String, dynamic>> rows, void Function(Map<String, dynamic>)? onTap) => Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text('$title (${rows.length})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
    if (rows.isEmpty) const Padding(padding: EdgeInsets.all(10), child: Text('No results')),
    ...rows.take(10).map((m) => ListTile(contentPadding: EdgeInsets.zero, onTap: onTap == null ? null : () => onTap(m), title: Text((m['title'] ?? m['content'] ?? m['description'] ?? m['file_name'] ?? '').toString(), maxLines: 2, overflow: TextOverflow.ellipsis), subtitle: Text('${m['code'] ?? ''} ${m['status'] ?? m['type'] ?? m['storage_path'] ?? ''}'), trailing: onTap == null ? null : const Icon(Icons.chevron_right))),
  ])));
}
