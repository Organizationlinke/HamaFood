import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../services/app_helpers.dart';
import '../providers/providers.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class ActivitiesScreen extends ConsumerStatefulWidget {
  const ActivitiesScreen({super.key});
  @override ConsumerState<ActivitiesScreen> createState() => _ActivitiesScreenState();
}

class _ActivitiesScreenState extends ConsumerState<ActivitiesScreen> {
  String type = '';

  @override
  Widget build(BuildContext context) {
    final data = ref.watch(allActivitiesProvider);
    final canCreateTask = ref.watch(profileProvider).valueOrNull?.isGm == true;
    return AppScaffold(
      title: 'Activities',
      actions: [IconButton(onPressed: () => ref.invalidate(allActivitiesProvider), icon: const Icon(Icons.refresh))],
      floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Activity')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: DropdownButton<String>(
              value: type,
              items: const [
                DropdownMenuItem(value: '', child: Text('All types')),
                DropdownMenuItem(value: 'phone_call', child: Text('Phone Call')),
                DropdownMenuItem(value: 'email', child: Text('Email')),
                DropdownMenuItem(value: 'meeting', child: Text('Meeting')),
                DropdownMenuItem(value: 'visit', child: Text('Visit')),
                DropdownMenuItem(value: 'message', child: Text('Message')),
                DropdownMenuItem(value: 'document', child: Text('Document')),
                DropdownMenuItem(value: 'note', child: Text('Note')),
                DropdownMenuItem(value: 'inspection', child: Text('Inspection')),
                DropdownMenuItem(value: 'voice', child: Text('Voice')),
                DropdownMenuItem(value: 'other', child: Text('Other')),
              ],
              onChanged: (value) => setState(() => type = value ?? ''),
            ),
          ),
          Expanded(
            child: data.when(
              data: (items) {
                final visible = type.isEmpty ? items : items.where((item) => item.type == type).toList();
                if (visible.isEmpty) return const EmptyView('No activities', icon: Icons.event_note_outlined);
                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: visible.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) => _tile(visible[i], canCreateTask),
                );
              },
              loading: () => const LoadingView(),
              error: (e, _) => ErrorView(e, retry: () => ref.invalidate(allActivitiesProvider)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(Activity activity, bool canCreateTask) {
    final lines = <String>['${labelize(activity.type)} • ${dateTimeText(activity.dateTime)}'];
    if (activity.withWhom != null) lines.add('With: ${activity.withWhom}');
    if (activity.toWhom != null) lines.add('To: ${activity.toWhom}');
    if (activity.result != null) lines.add('Result: ${activity.result}');
    if (activity.nextAction != null) lines.add('Next: ${activity.nextAction}');
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Icon(_icon(activity.type))),
        title: Text(activity.description),
        subtitle: Text(lines.join('\n')),
        isThreeLine: lines.length > 2,
        trailing: canCreateTask && activity.nextAction?.trim().isNotEmpty == true
            ? IconButton(tooltip: 'Create task from next action', onPressed: () => _createTaskFromActivity(activity), icon: const Icon(Icons.add_task))
            : null,
      ),
    );
  }

  IconData _icon(String value) => switch (value) {
        'phone_call' => Icons.call,
        'email' => Icons.email_outlined,
        'meeting' => Icons.groups_outlined,
        'visit' => Icons.location_on_outlined,
        'message' => Icons.message_outlined,
        'document' => Icons.description_outlined,
        'inspection' => Icons.fact_check_outlined,
        'voice' => Icons.mic_none,
        _ => Icons.note_alt_outlined,
      };

  Future<void> _add() async {
    final description = TextEditingController();
    final result = TextEditingController();
    final nextAction = TextEditingController();
    final withWhom = TextEditingController();
    final to = TextEditingController();
    final workItems = await ref.read(repoProvider).workItems();
    final tasks = await ref.read(repoProvider).tasks();
    if (!mounted) return;
    String typeValue = 'note';
    String? workItemId;
    String? taskId;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('New Activity'),
          content: SizedBox(
            width: 600,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  DropdownButtonFormField<String>(
                    value: typeValue,
                    decoration: const InputDecoration(labelText: 'Type'),
                    items: const [
                      DropdownMenuItem(value: 'phone_call', child: Text('Phone Call')),
                      DropdownMenuItem(value: 'email', child: Text('Email')),
                      DropdownMenuItem(value: 'meeting', child: Text('Meeting')),
                      DropdownMenuItem(value: 'visit', child: Text('Visit')),
                      DropdownMenuItem(value: 'message', child: Text('Message')),
                      DropdownMenuItem(value: 'document', child: Text('Document')),
                      DropdownMenuItem(value: 'note', child: Text('Note')),
                      DropdownMenuItem(value: 'inspection', child: Text('Inspection')),
                      DropdownMenuItem(value: 'voice', child: Text('Voice')),
                      DropdownMenuItem(value: 'other', child: Text('Other')),
                    ],
                    onChanged: (value) => setDialogState(() => typeValue = value ?? 'note'),
                  ),
                  TextField(controller: withWhom, decoration: const InputDecoration(labelText: 'With whom')),
                  TextField(controller: to, decoration: const InputDecoration(labelText: 'To')),
                  TextField(controller: description, maxLines: 6, decoration: const InputDecoration(labelText: 'Description *')),
                  TextField(controller: result, maxLines: 3, decoration: const InputDecoration(labelText: 'Result')),
                  TextField(controller: nextAction, maxLines: 3, decoration: const InputDecoration(labelText: 'Next Action')),
                  DropdownButtonFormField<String>(
                    value: workItemId,
                    decoration: const InputDecoration(labelText: 'Work Item (optional)'),
                    items: [const DropdownMenuItem<String>(value: null, child: Text('Standalone')), ...workItems.map((w) => DropdownMenuItem<String>(value: w.id, child: Text('${w.code} • ${w.title}')))],
                    onChanged: (value) => setDialogState(() => workItemId = value),
                  ),
                  DropdownButtonFormField<String>(
                    value: taskId,
                    decoration: const InputDecoration(labelText: 'Task (optional)'),
                    items: [const DropdownMenuItem<String>(value: null, child: Text('No Task')), ...tasks.map((t) => DropdownMenuItem<String>(value: t.id, child: Text('${t.code} • ${t.title}')))],
                    onChanged: (value) => setDialogState(() => taskId = value),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () async {
                if (description.text.trim().isEmpty) return;
                try {
                  await ref.read(repoProvider).addActivity(type: typeValue, dateTime: DateTime.now(), description: description.text.trim(), withWhom: withWhom.text.trim().isEmpty ? null : withWhom.text.trim(), toWhom: to.text.trim().isEmpty ? null : to.text.trim(), result: result.text.trim().isEmpty ? null : result.text.trim(), nextAction: nextAction.text.trim().isEmpty ? null : nextAction.text.trim(), workItemId: workItemId, taskId: taskId);
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                  ref.invalidate(allActivitiesProvider);
                  Ui.snack(context, 'Activity saved.');
                } catch (e) {
                  Ui.snack(context, 'Error: $e');
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
    description.dispose(); result.dispose(); nextAction.dispose(); withWhom.dispose(); to.dispose();
  }

  Future<void> _createTaskFromActivity(Activity activity) async {
    final users = await ref.read(activeUsersProvider.future);
    if (!mounted || activity.nextAction == null || activity.nextAction!.trim().isEmpty || users.isEmpty) return;
    final title = TextEditingController(text: activity.nextAction!.trim());
    String priority = 'normal';
    String? responsibleId = users.first.id;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Create Task from Next Action'),
          content: SizedBox(
            width: 520,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: title, maxLines: 3, decoration: const InputDecoration(labelText: 'Task title')),
                DropdownButtonFormField<String>(value: priority, decoration: const InputDecoration(labelText: 'Priority'), items: const [DropdownMenuItem(value: 'normal', child: Text('Normal')), DropdownMenuItem(value: 'urgent', child: Text('Urgent'))], onChanged: (value) => setDialogState(() => priority = value ?? 'normal')),
                DropdownButtonFormField<String>(value: responsibleId, decoration: const InputDecoration(labelText: 'Responsible'), items: users.map((u) => DropdownMenuItem(value: u.id, child: Text(u.fullName))).toList(), onChanged: (value) => setDialogState(() => responsibleId = value)),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () async {
                if (title.text.trim().isEmpty || responsibleId == null) return;
                try {
                  await ref.read(repoProvider).createTask(title: title.text.trim(), priority: priority, responsibleId: responsibleId!, workItemId: activity.workItemId);
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                  ref.invalidate(tasksProvider);
                  Ui.snack(context, 'Task created.');
                } catch (e) { Ui.snack(context, 'Error: $e'); }
              },
              child: const Text('Create'),
            ),
          ],
        ),
      ),
    );
    title.dispose();
  }
}
