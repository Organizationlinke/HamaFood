import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class TaskDetailScreen extends ConsumerStatefulWidget {
  final String taskId;

  const TaskDetailScreen({super.key, required this.taskId});

  @override
  ConsumerState<TaskDetailScreen> createState() => _TaskDetailScreenState();
}

class _TaskDetailScreenState extends ConsumerState<TaskDetailScreen> {
  Future<Task> _load() => ref.read(repoProvider).taskById(widget.taskId);

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'Task Detail',
      showBack: true,
      body: FutureBuilder<Task>(
        future: _load(),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const LoadingView();
          }
          if (snapshot.hasError) {
            return ErrorView(snapshot.error!);
          }
          final task = snapshot.data;
          if (task == null) {
            return const EmptyView('Task not found');
          }

          final profile = ref.watch(profileProvider).valueOrNull;

          return RefreshIndicator(
            onRefresh: () async {
              setState(() {});
            },
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            task.title,
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            task.code,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    StatusChip(task.status),
                    const SizedBox(width: 6),
                    PriorityChip(task.priority),
                  ],
                ),
                if (task.description?.isNotEmpty == true) ...[
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(task.description!),
                    ),
                  ),
                ],
                if (task.workItemId != null) ...[
                  const SizedBox(height: 8),
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.folder_open),
                      title: const Text('Linked Work Item'),
                      onTap: () =>
                          context.go('/work-items/${task.workItemId}'),
                    ),
                  ),
                ],
                const SizedBox(height: 8),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Wrap(
                      spacing: 24,
                      runSpacing: 14,
                      children: [
                        LabeledValue(
                          'Responsible',
                          task.responsibleId ?? '—',
                        ),
                        LabeledValue('Follower', task.followerId ?? '—'),
                        LabeledValue(
                          'Deadline',
                          dateTimeText(task.deadline),
                        ),
                        LabeledValue(
                          'Evidence',
                          task.evidenceRequired
                              ? 'Required'
                              : 'Not required',
                        ),
                        LabeledValue(
                          'Manager confirmation',
                          task.managerConfirmationRequired
                              ? 'Required'
                              : 'Not required',
                        ),
                        LabeledValue(
                          'Evaluation',
                          task.score == null
                              ? 'Not evaluated'
                              : '${task.score}/10',
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                _actionBar(task, profile),
                const SizedBox(height: 10),
                _stages(task),
                const SizedBox(height: 10),
                _evidence(task),
                const SizedBox(height: 10),
                _comments(task),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _actionBar(Task task, Profile? profile) {
    final isManager = profile?.isGm == true || profile?.isManager == true;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        if (task.status == 'not_started')
          FilledButton.icon(
            onPressed: () => _run(
              () => ref.read(repoProvider).startTask(task.id),
            ),
            icon: const Icon(Icons.play_arrow),
            label: const Text('Start'),
          ),
        if (task.status == 'in_progress')
          FilledButton.icon(
            onPressed: () => _run(
              () => ref.read(repoProvider).requestCompletion(task.id),
            ),
            icon: const Icon(Icons.fact_check_outlined),
            label: const Text('Ready for Completion'),
          ),
        if (task.status == 'ready_for_completion' && isManager)
          FilledButton.icon(
            onPressed: _confirmCompletion,
            icon: const Icon(Icons.verified),
            label: const Text('Confirm & Evaluate'),
          ),
        if (isManager &&
            (task.status == 'completed' ||
                task.status == 'cancelled' ||
                task.status == 'overdue'))
          OutlinedButton.icon(
            onPressed: () => _run(
              () => ref.read(repoProvider).reopenTask(task.id),
            ),
            icon: const Icon(Icons.replay),
            label: const Text('Reopen'),
          ),
        if (isManager && task.status != 'completed' && task.status != 'cancelled')
          OutlinedButton.icon(
            onPressed: () async {
              final ok = await Ui.confirm(
                context,
                title: 'Cancel Task',
                message: 'Cancel this task?',
              );
              if (ok == true) {
                await _run(() => ref.read(repoProvider).cancelTask(task.id));
              }
            },
            icon: const Icon(Icons.cancel_outlined),
            label: const Text('Cancel'),
          ),
        OutlinedButton.icon(
          onPressed: () => context.go('/messages'),
          icon: const Icon(Icons.chat_bubble_outline),
          label: const Text('Task Chat'),
        ),
      ],
    );
  }

  Future<void> _run(Future<void> Function() action) async {
    try {
      await action();
      if (mounted) setState(() {});
      ref.invalidate(tasksProvider);
      ref.invalidate(dashboardProvider);
    } catch (e) {
      if (mounted) Ui.snack(context, 'Error: $e');
    }
  }

  Widget _stages(Task task) {
    final data = ref.watch(taskStagesProvider(task.id));
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Stages',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: _addStage,
                  icon: const Icon(Icons.add),
                ),
              ],
            ),
            data.when(
              data: (stages) {
                if (stages.isEmpty) {
                  return const Text('No stages yet.');
                }
                return Column(
                  children: stages.map(_stageTile).toList(),
                );
              },
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => Text('Error: $e'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stageTile(TaskStage stage) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(child: Text('${stage.sortOrder}')),
      title: Text(stage.title),
      subtitle: Text(
        '${labelize(stage.status)}'
        '${stage.deadline == null ? '' : ' • ${shortDate(stage.deadline)}'}'
        '${stage.description?.isNotEmpty == true ? '\n${stage.description}' : ''}',
      ),
      isThreeLine: stage.description?.isNotEmpty == true,
      trailing: PopupMenuButton<String>(
        onSelected: (status) async {
          final values = <String, dynamic>{'status': status};
          if (status == 'completed') {
            values['completed_at'] = DateTime.now().toIso8601String();
          }
          await _run(
            () => ref.read(repoProvider).updateTaskStage(
                  stage.id,
                  values,
                ),
          );
          ref.invalidate(taskStagesProvider(widget.taskId));
        },
        itemBuilder: (_) => const [
          PopupMenuItem(value: 'pending', child: Text('Pending')),
          PopupMenuItem(value: 'in_progress', child: Text('In Progress')),
          PopupMenuItem(value: 'completed', child: Text('Completed')),
          PopupMenuItem(value: 'overdue', child: Text('Overdue')),
          PopupMenuItem(value: 'cancelled', child: Text('Cancelled')),
        ],
      ),
    );
  }

  Widget _evidence(Task task) {
    final data = ref.watch(taskEvidenceProvider(task.id));
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Evidence / Completion Proof',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: _addEvidence,
                  icon: const Icon(Icons.add),
                ),
              ],
            ),
            data.when(
              data: (rows) {
                if (rows.isEmpty) {
                  return const Text('No evidence recorded.');
                }
                return Column(
                  children: rows
                      .map(
                        (row) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: const Icon(Icons.attach_file),
                          title: Text('${row['title'] ?? 'Evidence'}'),
                          subtitle: Text(
                            '${row['description'] ?? ''}'
                            '${row['attachment_id'] == null ? '' : '\nAttachment: ${row['attachment_id']}'}',
                          ),
                        ),
                      )
                      .toList(),
                );
              },
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => Text('Error: $e'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _comments(Task task) {
    final data = ref.watch(commentsProvider('task|${task.id}'));
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Task Chat',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: _addComment,
                  icon: const Icon(Icons.add_comment),
                ),
              ],
            ),
            data.when(
              data: (items) {
                if (items.isEmpty) {
                  return const Text('No comments yet.');
                }
                return Column(
                  children: items
                      .map(
                        (item) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text(item.creatorName ?? 'User'),
                          subtitle: Text(item.content),
                          trailing: Text(shortDate(item.createdAt)),
                        ),
                      )
                      .toList(),
                );
              },
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => Text('Error: $e'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmCompletion() async {
    int score = 8;
    final comment = TextEditingController();
    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => StatefulBuilder(
          builder: (dialogContext, setDialogState) => AlertDialog(
            title: const Text('Confirm & Evaluate'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<int>(
                  value: score,
                  decoration: const InputDecoration(labelText: 'Score 1–10'),
                  items: List.generate(
                    10,
                    (i) => DropdownMenuItem(
                      value: i + 1,
                      child: Text('${i + 1} / 10'),
                    ),
                  ),
                  onChanged: (value) =>
                      setDialogState(() => score = value ?? 8),
                ),
                TextField(
                  controller: comment,
                  maxLines: 4,
                  decoration:
                      const InputDecoration(labelText: 'Evaluation comment'),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () async {
                  try {
                    await ref.read(repoProvider).confirmTask(
                          widget.taskId,
                          score,
                          comment: comment.text.trim().isEmpty
                              ? null
                              : comment.text.trim(),
                        );
                    if (dialogContext.mounted) {
                      Navigator.pop(dialogContext);
                    }
                    if (mounted) setState(() {});
                    ref.invalidate(tasksProvider);
                    ref.invalidate(dashboardProvider);
                  } catch (e) {
                    Ui.snack(context, 'Error: $e');
                  }
                },
                child: const Text('Confirm'),
              ),
            ],
          ),
        ),
      );
    } finally {
      comment.dispose();
    }
  }

  Future<void> _addStage() async {
    final users = await ref.read(activeUsersProvider.future);
    final title = TextEditingController();
    final description = TextEditingController();
    String? responsibleId;
    DateTime? deadline;

    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => StatefulBuilder(
          builder: (dialogContext, setDialogState) => AlertDialog(
            title: const Text('New Stage'),
            content: SizedBox(
              width: 560,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    TextField(
                      controller: title,
                      decoration: const InputDecoration(labelText: 'Title *'),
                    ),
                    TextField(
                      controller: description,
                      maxLines: 3,
                      decoration:
                          const InputDecoration(labelText: 'Description'),
                    ),
                    DropdownButtonFormField<String>(
                      value: responsibleId,
                      isExpanded: true,
                      decoration:
                          const InputDecoration(labelText: 'Responsible'),
                      items: [
                        const DropdownMenuItem<String>(
                          value: null,
                          child: Text('No specific responsible'),
                        ),
                        ...users.map(
                          (u) => DropdownMenuItem<String>(
                            value: u.id,
                            child: Text(u.fullName),
                          ),
                        ),
                      ],
                      onChanged: (value) =>
                          setDialogState(() => responsibleId = value),
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(
                        deadline == null
                            ? 'No deadline'
                            : 'Deadline: ${dateTimeText(deadline)}',
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.event),
                        onPressed: () async {
                          final date = await showDatePicker(
                            context: dialogContext,
                            firstDate: DateTime.now(),
                            lastDate: DateTime(2100),
                            initialDate: DateTime.now(),
                          );
                          if (date != null) {
                            setDialogState(
                              () => deadline = DateTime(
                                date.year,
                                date.month,
                                date.day,
                                17,
                              ),
                            );
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () async {
                  if (title.text.trim().isEmpty) return;
                  try {
                    final stages = await ref
                        .read(repoProvider)
                        .taskStages(widget.taskId);
                    await ref.read(repoProvider).createTaskStage(
                          taskId: widget.taskId,
                          title: title.text.trim(),
                          description: description.text.trim().isEmpty
                              ? null
                              : description.text.trim(),
                          responsibleId: responsibleId,
                          deadline: deadline,
                          sortOrder: stages.length + 1,
                        );
                    if (dialogContext.mounted) {
                      Navigator.pop(dialogContext);
                    }
                    ref.invalidate(taskStagesProvider(widget.taskId));
                  } catch (e) {
                    Ui.snack(context, 'Error: $e');
                  }
                },
                child: const Text('Add'),
              ),
            ],
          ),
        ),
      );
    } finally {
      title.dispose();
      description.dispose();
    }
  }

  Future<void> _addEvidence() async {
    final title = TextEditingController();
    final description = TextEditingController();
    final attachmentId = TextEditingController();

    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Add Evidence'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: title,
                decoration: const InputDecoration(labelText: 'Title *'),
              ),
              TextField(
                controller: description,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'Description'),
              ),
              TextField(
                controller: attachmentId,
                decoration: const InputDecoration(
                  labelText: 'Attachment ID (optional)',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                if (title.text.trim().isEmpty) return;
                try {
                  await ref.read(repoProvider).addTaskEvidence(
                        taskId: widget.taskId,
                        title: title.text.trim(),
                        description: description.text.trim().isEmpty
                            ? null
                            : description.text.trim(),
                        attachmentId: attachmentId.text.trim().isEmpty
                            ? null
                            : attachmentId.text.trim(),
                      );
                  if (dialogContext.mounted) {
                    Navigator.pop(dialogContext);
                  }
                  ref.invalidate(taskEvidenceProvider(widget.taskId));
                } catch (e) {
                  Ui.snack(context, 'Error: $e');
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      );
    } finally {
      title.dispose();
      description.dispose();
      attachmentId.dispose();
    }
  }

  Future<void> _addComment() async {
    final controller = TextEditingController();
    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Task Chat'),
          content: TextField(
            controller: controller,
            maxLines: 6,
            decoration: const InputDecoration(
              hintText: 'Write a comment… @username',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                if (controller.text.trim().isEmpty) return;
                try {
                  await ref.read(repoProvider).addComment(
                        parentType: 'task',
                        parentId: widget.taskId,
                        content: controller.text.trim(),
                      );
                  if (dialogContext.mounted) {
                    Navigator.pop(dialogContext);
                  }
                  ref.invalidate(
                    commentsProvider('task|${widget.taskId}'),
                  );
                } catch (e) {
                  Ui.snack(context, 'Error: $e');
                }
              },
              child: const Text('Post'),
            ),
          ],
        ),
      );
    } finally {
      controller.dispose();
    }
  }
}
