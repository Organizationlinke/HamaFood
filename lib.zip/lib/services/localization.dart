import 'package:flutter/material.dart';

/// Lightweight, dependency-free localization for Hama Work.
/// The selected language is stored per user in public.profiles.preferred_language.
class AppI18n {
  static Locale _locale = const Locale('ar');

  static Locale get locale => _locale;
  static String get languageCode => _locale.languageCode;
  static bool get isArabic => languageCode == 'ar';

  static String roleLabel(String role) {
    switch (role) {
      case 'gm':
        return isArabic ? 'المدير العام' : 'General Manager';
      case 'manager':
        return isArabic ? 'مدير' : 'Manager';
      case 'employee':
        return isArabic ? 'موظف' : 'Employee';
      default:
        return role;
    }
  }

  static void setLocale(Locale locale) {
    _locale = locale.languageCode == 'en'
        ? const Locale('en')
        : const Locale('ar');
  }

  static String t(String text) {
    if (!isArabic || text.isEmpty) return text;

    final exact = _ar[text];
    if (exact != null) return exact;

    // Safe translations for common dynamic UI prefixes/suffixes.
    const dynamicReplacements = <String, String>{
      'Welcome, ': 'مرحبًا، ',
      'Profile error: ': 'خطأ في الملف الشخصي: ',
      'Message error: ': 'خطأ في الرسائل: ',
      'Approval error: ': 'خطأ في الموافقات: ',
      'Task error: ': 'خطأ في المهام: ',
      'Error: ': 'خطأ: ',
      'Seen ': 'تمت المشاهدة ',
      'Deadline: ': 'الموعد النهائي: ',
      'Updated ': 'آخر تحديث ',
      'With: ': 'مع: ',
      'To: ': 'إلى: ',
      'Result: ': 'النتيجة: ',
      'Next: ': 'الإجراء التالي: ',
      'From: ': 'من: ',
      'Today submitted': 'تم تسجيل عمل اليوم',
      'Today not submitted': 'لم يتم تسجيل عمل اليوم',
    };

    for (final entry in dynamicReplacements.entries) {
      if (text.startsWith(entry.key)) {
        return '${entry.value}${text.substring(entry.key.length)}';
      }
    }

    return text;
  }

  static final Map<String, String> _ar = {
    'Dashboard': 'لوحة التحكم',
    'Work Items': 'ملفات العمل',
    'Team Tasks': 'مهام الفريق',
    'My Tasks': 'مهامي',
    'Tasks': 'المهام',
    'Messages': 'الرسائل',
    'Daily Work': 'العمل اليومي',
    'Activities': 'الأنشطة',
    'Approvals': 'الموافقات',
    'Notifications': 'الإشعارات',
    'Search': 'البحث',
    'Reports': 'التقارير',
    'Users': 'المستخدمون',
    'Settings': 'الإعدادات',
    'Language': 'اللغة',
    'Arabic': 'العربية',
    'English': 'الإنجليزية',
    'Sign out': 'تسجيل الخروج',
    'Sign in': 'تسجيل الدخول',
    'Signing in...': 'جارٍ تسجيل الدخول...',
    'Username': 'اسم المستخدم',
    'Username *': 'اسم المستخدم *',
    'Full name *': 'الاسم بالكامل *',
    'Password *': 'كلمة المرور *',
    'Use Hama Work in Arabic': 'استخدم Hama Work بالعربية',
    'Use Hama Work in English': 'استخدم Hama Work بالإنجليزية',
    'Could not sign in.': 'تعذر تسجيل الدخول.',
    'Enter username and password.': 'أدخل اسم المستخدم وكلمة المرور.',
    'Invalid username format.': 'تنسيق اسم المستخدم غير صحيح.',
    'Password': 'كلمة المرور',
    'Internal Work & Communication': 'إدارة العمل والتواصل الداخلي',
    'Needs Your Attention': 'يحتاج إلى انتباهك',
    'Open Items': 'الملفات المفتوحة',
    'Overdue': 'متأخرة',
    'Ready': 'جاهزة للإنجاز',
    'Unread Messages': 'رسائل غير مقروءة',
    'No messages': 'لا توجد رسائل',
    'Latest Communication': 'أحدث المراسلات',
    'Pending Approvals': 'الموافقات المعلقة',
    'No pending approvals.': 'لا توجد موافقات معلقة.',
    'Search everything': 'البحث في كل شيء',
    'Search anything': 'ابحث عن أي شيء',
    'Search Work Items, Tasks, Messages, Comments, Activities and Files': 'ابحث في ملفات العمل والمهام والرسائل والتعليقات والأنشطة والملفات',
    'Search tasks': 'البحث في المهام',
    'Search Work Items': 'البحث في ملفات العمل',
    'No results': 'لا توجد نتائج',
    'Mark all read': 'تحديد الكل كمقروء',
    'Retry': 'إعادة المحاولة',
    'Cancel': 'إلغاء',
    'Confirm': 'تأكيد',
    'Save': 'حفظ',
    'Create': 'إنشاء',
    'Add': 'إضافة',
    'Done': 'تم',
    'Post': 'نشر',
    'Send': 'إرسال',
    'Link': 'ربط',
    'Close': 'إغلاق',
    'Archive': 'أرشفة',
    'Reopen': 'إعادة فتح',
    'Start': 'بدء',
    'Add File': 'إضافة ملف',
    'Add Activity': 'إضافة نشاط',
    'New Activity': 'نشاط جديد',
    'New Task': 'مهمة جديدة',
    'New Work Item': 'ملف عمل جديد',
    'New Message': 'رسالة جديدة',
    'New Approval Request': 'طلب موافقة جديد',
    'Create Work Item': 'إنشاء ملف عمل',
    'Create Task': 'إنشاء مهمة',
    'Create User': 'إنشاء مستخدم',
    'New User': 'مستخدم جديد',
    'Title': 'العنوان',
    'Title *': 'العنوان *',
    'Description': 'الوصف',
    'Description *': 'الوصف *',
    'Category': 'التصنيف',
    'Priority': 'الأولوية',
    'Normal': 'عادية',
    'Urgent': 'عاجلة',
    'Responsible': 'المسؤول',
    'Responsible *': 'المسؤول *',
    'No responsible': 'بدون مسؤول',
    'Follower': 'المتابع',
    'No follower': 'بدون متابع',
    'Department': 'الإدارة',
    'Job title': 'المسمى الوظيفي',
    'Role': 'الدور',
    'Manager': 'مدير',
    'Employee': 'موظف',
    'Work Item': 'ملف العمل',
    'Work Item (optional)': 'ملف العمل (اختياري)',
    'Standalone Task': 'مهمة مستقلة',
    'Standalone': 'مستقل',
    'Task (optional)': 'مهمة (اختياري)',
    'No deadline': 'بدون موعد نهائي',
    'Evidence required': 'إثبات الإنجاز مطلوب',
    'Manager confirmation before completion': 'تأكيد المدير قبل الإنجاز',
    'All': 'الكل',
    'All status': 'كل الحالات',
    'All priority': 'كل الأولويات',
    'Not Started': 'لم تبدأ',
    'In Progress': 'قيد التنفيذ',
    'Ready for Completion': 'جاهزة للإنجاز',
    'Completed': 'مكتملة',
    'Cancelled': 'ملغاة',
    'Waiting': 'انتظار',
    'Open': 'مفتوح',
    'Status': 'الحالة',
    'Change Status': 'تغيير الحالة',
    'Close Work Item': 'إغلاق ملف العمل',
    'Final Result *': 'النتيجة النهائية *',
    'Participants': 'المشاركون',
    'No additional participants.': 'لا يوجد مشاركون إضافيون.',
    'Comments': 'التعليقات',
    'No comments yet.': 'لا توجد تعليقات بعد.',
    'Write comment… @username': 'اكتب تعليقًا… @اسم_المستخدم',
    'Write a comment… @username': 'اكتب تعليقًا… @اسم_المستخدم',
    'Replies / Comments': 'الردود / التعليقات',
    'No replies yet.': 'لا توجد ردود بعد.',
    'Reply': 'رد',
    'Write reply… @username': 'اكتب ردًا… @اسم_المستخدم',
    'Recipients': 'المستلمون',
    'No recipient data available.': 'لا توجد بيانات للمستلمين.',
    'Files': 'الملفات',
    'No files.': 'لا توجد ملفات.',
    'File name *': 'اسم الملف *',
    'Storage path *': 'مسار التخزين *',
    'Supabase Storage path *': 'مسار Supabase Storage *',
    'MIME type': 'نوع الملف',
    'Link Message to Work Item': 'ربط الرسالة بملف عمل',
    'Open Work Item': 'فتح ملف العمل',
    'Open Task': 'فتح المهمة',
    'Convert to Task': 'تحويل إلى مهمة',
    'Convert Message to Task': 'تحويل الرسالة إلى مهمة',
    'Create Task from Approval': 'إنشاء مهمة من الموافقة',
    'Link Work Item': 'ربط ملف العمل',
    'Submit': 'إرسال',
    'Convert Task': 'تحويل إلى مهمة',
    'Action Required': 'إجراء مطلوب',
    'This message can be converted into a managed Task.': 'يمكن تحويل هذه الرسالة إلى مهمة مُدارة.',
    'This message can be converted to a managed Task.': 'يمكن تحويل هذه الرسالة إلى مهمة مُدارة.',
    'Information': 'معلومة',
    'Info': 'معلومة',
    'Action': 'إجراء',
    'Task': 'مهمة',
    'Task title': 'عنوان المهمة',
    'Type': 'النوع',
    'Audience': 'الجمهور',
    'Everyone': 'الجميع',
    'Selected users': 'مستخدمون محددون',
    'Message': 'رسالة',
    'Message *': 'الرسالة *',
    'Use @username to mention someone': 'استخدم @اسم_المستخدم لذكر شخص',
    'Approve': 'اعتماد',
    'Reject': 'رفض',
    'Need info': 'بحاجة إلى معلومات',
    'Request': 'طلب',
    'Request *': 'الطلب *',
    'Requested from *': 'مطلوب من *',
    'Comment': 'تعليق',
    'Activity': 'نشاط',
    'All types': 'كل الأنواع',
    'Phone Call': 'مكالمة هاتفية',
    'Email': 'بريد إلكتروني',
    'Meeting': 'اجتماع',
    'Visit': 'زيارة',
    'Document': 'مستند',
    'Note': 'ملاحظة',
    'Inspection': 'تفتيش',
    'Voice': 'صوت',
    'Other': 'أخرى',
    'With whom': 'مع من',
    'To': 'إلى',
    'Result': 'النتيجة',
    'Next Action': 'الإجراء التالي',
    'Create Task from Next Action': 'إنشاء مهمة من الإجراء التالي',
    'Draft': 'مسودة',
    'Submitted': 'تم الإرسال',
    'No Work Item': 'بدون ملف عمل',
    'No Task': 'بدون مهمة',
    'What did you do? *': 'ماذا أنجزت؟ *',
    'Problems / blockers': 'المشكلات / المعوقات',
    'Next actions': 'الإجراءات التالية',
    'Link to Work Item (optional)': 'ربط بملف عمل (اختياري)',
    'Link to Task (optional)': 'ربط بمهمة (اختياري)',
    'Linked Work Item': 'ملف العمل المرتبط',
    'Work Item linked': 'تم ربط ملف العمل',
    'Task linked': 'تم ربط المهمة',
    'Task Detail': 'تفاصيل المهمة',
    'Task Chat': 'محادثة المهمة',
    'No stages yet.': 'لا توجد مراحل بعد.',
    'New Stage': 'مرحلة جديدة',
    'No specific responsible': 'بدون مسؤول محدد',
    'Pending': 'معلقة',
    'No evidence recorded.': 'لا يوجد إثبات مسجل.',
    'Add Evidence': 'إضافة إثبات',
    'Attachment ID (optional)': 'معرّف المرفق (اختياري)',
    'Score 1–10': 'التقييم من 1 إلى 10',
    'Evaluation comment': 'تعليق التقييم',
    'Confirm & Evaluate': 'تأكيد وتقييم',
    'Cancel Task': 'إلغاء المهمة',
    'Cancel this task?': 'هل تريد إلغاء هذه المهمة؟',
    'Average task score: ': 'متوسط تقييم المهام: ',
    'Report': 'تقرير',
    'Choose language': 'اختر اللغة',
    'Language saved.': 'تم حفظ اللغة.',
    'Language updated.': 'تم تحديث اللغة.',
    'Today': 'اليوم',
    'Updated': 'آخر تحديث',
    'Created': 'تاريخ الإنشاء',
    'Final Result': 'النتيجة النهائية',
    'Overview': 'نظرة عامة',
    'Timeline': 'السجل الزمني',
    'Search Results': 'نتائج البحث',
    'No Tasks': 'لا توجد مهام',
    'No Activities.': 'لا توجد أنشطة.',
    'No activities.': 'لا توجد أنشطة.',
    'No timeline events.': 'لا توجد أحداث في السجل الزمني.',
    'Error': 'خطأ',
    'Invalid username': 'اسم المستخدم غير صحيح',
    'Profile is not configured for this account': 'لم يتم إعداد ملف المستخدم لهذا الحساب',
    'User is inactive or username does not match': 'المستخدم غير نشط أو اسم المستخدم غير مطابق',
    'Title and at least one Responsible user are required': 'العنوان ومستخدم مسؤول واحد على الأقل مطلوبان',
    'Complete all required fields.': 'أكمل جميع الحقول المطلوبة.',
    'User created successfully.': 'تم إنشاء المستخدم بنجاح.',
    'Task created.': 'تم إنشاء المهمة.',
    'Work Item created': 'تم إنشاء ملف العمل',
    'Work Item updated': 'تم تحديث ملف العمل',
    'Work Item status changed': 'تم تغيير حالة ملف العمل',
    'Work Item completed': 'تم إنجاز ملف العمل',
    'Work Item reopened': 'تم إعادة فتح ملف العمل',
    'Work Item archived': 'تمت أرشفة ملف العمل',
    'Participant added': 'تمت إضافة مشارك',
    'Task created': 'تم إنشاء المهمة',
    'Task started': 'بدأت المهمة',
    'Task ready for completion': 'المهمة جاهزة للإنجاز',
    'Task completed': 'تم إنجاز المهمة',
    'Task completed and evaluated': 'تم إنجاز المهمة وتقييمها',
    'Task reopened': 'تم إعادة فتح المهمة',
    'Task cancelled': 'تم إلغاء المهمة',
    'Activity added': 'تمت إضافة النشاط',
    'Message added': 'تمت إضافة الرسالة',
    'Message linked': 'تم ربط الرسالة',
    'Profile': 'الملف الشخصي',
    'User': 'مستخدم',
    'Team member': 'عضو بالفريق',
    'No department': 'بدون إدارة',
    'Admin': 'مدير النظام',
    'General Manager': 'المدير العام',
    'User created successfully': 'تم إنشاء المستخدم بنجاح',
  };
}

String tr(String text) => AppI18n.t(text);

/// Text widget that resolves known Hama Work UI phrases using the active locale.
class T extends StatelessWidget {
  final String data;
  final TextStyle? style;
  final TextAlign? textAlign;
  final TextOverflow? overflow;
  final int? maxLines;
  final bool? softWrap;
  final bool translate;

  const T(
    this.data, {
    super.key,
    this.style,
    this.textAlign,
    this.overflow,
    this.maxLines,
    this.softWrap,
    this.translate = true,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      translate ? AppI18n.t(data) : data,
      key: key,
      style: style,
      textAlign: textAlign,
      overflow: overflow,
      maxLines: maxLines,
      softWrap: softWrap,
    );
  }
}
