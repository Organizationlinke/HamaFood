import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../services/localization.dart';
import '../services/repository.dart';

final repoProvider = Provider<AppRepository>((ref) => AppRepository());
final profileProvider = FutureProvider<Profile?>((ref) => ref.watch(repoProvider).myProfile());
final usersProvider = FutureProvider<List<Profile>>((ref) => ref.watch(repoProvider).users());
final activeUsersProvider = FutureProvider<List<Profile>>((ref) => ref.watch(repoProvider).users(activeOnly: true));
final departmentsProvider = FutureProvider<List<Department>>((ref) => ref.watch(repoProvider).departments());
final dashboardProvider = FutureProvider<DashboardStats>((ref) => ref.watch(repoProvider).dashboardStats());
final workItemsProvider = FutureProvider<List<WorkItem>>((ref) => ref.watch(repoProvider).workItems());
final tasksProvider = FutureProvider<List<Task>>((ref) => ref.watch(repoProvider).tasks());
final messagesProvider = FutureProvider<List<MessageItem>>((ref) => ref.watch(repoProvider).messages());
final notificationsProvider = FutureProvider<List<NotificationItem>>((ref) => ref.watch(repoProvider).notifications());
final dailyWorksProvider = FutureProvider<List<DailyWork>>((ref) => ref.watch(repoProvider).dailyWorks());
final approvalsProvider = FutureProvider<List<Approval>>((ref) => ref.watch(repoProvider).approvals());
final allActivitiesProvider = FutureProvider<List<Activity>>((ref) => ref.watch(repoProvider).activities());
final workItemTasksProvider = FutureProvider.family<List<Task>, String>((ref, id) => ref.watch(repoProvider).tasks(workItemId: id));
final workItemActivitiesProvider = FutureProvider.family<List<Activity>, String>((ref, id) => ref.watch(repoProvider).activities(workItemId: id));
final workItemParticipantsProvider = FutureProvider.family<List<Profile>, String>((ref, id) => ref.watch(repoProvider).workItemParticipants(id));
final workItemTimelineProvider = FutureProvider.family<List<TimelineEvent>, String>((ref, id) => ref.watch(repoProvider).timeline(id));
final taskStagesProvider = FutureProvider.family<List<TaskStage>, String>((ref, id) => ref.watch(repoProvider).taskStages(id));
final taskEvidenceProvider = FutureProvider.family<List<Map<String, dynamic>>, String>((ref, id) => ref.watch(repoProvider).taskEvidence(id));
final commentsProvider = FutureProvider.family<List<CommentItem>, String>((ref, key) {
  final i = key.indexOf('|');
  final type = i < 0 ? key : key.substring(0, i);
  final id = i < 0 ? '' : key.substring(i + 1);
  return ref.watch(repoProvider).comments(type, id);
});

/// Current UI locale. It is initialized from the signed-in user's profile.
final languageProvider = StateProvider<Locale>((ref) => AppI18n.locale);
