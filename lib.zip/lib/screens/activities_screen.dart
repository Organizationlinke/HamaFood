import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../services/app_helpers.dart';
import '../services/localization.dart';
import '../providers/providers.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class ActivitiesScreen extends ConsumerStatefulWidget {
  const ActivitiesScreen({super.key});
  @override ConsumerState<ActivitiesScreen> createState() => _ActivitiesScreenState();
}

class _ActivitiesScreenState extends ConsumerState<ActivitiesScreen> {
  String type = '';

  @override
  Widget build(BuildContext context) {
    final data = ref.watch(allActivitiesProvider);
    final canCreateTask = ref.watch(profileProvider).valueOrNull?.isGm == true;
    return AppScaffold(
      title: 'Activities',
      actions: [IconButton(onPressed: () => ref.invalidate(allActivitiesProvider), icon: const Icon(Icons.refresh))],
      floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const T('Activity')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: DropdownButton<String>(
              value: type,
              items: const [
                DropdownMenuItem(value: '', child: T('All types')),
                DropdownMenuItem(value: 'phone_call', child: T('Phone Call')),
                DropdownMenuItem(value: 'email', child: T('Email')),
                DropdownMenuItem(value: 'meeting', child: T('Meeting')),
                DropdownMenuItem(value: 'visit', child: T('Visit')),
                DropdownMenuItem(value: 'message', child: T('Message')),
                DropdownMenuItem(value: 'document', child: T('Document')),
                DropdownMenuItem(value: 'note', child: T('Note')),
                DropdownMenuItem(value: 'inspection', child: T('Inspection')),
                DropdownMenuItem(value: 'voice', child: T('Voice')),
                DropdownMenuItem(value: 'other', child: T('Other')),
              ],
              onChanged: (value) => setState(() => type = value ?? ''),
            ),
          ),
          Expanded(
            child: data.when(
              data: (items) {
                final visible = type.isEmpty ? items : items.where((item) => item.type == type).toList();
                if (visible.isEmpty) return const EmptyView('No activities', icon: Icons.event_note_outlined);
                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: visible.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) => _tile(visible[i], canCreateTask),
                );
              },
              loading: () => const LoadingView(),
              error: (e, _) => ErrorView(e, retry: () => ref.invalidate(allActivitiesProvider)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(Activity activity, bool canCreateTask) {
    final lines = <String>['${labelize(activity.type)} • ${dateTimeText(activity.dateTime)}'];
    if (activity.withWhom != null) lines.add('With: ${activity.withWhom}');
    if (activity.toWhom != null) lines.add('To: ${activity.toWhom}');
    if (activity.result != null) lines.add('Result: ${activity.result}');
    if (activity.nextAction != null) lines.add('Next: ${activity.nextAction}');
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Icon(_icon(activity.type))),
        title: T(activity.description),
        subtitle: T(lines.join('\n')),
        isThreeLine: lines.length > 2,
        trailing: canCreateTask && activity.nextAction?.trim().isNotEmpty == true
            ? IconButton(tooltip: 'Create task from next action', onPressed: () => _createTaskFromActivity(activity), icon: const Icon(Icons.add_task))
            : null,
      ),
    );
  }

  IconData _icon(String value) => switch (value) {
        'phone_call' => Icons.call,
        'email' => Icons.email_outlined,
        'meeting' => Icons.groups_outlined,
        'visit' => Icons.location_on_outlined,
        'message' => Icons.message_outlined,
        'document' => Icons.description_outlined,
        'inspection' => Icons.fact_check_outlined,
        'voice' => Icons.mic_none,
        _ => Icons.note_alt_outlined,
      };

  Future<void> _add() async {
    final description = TextEditingController();
    final result = TextEditingController();
    final nextAction = TextEditingController();
    final withWhom = TextEditingController();
    final to = TextEditingController();
    final workItems = await ref.read(repoProvider).workItems();
    final tasks = await ref.read(repoProvider).tasks();
    if (!mounted) return;
    String typeValue = 'note';
    String? workItemId;
    String? taskId;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const T('New Activity'),
          content: SizedBox(
            width: 600,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  DropdownButtonFormField<String>(
                    value: typeValue,
                    decoration: InputDecoration(labelText: tr('Type')),
                    items: const [
                      DropdownMenuItem(value: 'phone_call', child: T('Phone Call')),
                      DropdownMenuItem(value: 'email', child: T('Email')),
                      DropdownMenuItem(value: 'meeting', child: T('Meeting')),
                      DropdownMenuItem(value: 'visit', child: T('Visit')),
                      DropdownMenuItem(value: 'message', child: T('Message')),
                      DropdownMenuItem(value: 'document', child: T('Document')),
                      DropdownMenuItem(value: 'note', child: T('Note')),
                      DropdownMenuItem(value: 'inspection', child: T('Inspection')),
                      DropdownMenuItem(value: 'voice', child: T('Voice')),
                      DropdownMenuItem(value: 'other', child: T('Other')),
                    ],
                    onChanged: (value) => setDialogState(() => typeValue = value ?? 'note'),
                  ),
                  TextField(controller: withWhom, decoration: InputDecoration(labelText: tr('With whom'))),
                  TextField(controller: to, decoration: InputDecoration(labelText: tr('To'))),
                  TextField(controller: description, maxLines: 6, decoration: InputDecoration(labelText: tr('Description *'))),
                  TextField(controller: result, maxLines: 3, decoration: InputDecoration(labelText: tr('Result'))),
                  TextField(controller: nextAction, maxLines: 3, decoration: InputDecoration(labelText: tr('Next Action'))),
                  DropdownButtonFormField<String>(
                    value: workItemId,
                    decoration: InputDecoration(labelText: tr('Work Item (optional)')),
                    items: [const DropdownMenuItem<String>(value: null, child: T('Standalone')), ...workItems.map((w) => DropdownMenuItem<String>(value: w.id, child: T('${w.code} • ${w.title}')))],
                    onChanged: (value) => setDialogState(() => workItemId = value),
                  ),
                  DropdownButtonFormField<String>(
                    value: taskId,
                    decoration: InputDecoration(labelText: tr('Task (optional)')),
                    items: [const DropdownMenuItem<String>(value: null, child: T('No Task')), ...tasks.map((t) => DropdownMenuItem<String>(value: t.id, child: T('${t.code} • ${t.title}')))],
                    onChanged: (value) => setDialogState(() => taskId = value),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const T('Cancel')),
            FilledButton(
              onPressed: () async {
                if (description.text.trim().isEmpty) return;
                try {
                  await ref.read(repoProvider).addActivity(type: typeValue, dateTime: DateTime.now(), description: description.text.trim(), withWhom: withWhom.text.trim().isEmpty ? null : withWhom.text.trim(), toWhom: to.text.trim().isEmpty ? null : to.text.trim(), result: result.text.trim().isEmpty ? null : result.text.trim(), nextAction: nextAction.text.trim().isEmpty ? null : nextAction.text.trim(), workItemId: workItemId, taskId: taskId);
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                  ref.invalidate(allActivitiesProvider);
                  Ui.snack(context, 'Activity saved.');
                } catch (e) {
                  Ui.snack(context, 'Error: $e');
                }
              },
              child: const T('Save'),
            ),
          ],
        ),
      ),
    );
    description.dispose(); result.dispose(); nextAction.dispose(); withWhom.dispose(); to.dispose();
  }

  Future<void> _createTaskFromActivity(Activity activity) async {
    final users = await ref.read(activeUsersProvider.future);
    if (!mounted || activity.nextAction == null || activity.nextAction!.trim().isEmpty || users.isEmpty) return;
    final title = TextEditingController(text: activity.nextAction!.trim());
    String priority = 'normal';
    String? responsibleId = users.first.id;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const T('Create Task from Next Action'),
          content: SizedBox(
            width: 520,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: title, maxLines: 3, decoration: InputDecoration(labelText: tr('Task title'))),
                DropdownButtonFormField<String>(value: priority, decoration: InputDecoration(labelText: tr('Priority')), items: const [DropdownMenuItem(value: 'normal', child: T('Normal')), DropdownMenuItem(value: 'urgent', child: T('Urgent'))], onChanged: (value) => setDialogState(() => priority = value ?? 'normal')),
                DropdownButtonFormField<String>(value: responsibleId, decoration: InputDecoration(labelText: tr('Responsible')), items: users.map((u) => DropdownMenuItem(value: u.id, child: T(u.fullName))).toList(), onChanged: (value) => setDialogState(() => responsibleId = value)),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const T('Cancel')),
            FilledButton(
              onPressed: () async {
                if (title.text.trim().isEmpty || responsibleId == null) return;
                try {
                  await ref.read(repoProvider).createTask(title: title.text.trim(), priority: priority, responsibleId: responsibleId!, workItemId: activity.workItemId);
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                  ref.invalidate(tasksProvider);
                  Ui.snack(context, 'Task created.');
                } catch (e) { Ui.snack(context, 'Error: $e'); }
              },
              child: const T('Create'),
            ),
          ],
        ),
      ),
    );
    title.dispose();
  }
}
