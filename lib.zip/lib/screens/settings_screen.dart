import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../services/localization.dart';
import '../widgets/app_scaffold.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  Future<void> _setLanguage(BuildContext context, WidgetRef ref, String code) async {
    try {
      await ref.read(repoProvider).setPreferredLanguage(code);
      AppI18n.setLocale(Locale(code));
      ref.read(languageProvider.notifier).state = Locale(code);
      ref.invalidate(profileProvider);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: T('Language saved.')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: T('Error: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider).valueOrNull;
    final current = ref.watch(languageProvider).languageCode;

    return AppScaffold(
      title: 'Settings',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.language),
              title: const T('Language'),
              subtitle: T(current == 'ar' ? 'Arabic' : 'English'),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: [
                RadioListTile<String>(
                  value: 'ar',
                  groupValue: current,
                  title: const T('Arabic'),
                  subtitle: const T('Use Hama Work in Arabic'),
                  onChanged: (v) => v == null ? null : _setLanguage(context, ref, v),
                ),
                const Divider(height: 1),
                RadioListTile<String>(
                  value: 'en',
                  groupValue: current,
                  title: const T('English'),
                  subtitle: const T('Use Hama Work in English'),
                  onChanged: (v) => v == null ? null : _setLanguage(context, ref, v),
                ),
              ],
            ),
          ),
          if (profile != null) ...[
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.person_outline),
                title: T(profile.fullName, translate: false),
                subtitle: T('@${profile.username}', translate: false),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
