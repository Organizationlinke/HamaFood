import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../services/localization.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class TasksScreen extends ConsumerStatefulWidget {
  final String initialScope;

  const TasksScreen({super.key, this.initialScope = 'team'});
  @override ConsumerState<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends ConsumerState<TasksScreen> {
  String status = '';
  String priority = '';
  String query = '';
  late String scope;

  @override
  void initState() {
    super.initState();
    scope = widget.initialScope;
  }

  @override
  Widget build(BuildContext context) {
    final data = ref.watch(tasksProvider);
    final canCreate = ref.watch(profileProvider).valueOrNull?.isGm == true;
    return AppScaffold(
      title: 'Tasks',
      actions: [IconButton(onPressed: () => ref.invalidate(tasksProvider), icon: const Icon(Icons.refresh))],
      floatingActionButton: canCreate ? FloatingActionButton.extended(onPressed: _createTask, icon: const Icon(Icons.add_task), label: const T('New Task')) : null,
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
          child: Wrap(spacing: 8, runSpacing: 8, children: [
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'my', label: T('My Tasks'), icon: Icon(Icons.person_pin)),
                ButtonSegment(value: 'team', label: T('Team Tasks'), icon: Icon(Icons.groups_outlined)),
              ],
              selected: {scope},
              onSelectionChanged: (value) => setState(() => scope = value.first),
            ),
            SizedBox(width: 260, child: TextField(
              decoration: InputDecoration(prefixIcon: Icon(Icons.search), hintText: tr('Search tasks')),
              onChanged: (v) => setState(() => query = v),
            )),
            DropdownButton<String>(
              value: status,
              items: const [
                DropdownMenuItem(value: '', child: T('All status')),
                DropdownMenuItem(value: 'not_started', child: T('Not Started')),
                DropdownMenuItem(value: 'in_progress', child: T('In Progress')),
                DropdownMenuItem(value: 'ready_for_completion', child: T('Ready')),
                DropdownMenuItem(value: 'completed', child: T('Completed')),
                DropdownMenuItem(value: 'overdue', child: T('Overdue')),
                DropdownMenuItem(value: 'cancelled', child: T('Cancelled')),
              ],
              onChanged: (v) => setState(() => status = v ?? ''),
            ),
            DropdownButton<String>(
              value: priority,
              items: const [
                DropdownMenuItem(value: '', child: T('All priority')),
                DropdownMenuItem(value: 'normal', child: T('Normal')),
                DropdownMenuItem(value: 'urgent', child: T('Urgent')),
              ],
              onChanged: (v) => setState(() => priority = v ?? ''),
            ),
          ]),
        ),
        Expanded(child: data.when(
          data: (items) {
            final q = query.trim().toLowerCase();
            final profile = ref.watch(profileProvider).valueOrNull;
            final xs = items.where((t) {
              final mine = t.responsibleId == profile?.id || t.followerId == profile?.id;
              return (scope == 'team' || mine) &&
                  (status.isEmpty || t.status == status) &&
                  (priority.isEmpty || t.priority == priority) &&
                  (q.isEmpty || '${t.code} ${t.title} ${t.description ?? ''}'.toLowerCase().contains(q));
            }).toList();
            if (xs.isEmpty) return const EmptyView('No Tasks', icon: Icons.task_alt);
            return RefreshIndicator(
              onRefresh: () async {
                ref.invalidate(tasksProvider);
                await ref.read(tasksProvider.future);
              },
              child: ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: xs.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (_, i) => _tile(xs[i]),
              ),
            );
          },
          loading: () => const LoadingView(),
          error: (e, _) => ErrorView(e, retry: () => ref.invalidate(tasksProvider)),
        )),
      ]),
    );
  }

  Widget _tile(Task t) => Card(
    child: ListTile(
      onTap: () => context.go('/tasks/${t.id}'),
      leading: CircleAvatar(child: Icon(t.status == 'completed' ? Icons.task_alt : Icons.assignment_outlined)),
      title: T(t.title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: T('${t.code} • ${t.deadline == null ? 'No deadline' : dateTimeText(t.deadline)}${t.workItemId == null ? '' : '\nLinked to Work Item'}'),
      isThreeLine: t.workItemId != null,
      trailing: Wrap(spacing: 4, children: [StatusChip(t.status), PriorityChip(t.priority)]),
    ),
  );

  Future<void> _createTask() async {
    final users = await ref.read(activeUsersProvider.future);
    final workItems = await ref.read(repoProvider).workItems();
    final title = TextEditingController();
    final desc = TextEditingController();
    final deadlineCtrl = TextEditingController();
    String priority = 'normal';
    String? responsibleId;
    final selectedResponsibleIds = <String>{};
    String? followerId;
    String? workItemId;
    bool evidence = false;
    bool managerConfirm = true;
    DateTime? deadline;

    await showDialog(
      context: context,
      builder: (c) => StatefulBuilder(builder: (c, set) => AlertDialog(
        title: const T('Create Task'),
        content: SizedBox(
          width: 560,
          child: SingleChildScrollView(
            child: Column(children: [
              TextField(controller: title, decoration: InputDecoration(labelText: tr('Title *'))),
              TextField(controller: desc, maxLines: 4, decoration: InputDecoration(labelText: tr('Description'))),
              DropdownButtonFormField<String>(
                value: priority,
                decoration: InputDecoration(labelText: tr('Priority')),
                items: const [DropdownMenuItem(value: 'normal', child: T('Normal')), DropdownMenuItem(value: 'urgent', child: T('Urgent'))],
                onChanged: (v) => set(() => priority = v ?? 'normal'),
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: T('Responsible *', style: TextStyle(fontWeight: FontWeight.w600)),
              ),
              const SizedBox(height: 6),
              ...users.map(
                (u) => CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: selectedResponsibleIds.contains(u.id),
                  title: T(u.fullName),
                  subtitle: T('@${u.username}'),
                  onChanged: (checked) => set(() {
                    if (checked == true) {
                      selectedResponsibleIds.add(u.id);
                      responsibleId ??= u.id;
                    } else {
                      selectedResponsibleIds.remove(u.id);
                      if (responsibleId == u.id) {
                        responsibleId = selectedResponsibleIds.isEmpty
                            ? null
                            : selectedResponsibleIds.first;
                      }
                    }
                  }),
                ),
              ),
              DropdownButtonFormField<String>(
                value: followerId,
                decoration: InputDecoration(labelText: tr('Follower')),
                items: [const DropdownMenuItem(value: null, child: T('No follower')), ...users.map((u) => DropdownMenuItem(value: u.id, child: T(u.fullName)))],
                onChanged: (v) => set(() => followerId = v),
              ),
              DropdownButtonFormField<String>(
                value: workItemId,
                decoration: InputDecoration(labelText: tr('Work Item (optional)')),
                items: [const DropdownMenuItem(value: null, child: T('Standalone Task')), ...workItems.map((w) => DropdownMenuItem(value: w.id, child: T('${w.code} • ${w.title}', overflow: TextOverflow.ellipsis)))],
                onChanged: (v) => set(() => workItemId = v),
              ),
              SwitchListTile(value: evidence, title: const T('Evidence required'), onChanged: (v) => set(() => evidence = v)),
              SwitchListTile(value: managerConfirm, title: const T('Manager confirmation before completion'), onChanged: (v) => set(() => managerConfirm = v)),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: T(deadline == null ? 'No deadline' : 'Deadline: ${dateTimeText(deadline)}'),
                trailing: IconButton(
                  icon: const Icon(Icons.event),
                  onPressed: () async {
                    final d = await showDatePicker(context: c, firstDate: DateTime.now(), lastDate: DateTime(2100), initialDate: DateTime.now());
                    if (d != null) set(() => deadline = DateTime(d.year, d.month, d.day, 17));
                  },
                ),
              ),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const T('Cancel')),
          FilledButton(
            onPressed: () async {
              if (title.text.trim().isEmpty || selectedResponsibleIds.isEmpty || responsibleId == null) {
                Ui.snack(context, 'Title and at least one Responsible user are required');
                return;
              }
              try {
                await ref.read(repoProvider).createTask(
                  title: title.text.trim(),
                  description: desc.text.trim().isEmpty ? null : desc.text.trim(),
                  workItemId: workItemId,
                  priority: priority,
                  deadline: deadline,
                  responsibleId: responsibleId!,
                  additionalResponsibleIds: selectedResponsibleIds
                      .where((id) => id != responsibleId)
                      .toList(),
                  followerId: followerId,
                  evidenceRequired: evidence,
                  managerConfirmationRequired: managerConfirm,
                );
                if (c.mounted) Navigator.pop(c);
                ref.invalidate(tasksProvider);
                ref.invalidate(dashboardProvider);
                Ui.snack(context, 'Task created');
              } catch (e) {
                Ui.snack(context, 'Error: $e');
              }
            },
            child: const T('Create'),
          ),
        ],
      )),
    );
    title.dispose(); desc.dispose(); deadlineCtrl.dispose();
  }
}
