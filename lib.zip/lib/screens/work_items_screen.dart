import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../services/localization.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class WorkItemsScreen extends ConsumerStatefulWidget {
  const WorkItemsScreen({super.key});
  @override ConsumerState<WorkItemsScreen> createState() => _WorkItemsScreenState();
}

class _WorkItemsScreenState extends ConsumerState<WorkItemsScreen> {
  String status = '';
  String query = '';

  @override
  Widget build(BuildContext context) {
    final data = ref.watch(workItemsProvider);
    return AppScaffold(
      title: 'Work Items',
      actions: [
        IconButton(onPressed: () => ref.invalidate(workItemsProvider), icon: const Icon(Icons.refresh)),
      ],
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        icon: const Icon(Icons.add),
        label: const T('New Work Item'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                SizedBox(
                  width: 280,
                  child: TextField(
                    decoration:  InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      hintText: tr('Search Work Items'),
                    ),
                    onChanged: (value) => setState(() => query = value),
                  ),
                ),
                DropdownButton<String>(
                  value: status,
                  items: const [
                    DropdownMenuItem(value: '', child: T('All')),
                    DropdownMenuItem(value: 'open', child: T('Open')),
                    DropdownMenuItem(value: 'in_progress', child: T('In Progress')),
                    DropdownMenuItem(value: 'waiting', child: T('Waiting')),
                    DropdownMenuItem(value: 'completed', child: T('Completed')),
                    DropdownMenuItem(value: 'cancelled', child: T('Cancelled')),
                  ],
                  onChanged: (value) => setState(() => status = value ?? ''),
                ),
              ],
            ),
          ),
          Expanded(
            child: data.when(
              data: (items) {
                final q = query.trim().toLowerCase();
                final visible = items.where((w) {
                  final text = '${w.title} ${w.code} ${w.description ?? ''}'.toLowerCase();
                  return (status.isEmpty || w.status == status) && (q.isEmpty || text.contains(q));
                }).toList();
                if (visible.isEmpty) {
                  return const EmptyView('No Work Items', icon: Icons.folder_open_outlined);
                }
                return RefreshIndicator(
                  onRefresh: () async {
                    ref.invalidate(workItemsProvider);
                    await ref.read(workItemsProvider.future);
                  },
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: visible.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) => _tile(visible[i]),
                  ),
                );
              },
              loading: () => const LoadingView(),
              error: (e, _) => ErrorView(
                e,
                retry: () => ref.invalidate(workItemsProvider),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(WorkItem workItem) {
    return Card(
      child: ListTile(
        onTap: () => context.go('/work-items/${workItem.id}'),
        leading: const CircleAvatar(child: Icon(Icons.folder_open)),
        title: T(workItem.title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: T(
          '${workItem.code} • ${labelize(workItem.category)}\n'
          'Deadline: ${shortDate(workItem.deadline)}',
        ),
        isThreeLine: true,
        trailing: Wrap(
          spacing: 4,
          children: [StatusChip(workItem.status), PriorityChip(workItem.priority)],
        ),
      ),
    );
  }

  Future<void> _create() async {
    final users = await ref.read(activeUsersProvider.future);
    if (!mounted) return;

    final title = TextEditingController();
    final description = TextEditingController();
    final category = TextEditingController(text: 'Other');
    String priority = 'normal';
    String? responsibleId;
    String? followerId;
    DateTime? deadline;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const T('Create Work Item'),
          content: SizedBox(
            width: 560,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  TextField(
                    controller: title,
                    decoration: InputDecoration(labelText: tr('Title *')),
                  ),
                  TextField(
                    controller: description,
                    maxLines: 4,
                    decoration: InputDecoration(labelText: tr('Description')),
                  ),
                  TextField(
                    controller: category,
                    decoration: InputDecoration(labelText: tr('Category')),
                  ),
                  DropdownButtonFormField<String>(
                    value: priority,
                    decoration: InputDecoration(labelText: tr('Priority')),
                    items: const [
                      DropdownMenuItem(value: 'normal', child: T('Normal')),
                      DropdownMenuItem(value: 'urgent', child: T('Urgent')),
                    ],
                    onChanged: (value) => setDialogState(() => priority = value ?? 'normal'),
                  ),
                  DropdownButtonFormField<String>(
                    value: responsibleId,
                    decoration: InputDecoration(labelText: tr('Responsible')),
                    items: [
                      const DropdownMenuItem<String>(value: null, child: T('No responsible')),
                      ...users.map((u) => DropdownMenuItem<String>(value: u.id, child: T(u.fullName))),
                    ],
                    onChanged: (value) => setDialogState(() => responsibleId = value),
                  ),
                  DropdownButtonFormField<String>(
                    value: followerId,
                    decoration: InputDecoration(labelText: tr('Follower')),
                    items: [
                      const DropdownMenuItem<String>(value: null, child: T('No follower')),
                      ...users.map((u) => DropdownMenuItem<String>(value: u.id, child: T(u.fullName))),
                    ],
                    onChanged: (value) => setDialogState(() => followerId = value),
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: T(deadline == null ? 'No deadline' : 'Deadline: ${dateTimeText(deadline)}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.event),
                      onPressed: () async {
                        final selected = await showDatePicker(
                          context: dialogContext,
                          firstDate: DateTime.now(),
                          lastDate: DateTime(2100),
                          initialDate: DateTime.now(),
                        );
                        if (selected != null) {
                          setDialogState(() => deadline = DateTime(selected.year, selected.month, selected.day, 17));
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const T('Cancel')),
            FilledButton(
              onPressed: () async {
                if (title.text.trim().isEmpty) {
                  Ui.snack(context, 'Title is required.');
                  return;
                }
                try {
                  await ref.read(repoProvider).createWorkItem(
                    title: title.text.trim(),
                    description: description.text.trim().isEmpty ? null : description.text.trim(),
                    category: category.text.trim().isEmpty ? 'Other' : category.text.trim(),
                    priority: priority,
                    responsibleId: responsibleId,
                    followerId: followerId,
                    deadline: deadline,
                  );
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                  ref.invalidate(workItemsProvider);
                  ref.invalidate(dashboardProvider);
                  Ui.snack(context, 'Work Item created.');
                } catch (e) {
                  Ui.snack(context, 'Error: $e');
                }
              },
              child: const T('Create'),
            ),
          ],
        ),
      ),
    );

    title.dispose();
    description.dispose();
    category.dispose();
  }
}
