import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/localization.dart';
import '../services/repository.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final username = TextEditingController(text: 'ahmed');
  final password = TextEditingController();
  bool busy = false;
  String? error;

  Future<void> submit() async {
    final u = username.text.trim().toLowerCase();
    if (u.isEmpty || password.text.isEmpty) {
      setState(() => error = 'Enter username and password.');
      return;
    }
    if (!RegExp(r'^[a-z0-9._-]{3,40}$').hasMatch(u)) {
      setState(() => error = 'Invalid username format.');
      return;
    }

    setState(() {
      busy = true;
      error = null;
    });

    try {
      await AppRepository().loginWithUsername(
        username: u,
        password: password.text,
      );
    } on AuthException catch (e) {
      debugPrint('Auth error: ${e.message}');
      if (mounted) setState(() => error = e.message);
    } catch (e, st) {
      debugPrint('Login error: $e\n$st');
      if (mounted) setState(() => error = 'Could not sign in. $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    username.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isAr = AppI18n.isArabic;
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 430),
          child: Card(
            margin: const EdgeInsets.all(24),
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton.icon(
                        onPressed: () {
                          setState(() {
                            AppI18n.setLocale(Locale(isAr ? 'en' : 'ar'));
                          });
                        },
                        icon: const Icon(Icons.language),
                        label: T(isAr ? 'English' : 'Arabic'),
                      ),
                    ],
                  ),
                  const T(
                    'Hama Work',
                    style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const T('Internal Work & Communication'),
                  const SizedBox(height: 28),
                  TextField(
                    controller: username,
                    autocorrect: false,
                    enableSuggestions: false,
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      labelText: tr('Username'),
                      hintText: 'ahmed',
                      prefixIcon: const Icon(Icons.person_outline),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: password,
                    obscureText: true,
                    textInputAction: TextInputAction.done,
                    onSubmitted: (_) => submit(),
                    decoration: InputDecoration(
                      labelText: tr('Password'),
                      prefixIcon: const Icon(Icons.lock_outline),
                    ),
                  ),
                  if (error != null) ...[
                    const SizedBox(height: 14),
                    T(
                      error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ],
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: busy ? null : submit,
                      child: T(busy ? 'Signing in...' : 'Sign in'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
