import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../services/localization.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class ReportsScreen extends ConsumerStatefulWidget {
  const ReportsScreen({super.key});
  @override ConsumerState<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends ConsumerState<ReportsScreen> {
  List<Map<String, dynamic>> tasks = [], works = [], activities = [], daily = [], approvals = [];
  bool loading = true;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { setState(() => loading = true); try { final r = ref.read(repoProvider); tasks = await r.reportTasks(); works = await r.reportWorkItems(); activities = await r.reportActivities(); daily = await r.reportDailyWorks(); approvals = await r.reportApprovals(); } catch (_) {} if (mounted) setState(() => loading = false); }
  Map<String, int> countBy(List<Map<String, dynamic>> rows, String key) { final out = <String, int>{}; for (final r in rows) { final v = (r[key] ?? 'unknown').toString(); out[v] = (out[v] ?? 0) + 1; } return out; }
  @override Widget build(BuildContext context) { final tc = countBy(tasks, 'status'), wc = countBy(works, 'status'), ac = countBy(activities, 'type'), dc = countBy(daily, 'status'), pc = countBy(approvals, 'status'); return AppScaffold(title: 'Reports', actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))], body: loading ? const LoadingView() : ListView(padding: const EdgeInsets.all(16), children: [
    _reportCard('Tasks', tasks.length, tc, tasks.length),
    _reportCard('Work Items', works.length, wc, works.length),
    _reportCard('Activities', activities.length, ac, activities.length),
    _reportCard('Daily Work', daily.length, dc, daily.length),
    _reportCard('Approvals', approvals.length, pc, approvals.length),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: T('Average task score: ${_avgScore().toStringAsFixed(1)} / 10'))),
  ])); }
  Widget _reportCard(String title, int total, Map<String, int> counts, int denominator) => Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [T('$title • Total $total', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 8), ...counts.entries.map((e) => _bar(e.key, e.value, denominator))])));
  Widget _bar(String label, int value, int total) { final pct = total == 0 ? 0.0 : value / total; return Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: T(labelize(label))), T('$value (${(pct * 100).toStringAsFixed(0)}%)')]), const SizedBox(height: 4), LinearProgressIndicator(value: pct)])); }
  double _avgScore() { final scores = tasks.map((m) => int.tryParse('${m['score']}')).whereType<int>().toList(); if (scores.isEmpty) return 0; return scores.reduce((a, b) => a + b) / scores.length; }
}
