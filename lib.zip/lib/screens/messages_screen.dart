import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../services/localization.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class MessagesScreen extends ConsumerStatefulWidget {
  const MessagesScreen({super.key});
  @override ConsumerState<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends ConsumerState<MessagesScreen> {
  String filter = '';

  @override
  Widget build(BuildContext context) {
    final data = ref.watch(messagesProvider);
    return AppScaffold(
      title: 'Messages',
      actions: [
        IconButton(
          onPressed: () => ref.invalidate(messagesProvider),
          icon: const Icon(Icons.refresh),
        ),
      ],
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _compose,
        icon: const Icon(Icons.edit),
        label: const T('New Message'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: '', label: T('All')),
                  ButtonSegment(value: 'information', label: T('Info')),
                  ButtonSegment(value: 'action_required', label: T('Action')),
                  ButtonSegment(value: 'task', label: T('Task')),
                ],
                selected: {filter},
                onSelectionChanged: (value) {
                  setState(() => filter = value.first);
                },
              ),
            ),
          ),
          Expanded(
            child: data.when(
              data: (items) {
                final visible = filter.isEmpty
                    ? items
                    : items.where((m) => m.messageType == filter).toList();
                if (visible.isEmpty) {
                  return const EmptyView(
                    'No messages',
                    icon: Icons.chat_bubble_outline,
                  );
                }
                return RefreshIndicator(
                  onRefresh: () async {
                    ref.invalidate(messagesProvider);
                    await ref.read(messagesProvider.future);
                  },
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: visible.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) => _tile(visible[i]),
                  ),
                );
              },
              loading: () => const LoadingView(),
              error: (e, _) => ErrorView(
                e,
                retry: () => ref.invalidate(messagesProvider),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(MessageItem message) {
    final icon = switch (message.messageType) {
      'task' => Icons.task,
      'action_required' => Icons.priority_high,
      _ => Icons.info_outline,
    };
    return Card(
      child: ListTile(
        onTap: () => context.go('/messages/${message.id}'),
        leading: CircleAvatar(child: Icon(icon)),
        title: T(
          message.content,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: T(
          '${message.senderName ?? 'User'} • ${dateTimeText(message.createdAt)}\n'
          'Seen ${message.seenCount}/${message.recipientCount}',
        ),
        isThreeLine: true,
        trailing: StatusChip(message.messageType),
      ),
    );
  }

  Future<void> _compose() async {
    final users = await ref.read(activeUsersProvider.future);
    if (!mounted) return;

    final content = TextEditingController();
    String messageType = 'information';
    String audience = 'everyone';
    final selected = <String>{};

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const T('New Message'),
          content: SizedBox(
            width: 580,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  TextField(
                    controller: content,
                    maxLines: 7,
                    decoration:  InputDecoration(
                      labelText: tr('Message *'),
                      hintText: tr('Use @username to mention someone'),
                    ),
                  ),
                  DropdownButtonFormField<String>(
                    value: messageType,
                    decoration: InputDecoration(labelText: tr('Type')),
                    items: const [
                      DropdownMenuItem(
                        value: 'information',
                        child: T('Information'),
                      ),
                      DropdownMenuItem(
                        value: 'action_required',
                        child: T('Action Required'),
                      ),
                      DropdownMenuItem(value: 'task', child: T('Task')),
                    ],
                    onChanged: (value) {
                      setDialogState(
                        () => messageType = value ?? 'information',
                      );
                    },
                  ),
                  DropdownButtonFormField<String>(
                    value: audience,
                    decoration: InputDecoration(labelText: tr('Audience')),
                    items: const [
                      DropdownMenuItem(
                        value: 'everyone',
                        child: T('Everyone'),
                      ),
                      DropdownMenuItem(
                        value: 'selected',
                        child: T('Selected users'),
                      ),
                    ],
                    onChanged: (value) {
                      setDialogState(
                        () => audience = value ?? 'everyone',
                      );
                    },
                  ),
                  if (audience == 'selected') ...[
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: EdgeInsets.only(top: 12),
                        child: T(
                          'Recipients',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                    ...users.map(
                      (user) => CheckboxListTile(
                        value: selected.contains(user.id),
                        title: T(user.fullName),
                        subtitle: T(
                          '@${user.username} • ${user.departmentName ?? ''}',
                        ),
                        onChanged: (value) {
                          setDialogState(() {
                            if (value == true) {
                              selected.add(user.id);
                            } else {
                              selected.remove(user.id);
                            }
                          });
                        },
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const T('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                if (content.text.trim().isEmpty) return;
                try {
                  await ref.read(repoProvider).sendMessage(
                    content: content.text.trim(),
                    messageType: messageType,
                    audienceType: audience,
                    recipientIds: selected.toList(),
                  );
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                  ref.invalidate(messagesProvider);
                  ref.invalidate(dashboardProvider);
                  Ui.snack(context, 'Message sent.');
                } catch (e) {
                  Ui.snack(context, 'Error: $e');
                }
              },
              child: const T('Send'),
            ),
          ],
        ),
      ),
    );
    content.dispose();
  }
}
