import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/app_helpers.dart';
import '../services/localization.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/common.dart';

class ApprovalsScreen extends ConsumerStatefulWidget {
  const ApprovalsScreen({super.key});

  @override
  ConsumerState<ApprovalsScreen> createState() => _ApprovalsScreenState();
}

class _ApprovalsScreenState extends ConsumerState<ApprovalsScreen> {
  @override
  Widget build(BuildContext context) {
    final data = ref.watch(approvalsProvider);
    final profile = ref.watch(profileProvider).valueOrNull;
    final canDecide = profile?.isGm == true || profile?.isManager == true;

    return AppScaffold(
      title: 'Approvals',
      actions: [
        IconButton(
          onPressed: () => ref.invalidate(approvalsProvider),
          icon: const Icon(Icons.refresh),
        ),
      ],
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        icon: const Icon(Icons.add),
        label: const T('Request'),
      ),
      body: data.when(
        data: (items) {
          if (items.isEmpty) {
            return const EmptyView(
              'No approvals',
              icon: Icons.fact_check_outlined,
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) => _tile(items[i], canDecide),
          );
        },
        loading: () => const LoadingView(),
        error: (e, _) => ErrorView(
          e,
          retry: () => ref.invalidate(approvalsProvider),
        ),
      ),
    );
  }

  Widget _tile(Approval a, bool canDecide) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.fact_check_outlined),
              ),
              title: T(a.title?.isNotEmpty == true ? a.title! : a.code),
              subtitle: T(
                '${a.requestText}\n'
                'Requested from: ${a.requestedFrom}'
                '${a.deadline == null ? '' : '\nDeadline: ${shortDate(a.deadline)}'}',
              ),
              isThreeLine: true,
              trailing: StatusChip(a.status),
            ),
            if (canDecide && a.status == 'pending')
              Align(
                alignment: Alignment.centerRight,
                child: Wrap(
                  spacing: 6,
                  children: [
                    TextButton(
                      onPressed: () => _decide(a, 'need_more_info'),
                      child: const T('Need info'),
                    ),
                    TextButton(
                      onPressed: () => _decide(a, 'rejected'),
                      child: const T('Reject'),
                    ),
                    FilledButton(
                      onPressed: () => _decide(a, 'approved'),
                      child: const T('Approve'),
                    ),
                  ],
                ),
              ),
            if (canDecide && a.status == 'approved')
              Align(
                alignment: Alignment.centerRight,
                child: OutlinedButton.icon(
                  onPressed: () => _createTaskFromApproval(a),
                  icon: const Icon(Icons.add_task),
                  label: const T('Create Task'),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _decide(Approval a, String status) async {
    final comment = TextEditingController();
    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: T(labelize(status)),
          content: TextField(
            controller: comment,
            maxLines: 4,
            decoration: InputDecoration(labelText: tr('Comment')),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const T('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                try {
                  await ref.read(repoProvider).decideApproval(
                        a.id,
                        status,
                        comment: comment.text.trim().isEmpty
                            ? null
                            : comment.text.trim(),
                      );
                  if (dialogContext.mounted) {
                    Navigator.pop(dialogContext);
                  }
                  ref.invalidate(approvalsProvider);
                  ref.invalidate(dashboardProvider);
                  if (mounted) Ui.snack(context, 'Decision saved.');
                } catch (e) {
                  Ui.snack(context, 'Error: $e');
                }
              },
              child: const T('Confirm'),
            ),
          ],
        ),
      );
    } finally {
      comment.dispose();
    }
  }

  Future<void> _create() async {
    final users = await ref.read(activeUsersProvider.future);
    if (!mounted || users.isEmpty) {
      Ui.snack(context, 'No active users are available.');
      return;
    }

    final title = TextEditingController();
    final request = TextEditingController();
    String? requestedFrom = users.first.id;
    DateTime? deadline;

    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => StatefulBuilder(
          builder: (dialogContext, setDialogState) {
            return AlertDialog(
              title: const T('New Approval Request'),
              content: SizedBox(
                width: 560,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      TextField(
                        controller: title,
                        decoration: InputDecoration(labelText: tr('Title')),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: request,
                        maxLines: 5,
                        decoration:  InputDecoration(
                          labelText: tr('Request *'),
                        ),
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: requestedFrom,
                        isExpanded: true,
                        decoration:  InputDecoration(
                          labelText: tr('Requested from *'),
                        ),
                        items: users
                            .map(
                              (u) => DropdownMenuItem<String>(
                                value: u.id,
                                child: T(u.fullName),
                              ),
                            )
                            .toList(),
                        onChanged: (v) =>
                            setDialogState(() => requestedFrom = v),
                      ),
                      const SizedBox(height: 10),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: T(
                          deadline == null
                              ? 'No deadline'
                              : 'Deadline: ${dateTimeText(deadline)}',
                        ),
                        trailing: IconButton(
                          icon: const Icon(Icons.event),
                          onPressed: () async {
                            final d = await showDatePicker(
                              context: dialogContext,
                              firstDate: DateTime.now(),
                              lastDate: DateTime(2100),
                              initialDate: DateTime.now(),
                            );
                            if (d != null) {
                              setDialogState(
                                () => deadline =
                                    DateTime(d.year, d.month, d.day, 17),
                              );
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const T('Cancel'),
                ),
                FilledButton(
                  onPressed: () async {
                    if (request.text.trim().isEmpty || requestedFrom == null) {
                      Ui.snack(context, 'Request and recipient are required.');
                      return;
                    }
                    try {
                      await ref.read(repoProvider).createApproval(
                            title: title.text.trim().isEmpty
                                ? null
                                : title.text.trim(),
                            requestText: request.text.trim(),
                            requestedFrom: requestedFrom!,
                            deadline: deadline,
                          );
                      if (dialogContext.mounted) {
                        Navigator.pop(dialogContext);
                      }
                      ref.invalidate(approvalsProvider);
                      ref.invalidate(dashboardProvider);
                      if (mounted) Ui.snack(context, 'Approval requested.');
                    } catch (e) {
                      Ui.snack(context, 'Error: $e');
                    }
                  },
                  child: const T('Submit'),
                ),
              ],
            );
          },
        ),
      );
    } finally {
      title.dispose();
      request.dispose();
    }
  }

  Future<void> _createTaskFromApproval(Approval a) async {
    final users = await ref.read(activeUsersProvider.future);
    if (!mounted || users.isEmpty) {
      Ui.snack(context, 'No active users are available.');
      return;
    }

    final title = TextEditingController(text: a.title ?? a.requestText);
    final description = TextEditingController(text: a.requestText);
    String? responsible = users.first.id;
    String priority = 'normal';
    DateTime deadline = DateTime.now().add(const Duration(days: 1));

    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => StatefulBuilder(
          builder: (dialogContext, setDialogState) {
            return AlertDialog(
              title: const T('Create Task from Approval'),
              content: SizedBox(
                width: 560,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      TextField(
                        controller: title,
                        decoration:
                            InputDecoration(labelText: tr('Task title')),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: description,
                        maxLines: 4,
                        decoration:
                            InputDecoration(labelText: tr('Description')),
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: priority,
                        decoration: InputDecoration(labelText: tr('Priority')),
                        items: const [
                          DropdownMenuItem(
                              value: 'normal', child: T('Normal')),
                          DropdownMenuItem(
                              value: 'urgent', child: T('Urgent')),
                        ],
                        onChanged: (v) => setDialogState(
                          () => priority = v ?? 'normal',
                        ),
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: responsible,
                        isExpanded: true,
                        decoration:
                            InputDecoration(labelText: tr('Responsible *')),
                        items: users
                            .map(
                              (u) => DropdownMenuItem<String>(
                                value: u.id,
                                child: T(u.fullName),
                              ),
                            )
                            .toList(),
                        onChanged: (v) =>
                            setDialogState(() => responsible = v),
                      ),
                      const SizedBox(height: 10),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: T('Deadline: ${dateTimeText(deadline)}'),
                        trailing: IconButton(
                          icon: const Icon(Icons.event),
                          onPressed: () async {
                            final d = await showDatePicker(
                              context: dialogContext,
                              firstDate: DateTime.now(),
                              lastDate: DateTime(2100),
                              initialDate: deadline,
                            );
                            if (d != null) {
                              setDialogState(
                                () => deadline =
                                    DateTime(d.year, d.month, d.day, 17),
                              );
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const T('Cancel'),
                ),
                FilledButton(
                  onPressed: () async {
                    if (responsible == null || title.text.trim().isEmpty) {
                      Ui.snack(context, 'Title and responsible are required.');
                      return;
                    }
                    try {
                      await ref.read(repoProvider).createTask(
                            title: title.text.trim(),
                            description: description.text.trim(),
                            priority: priority,
                            responsibleId: responsible!,
                            deadline: deadline,
                            workItemId: a.workItemId,
                          );
                      if (dialogContext.mounted) {
                        Navigator.pop(dialogContext);
                      }
                      ref.invalidate(tasksProvider);
                      ref.invalidate(dashboardProvider);
                      if (mounted) Ui.snack(context, 'Task created.');
                    } catch (e) {
                      Ui.snack(context, 'Error: $e');
                    }
                  },
                  child: const T('Create'),
                ),
              ],
            );
          },
        ),
      );
    } finally {
      title.dispose();
      description.dispose();
    }
  }
}
