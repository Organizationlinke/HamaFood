import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../core/supabase_client.dart';
import '../providers/providers.dart';
import '../models/models.dart';
import '../services/localization.dart';
import '../services/repository.dart';

class AppScaffold extends ConsumerWidget {
  final String title;
  final Widget body;
  final List<Widget>? actions;
  final Widget? floatingActionButton;
  final bool showBack;

  const AppScaffold({
    super.key,
    required this.title,
    required this.body,
    this.actions,
    this.floatingActionButton,
    this.showBack = false,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(profileProvider).valueOrNull;
    final unread = ref.watch(dashboardProvider).valueOrNull?.unreadNotifications ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: T(title),
        leading: showBack
            ? null
            : Builder(
                builder: (c) => IconButton(
                  icon: const Icon(Icons.menu),
                  onPressed: () => Scaffold.of(c).openDrawer(),
                ),
              ),
        automaticallyImplyLeading: showBack,
        actions: [
          Stack(
            children: [
              IconButton(
                onPressed: () => context.go('/notifications'),
                icon: const Icon(Icons.notifications_outlined),
                tooltip: tr('Notifications'),
              ),
              if (unread > 0)
                Positioned(
                  right: 7,
                  top: 6,
                  child: Container(
                    width: 9,
                    height: 9,
                    decoration: const BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
            ],
          ),
          ...?actions,
        ],
      ),
      drawer: _drawer(context, ref, p),
      body: body,
      floatingActionButton: floatingActionButton,
    );
  }

  Widget _drawer(BuildContext context, WidgetRef ref, Profile? p) {
    final profile = ref.watch(profileProvider).valueOrNull;

    void go(String route) {
      Navigator.pop(context);
      context.go(route);
    }

    Future<void> setLanguage(String code) async {
      try {
        await ref.read(repoProvider).setPreferredLanguage(code);
        AppI18n.setLocale(Locale(code));
        ref.read(languageProvider.notifier).state = Locale(code);
        ref.invalidate(profileProvider);
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: T('Error: $e')),
          );
        }
      }
    }

    return Drawer(
      child: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: T(p?.fullName ?? 'User', translate: p?.fullName == null),
              accountEmail: T(
                '@${p?.username ?? ''} • ${AppI18n.roleLabel(p?.role ?? '')}',
                translate: false,
              ),
              currentAccountPicture: CircleAvatar(
                child: T(
                  (p?.fullName?.isNotEmpty ?? false) ? p!.fullName[0].toUpperCase() : 'U',
                  translate: false,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard_outlined),
              title: const T('Dashboard'),
              onTap: () => go('/'),
            ),
            ListTile(
              leading: const Icon(Icons.folder_open_outlined),
              title: const T('Work Items'),
              onTap: () => go('/work-items'),
            ),
            ListTile(
              leading: const Icon(Icons.task_alt_outlined),
              title: const T('Team Tasks'),
              onTap: () => go('/team-tasks'),
            ),
            ListTile(
              leading: const Icon(Icons.person_pin_outlined),
              title: const T('My Tasks'),
              onTap: () => go('/my-tasks'),
            ),
            ListTile(
              leading: const Icon(Icons.chat_bubble_outline),
              title: const T('Messages'),
              onTap: () => go('/messages'),
            ),
            ListTile(
              leading: const Icon(Icons.today_outlined),
              title: const T('Daily Work'),
              onTap: () => go('/daily-work'),
            ),
            ListTile(
              leading: const Icon(Icons.event_note_outlined),
              title: const T('Activities'),
              onTap: () => go('/activities'),
            ),
            ListTile(
              leading: const Icon(Icons.fact_check_outlined),
              title: const T('Approvals'),
              onTap: () => go('/approvals'),
            ),
            ListTile(
              leading: const Icon(Icons.search_outlined),
              title: const T('Search'),
              onTap: () => go('/search'),
            ),
            ListTile(
              leading: const Icon(Icons.bar_chart_outlined),
              title: const T('Reports'),
              onTap: () => go('/reports'),
            ),
            if (profile?.canManageUsers == true)
              ListTile(
                leading: const Icon(Icons.people_outline),
                title: const T('Users'),
                onTap: () => go('/users'),
              ),
            ListTile(
              leading: const Icon(Icons.settings_outlined),
              title: const T('Settings'),
              onTap: () => go('/settings'),
            ),
            ListTile(
              leading: const Icon(Icons.language_outlined),
              title: const T('Language'),
              subtitle: T(
                ref.watch(languageProvider).languageCode == 'ar' ? 'Arabic' : 'English',
              ),
              onTap: () async {
                final selected = await showDialog<String>(
                  context: context,
                  builder: (c) {
                    final current = ref.read(languageProvider).languageCode;
                    return AlertDialog(
                      title: const T('Choose language'),
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          RadioListTile<String>(
                            value: 'ar',
                            groupValue: current,
                            title: const T('Arabic'),
                            onChanged: (v) => Navigator.pop(c, v),
                          ),
                          RadioListTile<String>(
                            value: 'en',
                            groupValue: current,
                            title: const T('English'),
                            onChanged: (v) => Navigator.pop(c, v),
                          ),
                        ],
                      ),
                    );
                  },
                );
                if (selected != null) {
                  await setLanguage(selected);
                }
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const T('Sign out'),
              onTap: () async {
                Navigator.pop(context);
                await supabase.auth.signOut();
                AppI18n.setLocale(const Locale('ar'));
                ref.read(languageProvider.notifier).state = const Locale('ar');
                ref.invalidate(profileProvider);
              },
            ),
          ],
        ),
      ),
    );
  }
}

