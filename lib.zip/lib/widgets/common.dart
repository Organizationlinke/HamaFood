import 'package:flutter/material.dart';
import '../services/app_helpers.dart';
import '../services/localization.dart';

class StatusChip extends StatelessWidget {
  final String value;
  const StatusChip(this.value, {super.key});

  @override
  Widget build(BuildContext context) {
    final c = statusColor(value);
    return Chip(
      label: T(labelize(value)),
      backgroundColor: c.withOpacity(.08),
      side: BorderSide(color: c.withOpacity(.25)),
      labelStyle: TextStyle(color: c, fontWeight: FontWeight.w600),
      visualDensity: VisualDensity.compact,
    );
  }
}

class PriorityChip extends StatelessWidget {
  final String value;
  const PriorityChip(this.value, {super.key});

  @override
  Widget build(BuildContext context) {
    final c = priorityColor(value);
    return Chip(
      label: T(labelize(value)),
      backgroundColor: c.withOpacity(.08),
      side: BorderSide(color: c.withOpacity(.25)),
      labelStyle: TextStyle(color: c, fontWeight: FontWeight.w600),
      visualDensity: VisualDensity.compact,
    );
  }
}

class LoadingView extends StatelessWidget {
  const LoadingView({super.key});

  @override
  Widget build(BuildContext context) => const Center(
        child: CircularProgressIndicator(),
      );
}

class EmptyView extends StatelessWidget {
  final String text;
  final IconData icon;

  const EmptyView(
    this.text, {
    this.icon = Icons.inbox_outlined,
    super.key,
  });

  @override
  Widget build(BuildContext context) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 52, color: Colors.grey),
            const SizedBox(height: 12),
            T(text),
          ],
        ),
      );
}

class ErrorView extends StatelessWidget {
  final Object error;
  final VoidCallback? retry;

  const ErrorView(this.error, {this.retry, super.key});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48),
              const SizedBox(height: 12),
              T('Error: $error', textAlign: TextAlign.center),
              if (retry != null)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: OutlinedButton(
                    onPressed: retry,
                    child: const T('Retry'),
                  ),
                ),
            ],
          ),
        ),
      );
}

class LabeledValue extends StatelessWidget {
  final String label;
  final String value;

  const LabeledValue(this.label, this.value, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            T(label, style: Theme.of(context).textTheme.labelMedium),
            const SizedBox(height: 3),
            T(value),
          ],
        ),
      );
}
