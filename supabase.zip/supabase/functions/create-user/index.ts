import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function generateUserCode(role: string, userId: string) {
  const prefix = role === "manager" ? "MGR" : "EMP";
  return `${prefix}-${userId.replaceAll("-", "").slice(0, 8).toUpperCase()}`;
}

Deno.serve(async (req) => {
  let createdAuthUserId: string | null = null;

  try {
    if (req.method === "OPTIONS") {
      return new Response("ok", { status: 200, headers: corsHeaders });
    }
    if (req.method !== "POST") return jsonResponse({ error: "Method not allowed" }, 405);

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return jsonResponse({ error: "Unauthorized" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const publishableKeysRaw = Deno.env.get("SUPABASE_PUBLISHABLE_KEYS");
    const secretKeysRaw = Deno.env.get("SUPABASE_SECRET_KEYS");
    if (!supabaseUrl || !publishableKeysRaw || !secretKeysRaw) {
      return jsonResponse({ error: "Supabase server configuration is incomplete" }, 500);
    }

    const publishableKey = JSON.parse(publishableKeysRaw)["default"];
    const secretKey = JSON.parse(secretKeysRaw)["default"];
    if (!publishableKey || !secretKey) return jsonResponse({ error: "Supabase key configuration is incomplete" }, 500);

    const supabaseUser = createClient(supabaseUrl, publishableKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const supabaseAdmin = createClient(supabaseUrl, secretKey);

    const { data: { user }, error: userError } = await supabaseUser.auth.getUser();
    if (userError || !user) return jsonResponse({ error: "Unauthorized" }, 401);

    const { data: currentProfile, error: currentProfileError } = await supabaseAdmin
      .from("profiles")
      .select("id, role, is_active")
      .eq("id", user.id)
      .single();

    if (currentProfileError || !currentProfile) {
      return jsonResponse({ error: "Could not verify current user profile", details: currentProfileError?.message ?? null }, 403);
    }
    if (!currentProfile.is_active) return jsonResponse({ error: "Current user is inactive" }, 403);
    if (currentProfile.role !== "gm") return jsonResponse({ error: "Only the General Manager can create users" }, 403);

    const body = await req.json();
    const username = String(body.username ?? "").trim().toLowerCase();
    const fullName = String(body.full_name ?? "").trim();
    const jobTitle = String(body.job_title ?? "").trim();
    const password = String(body.password ?? "");
    const role = String(body.role ?? "").trim().toLowerCase();
    const departmentCode = String(body.department_code ?? "").trim().toUpperCase();

    if (!username || !fullName || !password || !role || !departmentCode) {
      return jsonResponse({ error: "username, full_name, password, role and department_code are required" }, 400);
    }
    if (!/^[a-z0-9._-]{3,40}$/.test(username)) {
      return jsonResponse({ error: "Username must contain only lowercase letters, numbers, dot, underscore or dash." }, 400);
    }
    if (password.length < 6) return jsonResponse({ error: "Password must be at least 6 characters." }, 400);
    if (role !== "manager" && role !== "employee") return jsonResponse({ error: "Role must be manager or employee." }, 400);

    const { data: existingProfile, error: existingProfileError } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("username", username)
      .maybeSingle();
    if (existingProfileError) return jsonResponse({ error: "Could not check username", details: existingProfileError.message }, 500);
    if (existingProfile) return jsonResponse({ error: "Username already exists" }, 400);

    const { data: department, error: departmentError } = await supabaseAdmin
      .from("departments")
      .select("id, code, name, is_active")
      .eq("code", departmentCode)
      .maybeSingle();
    if (departmentError) return jsonResponse({ error: "Could not verify department", details: departmentError.message }, 500);
    if (!department) return jsonResponse({ error: "Department not found", department_code: departmentCode }, 400);
    if (!department.is_active) return jsonResponse({ error: "Department is inactive", department_code: departmentCode }, 400);

    const email = `${username}@auth.hamaholding.com`;
    const { data: createdUserData, error: createUserError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });
    if (createUserError || !createdUserData.user) {
      return jsonResponse({ error: createUserError?.message ?? "Could not create authentication user" }, 400);
    }
    createdAuthUserId = createdUserData.user.id;

    const userCode = generateUserCode(role, createdAuthUserId);
    const { error: profileInsertError } = await supabaseAdmin.from("profiles").insert({
      id: createdAuthUserId,
      username,
      user_code: userCode,
      full_name: fullName,
      role,
      department_id: department.id,
      job_title: jobTitle || null,
      is_active: true,
    });

    if (profileInsertError) {
      await supabaseAdmin.auth.admin.deleteUser(createdAuthUserId);
      createdAuthUserId = null;
      return jsonResponse({ error: "Could not create profile", details: profileInsertError.message }, 400);
    }

    return jsonResponse({
      success: true,
      message: "User created successfully",
      user_id: createdUserData.user.id,
      username,
      email,
      user_code: userCode,
      role,
      department: { id: department.id, code: department.code, name: department.name },
    });
  } catch (error) {
    if (createdAuthUserId) {
      try {
        const supabaseUrl = Deno.env.get("SUPABASE_URL");
        const secretKeysRaw = Deno.env.get("SUPABASE_SECRET_KEYS");
        if (supabaseUrl && secretKeysRaw) {
          const secretKey = JSON.parse(secretKeysRaw)["default"];
          if (secretKey) await createClient(supabaseUrl, secretKey).auth.admin.deleteUser(createdAuthUserId);
        }
      } catch (_) {}
    }
    return jsonResponse({ error: error instanceof Error ? error.message : String(error) }, 500);
  }
});
