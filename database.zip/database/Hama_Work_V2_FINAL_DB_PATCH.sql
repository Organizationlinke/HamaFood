-- Hama Work V2 - Fixes for errors observed in the 2026-09-22 screen recording
-- Run in Supabase SQL Editor.

BEGIN;

-- =========================================================
-- 1) work_items.is_archived is used by the Flutter V2 app.
-- =========================================================
ALTER TABLE public.work_items
  ADD COLUMN IF NOT EXISTS is_archived BOOLEAN NOT NULL DEFAULT FALSE;

-- Backfill defensively from archived_at when that column exists.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'work_items'
      AND column_name = 'archived_at'
  ) THEN
    UPDATE public.work_items
       SET is_archived = TRUE
     WHERE archived_at IS NOT NULL
       AND is_archived = FALSE;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_work_items_is_archived
  ON public.work_items(is_archived);

-- =========================================================
-- 2) The RLS helper functions are called by authenticated users'
--    policies, so authenticated must have EXECUTE permission.
-- =========================================================
GRANT USAGE ON SCHEMA private TO authenticated;

GRANT EXECUTE ON FUNCTION private.current_user_id() TO authenticated;
GRANT EXECUTE ON FUNCTION private.current_user_role() TO authenticated;
GRANT EXECUTE ON FUNCTION private.is_gm() TO authenticated;
GRANT EXECUTE ON FUNCTION private.is_manager() TO authenticated;
GRANT EXECUTE ON FUNCTION private.can_access_work_item(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION private.can_access_task(uuid) TO authenticated;

-- =========================================================
-- 3) Fix message RLS recursion.
--    Policies that cross messages <-> message_recipients can recursively
--    invoke each other. A SECURITY DEFINER helper avoids that cycle.
-- =========================================================
CREATE OR REPLACE FUNCTION private.can_access_message(p_message_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.messages m
    WHERE m.id = p_message_id
      AND (
        private.is_gm()
        OR m.created_by = auth.uid()
        OR m.audience_type = 'everyone'
        OR EXISTS (
          SELECT 1
          FROM public.message_recipients mr
          WHERE mr.message_id = m.id
            AND mr.user_id = auth.uid()
        )
      )
  );
$$;

GRANT EXECUTE ON FUNCTION private.can_access_message(uuid) TO authenticated;

-- Drop all existing policies on these two tables so old recursive policies
-- cannot remain alongside the fixed ones.
DO $$
DECLARE
  p record;
BEGIN
  FOR p IN
    SELECT policyname
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'messages'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.messages', p.policyname);
  END LOOP;

  FOR p IN
    SELECT policyname
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'message_recipients'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.message_recipients', p.policyname);
  END LOOP;
END $$;

-- Messages: users can read messages they are allowed to see.
CREATE POLICY messages_select
ON public.messages
FOR SELECT
TO authenticated
USING (private.can_access_message(id));

-- Messages: any authenticated user can create a message as themselves.
CREATE POLICY messages_insert
ON public.messages
FOR INSERT
TO authenticated
WITH CHECK (created_by = auth.uid());

-- Messages: creator or GM can edit/remove their own message.
CREATE POLICY messages_update
ON public.messages
FOR UPDATE
TO authenticated
USING (private.is_gm() OR created_by = auth.uid())
WITH CHECK (private.is_gm() OR created_by = auth.uid());

CREATE POLICY messages_delete
ON public.messages
FOR DELETE
TO authenticated
USING (private.is_gm() OR created_by = auth.uid());

-- Recipients: access follows the parent message. A creator/GM can manage
-- recipients; each recipient can update their own seen_at.
CREATE POLICY message_recipients_select
ON public.message_recipients
FOR SELECT
TO authenticated
USING (private.can_access_message(message_id));

CREATE POLICY message_recipients_insert
ON public.message_recipients
FOR INSERT
TO authenticated
WITH CHECK (
  private.is_gm()
  OR EXISTS (
    SELECT 1
    FROM public.messages m
    WHERE m.id = message_id
      AND m.created_by = auth.uid()
  )
);

CREATE POLICY message_recipients_update
ON public.message_recipients
FOR UPDATE
TO authenticated
USING (user_id = auth.uid() OR private.is_gm())
WITH CHECK (user_id = auth.uid() OR private.is_gm());

CREATE POLICY message_recipients_delete
ON public.message_recipients
FOR DELETE
TO authenticated
USING (
  private.is_gm()
  OR EXISTS (
    SELECT 1
    FROM public.messages m
    WHERE m.id = message_id
      AND m.created_by = auth.uid()
  )
);

-- =========================================================
-- 4) Standalone Activities: remove the old context requirement if present.
-- =========================================================
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conrelid = 'public.activities'::regclass
      AND conname = 'activities_context_check'
  ) THEN
    ALTER TABLE public.activities
      DROP CONSTRAINT activities_context_check;
  END IF;
END $$;

COMMIT;

-- =========================================================
-- Verification
-- =========================================================
SELECT
  'work_items.is_archived' AS check_name,
  EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'work_items'
      AND column_name = 'is_archived'
  ) AS ok;

SELECT
  routine_schema,
  routine_name,
  privilege_type
FROM information_schema.routine_privileges
WHERE routine_schema = 'private'
  AND grantee = 'authenticated'
  AND routine_name IN (
    'current_user_id',
    'current_user_role',
    'is_gm',
    'is_manager',
    'can_access_work_item',
    'can_access_task',
    'can_access_message'
  )
ORDER BY routine_name, privilege_type;

SELECT
  schemaname,
  tablename,
  policyname,
  cmd
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('messages', 'message_recipients')
ORDER BY tablename, policyname;
-- Hama Work V2 - per-user language preference
-- Supported values: ar / en

ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS preferred_language TEXT NOT NULL DEFAULT 'ar';

UPDATE public.profiles
SET preferred_language = 'ar'
WHERE preferred_language IS NULL
   OR preferred_language NOT IN ('ar', 'en');

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'profiles_preferred_language_check'
      AND conrelid = 'public.profiles'::regclass
  ) THEN
    ALTER TABLE public.profiles
      ADD CONSTRAINT profiles_preferred_language_check
      CHECK (preferred_language IN ('ar', 'en'));
  END IF;
END $$;

-- Secure, self-service RPC. It only updates the current user's language.
CREATE OR REPLACE FUNCTION public.set_preferred_language(p_language TEXT)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF p_language NOT IN ('ar', 'en') THEN
    RAISE EXCEPTION 'Unsupported language';
  END IF;

  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  UPDATE public.profiles
  SET preferred_language = p_language
  WHERE id = auth.uid()
    AND is_active = TRUE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profile not found or inactive';
  END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.set_preferred_language(TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.set_preferred_language(TEXT) TO authenticated;

SELECT id, username, preferred_language
FROM public.profiles
ORDER BY full_name;
